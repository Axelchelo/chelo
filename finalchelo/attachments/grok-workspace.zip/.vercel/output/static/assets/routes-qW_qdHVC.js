import{a as e,i as t,n,o as r,r as i,t as a}from"./index-DBaeXEzF.js";var o=a(`check`,[[`path`,{d:`M20 6 9 17l-5-5`,key:`1gmf2c`}]]),s=a(`copy`,[[`rect`,{width:`14`,height:`14`,x:`8`,y:`8`,rx:`2`,ry:`2`,key:`17jyea`}],[`path`,{d:`M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,key:`zix9uf`}]]),c=a(`dices`,[[`rect`,{width:`12`,height:`12`,x:`2`,y:`10`,rx:`2`,ry:`2`,key:`6agr2n`}],[`path`,{d:`m17.92 14 3.5-3.5a2.24 2.24 0 0 0 0-3l-5-4.92a2.24 2.24 0 0 0-3 0L10 6`,key:`1o487t`}],[`path`,{d:`M6 18h.01`,key:`uhywen`}],[`path`,{d:`M10 14h.01`,key:`ssrbsk`}],[`path`,{d:`M15 6h.01`,key:`cblpky`}],[`path`,{d:`M18 9h.01`,key:`2061c0`}]]),l=a(`download`,[[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}],[`polyline`,{points:`7 10 12 15 17 10`,key:`2ggqvy`}],[`line`,{x1:`12`,x2:`12`,y1:`15`,y2:`3`,key:`1vk2je`}]]),u=a(`file-up`,[[`path`,{d:`M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z`,key:`1rqfz7`}],[`path`,{d:`M14 2v4a2 2 0 0 0 2 2h4`,key:`tnqrlb`}],[`path`,{d:`M12 12v6`,key:`3ahymv`}],[`path`,{d:`m15 15-3-3-3 3`,key:`15xj92`}]]),d=a(`history`,[[`path`,{d:`M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,key:`1357e3`}],[`path`,{d:`M3 3v5h5`,key:`1xhq8a`}],[`path`,{d:`M12 7v5l4 2`,key:`1fdv2h`}]]),f=a(`lock`,[[`rect`,{width:`18`,height:`11`,x:`3`,y:`11`,rx:`2`,ry:`2`,key:`1w4ew1`}],[`path`,{d:`M7 11V7a5 5 0 0 1 10 0v4`,key:`fwvmzm`}]]),p=a(`shield`,[[`path`,{d:`M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z`,key:`oel41y`}]]),m=a(`trash-2`,[[`path`,{d:`M3 6h18`,key:`d0wm0j`}],[`path`,{d:`M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6`,key:`4alrt4`}],[`path`,{d:`M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2`,key:`v07s0e`}],[`line`,{x1:`10`,x2:`10`,y1:`11`,y2:`17`,key:`1uufr5`}],[`line`,{x1:`14`,x2:`14`,y1:`11`,y2:`17`,key:`xtxkd`}]]),h=r(t(),1),g=Object.defineProperty,_=(e,t)=>g(e,`name`,{value:t,configurable:!0});function v(e,[t,n]){return Math.min(n,Math.max(t,e))}_(v,`clamp`);var y=Object.defineProperty,b=(e,t)=>y(e,`name`,{value:t,configurable:!0}),x=!!(typeof window<`u`&&window.document&&window.document.createElement);function S(e,t,{checkForDefaultPrevented:n=!0}={}){return b(function(r){if(e?.(r),n===!1||!r||!r.defaultPrevented)return t?.(r)},`handleEvent`)}b(S,`composeEventHandlers`);function C(e){if(!x)throw Error(`Cannot access window outside of the DOM`);return e?.ownerDocument?.defaultView??window}b(C,`getOwnerWindow`);function w(e){if(!x)throw Error(`Cannot access document outside of the DOM`);return e?.ownerDocument??document}b(w,`getOwnerDocument`);function ee(e,t=!1){let{activeElement:n}=w(e);if(!n?.nodeName)return null;if(T(n)&&n.contentDocument)return ee(n.contentDocument.body,t);if(t){let e=n.getAttribute(`aria-activedescendant`);if(e){let t=w(n).getElementById(e);if(t)return t}}return n}b(ee,`getActiveElement`);function T(e){return e.tagName===`IFRAME`}b(T,`isFrame`);var te=Object.defineProperty,ne=(e,t)=>te(e,`name`,{value:t,configurable:!0});function E(e,t){if(typeof e==`function`)return e(t);e!=null&&(e.current=t)}ne(E,`setRef`);function D(...e){return t=>{let n=!1,r=e.map(e=>{let r=E(e,t);return!n&&typeof r==`function`&&(n=!0),r});if(n)return()=>{for(let t=0;t<r.length;t++){let n=r[t];typeof n==`function`?n():E(e[t],null)}}}}ne(D,`composeRefs`);function O(...e){return h.useCallback(D(...e),e)}ne(O,`useComposedRefs`);var k=n(),A=Object.defineProperty,j=(e,t)=>A(e,`name`,{value:t,configurable:!0});function M(e,t){let n=h.createContext(t);n.displayName=e+`Context`;let r=j(e=>{let{children:t,...r}=e,i=h.useMemo(()=>r,Object.values(r));return(0,k.jsx)(n.Provider,{value:i,children:t})},`Provider`);r.displayName=e+`Provider`;function i(r,i={}){let{optional:a=!1}=i,o=h.useContext(n);if(o)return o;if(t!==void 0)return t;if(!a)throw Error(`\`${r}\` must be used within \`${e}\``)}return j(i,`useContext`),[r,i]}j(M,`createContext`);function N(e,t=[]){let n=[];function r(t,r){let i=h.createContext(r);i.displayName=t+`Context`;let a=n.length;n=[...n,r];let o=j(t=>{let{scope:n,children:r,...o}=t,s=n?.[e]?.[a]||i,c=h.useMemo(()=>o,Object.values(o));return(0,k.jsx)(s.Provider,{value:c,children:r})},`Provider`);o.displayName=t+`Provider`;function s(n,o,s={}){let{optional:c=!1}=s,l=o?.[e]?.[a]||i,u=h.useContext(l);if(u)return u;if(r!==void 0)return r;if(!c)throw Error(`\`${n}\` must be used within \`${t}\``)}return j(s,`useContext`),[o,s]}j(r,`createContext`);let i=j(()=>{let t=n.map(e=>h.createContext(e));return j(function(n){let r=n?.[e]||t;return h.useMemo(()=>({[`__scope${e}`]:{...n,[e]:r}}),[n,r])},`useScope`)},`createScope`);return i.scopeName=e,[r,re(i,...t)]}j(N,`createContextScope`);function re(...e){let t=e[0];if(e.length===1)return t;let n=j(()=>{let n=e.map(e=>({useScope:e(),scopeName:e.scopeName}));return j(function(e){let r=n.reduce((t,{useScope:n,scopeName:r})=>{let i=n(e)[`__scope${r}`];return{...t,...i}},{});return h.useMemo(()=>({[`__scope${t.scopeName}`]:r}),[r])},`useComposedScopes`)},`createScope`);return n.scopeName=t.scopeName,n}j(re,`composeContextScopes`);var P=globalThis?.document?h.useLayoutEffect:()=>{},F=Object.defineProperty,I=(e,t)=>F(e,`name`,{value:t,configurable:!0}),ie=h.useEffectEvent,ae=h.useInsertionEffect;function oe(e){if(typeof ie==`function`)return ie(e);let t=h.useRef(()=>{throw Error(`Cannot call an event handler while rendering.`)});return typeof ae==`function`?ae(()=>{t.current=e}):P(()=>{t.current=e}),h.useMemo(()=>((...e)=>t.current?.(...e)),[])}I(oe,`useEffectEvent`);var se=Object.defineProperty,L=(e,t)=>se(e,`name`,{value:t,configurable:!0}),ce=h.useInsertionEffect||P;function le({prop:e,defaultProp:t,onChange:n=L(()=>{},`onChange`),caller:r}){let[i,a,o]=ue({defaultProp:t,onChange:n}),s=e!==void 0;return[s?e:i,h.useCallback(t=>{if(s){let n=de(t)?t(e):t;n!==e&&o.current?.(n)}else a(t)},[s,e,a,o])]}L(le,`useControllableState`);function ue({defaultProp:e,onChange:t}){let[n,r]=h.useState(e),i=h.useRef(n),a=h.useRef(t);return ce(()=>{a.current=t},[t]),h.useEffect(()=>{i.current!==n&&(a.current?.(n),i.current=n)},[n,i]),[n,r,a]}L(ue,`useUncontrolledState`);function de(e){return typeof e==`function`}L(de,`isFunction`);var fe=Symbol(`RADIX:SYNC_STATE`);function pe(e,t,n,r){let{prop:i,defaultProp:a,onChange:o,caller:s}=t,c=i!==void 0,l=oe(o),u=[{...n,state:a}];r&&u.push(r);let[d,f]=h.useReducer((t,n)=>{if(n.type===fe)return{...t,state:n.state};let r=e(t,n);return c&&!Object.is(r.state,t.state)&&l(r.state),r},...u),p=d.state,m=h.useRef(p);h.useEffect(()=>{m.current!==p&&(m.current=p,c||l(p))},[p,m,c]);let g=h.useMemo(()=>i===void 0?d:{...d,state:i},[d,i]);return h.useEffect(()=>{c&&!Object.is(i,d.state)&&f({type:fe,state:i})},[i,d.state,c]),[g,f]}L(pe,`useControllableStateReducer`);var me=Object.defineProperty,he=(e,t)=>me(e,`name`,{value:t,configurable:!0}),ge=h.createContext(void 0);function _e(e){let t=h.useContext(ge);return e||t||`ltr`}he(_e,`useDirection`);var ve=Object.defineProperty,ye=(e,t)=>ve(e,`name`,{value:t,configurable:!0});function R(e){let t=h.useRef({value:e,previous:e});return h.useMemo(()=>(t.current.value!==e&&(t.current.previous=t.current.value,t.current.value=e),t.current.previous),[e])}ye(R,`usePrevious`);var z=Object.defineProperty,B=(e,t)=>z(e,`name`,{value:t,configurable:!0});function be(e){let[t,n]=h.useState(void 0);return P(()=>{if(e){n({width:e.offsetWidth,height:e.offsetHeight});let t=new ResizeObserver(t=>{if(!Array.isArray(t)||!t.length)return;let r=t[0],i,a;if(`borderBoxSize`in r){let e=r.borderBoxSize,t=Array.isArray(e)?e[0]:e;i=t.inlineSize,a=t.blockSize}else i=e.offsetWidth,a=e.offsetHeight;n({width:i,height:a})});return t.observe(e,{box:`border-box`}),()=>t.unobserve(e)}n(void 0)},[e]),t}B(be,`useSize`);var xe=r(i(),1),Se=Object.defineProperty,V=(e,t)=>Se(e,`name`,{value:t,configurable:!0});function Ce(e){let t=h.forwardRef((t,n)=>{let{children:r,...i}=t,a=null,o=!1,s=[];H(r)&&typeof Ne==`function`&&(r=Ne(r._payload)),h.Children.forEach(r,e=>{if(ke(e)){o=!0;let t=e,n=`child`in t.props?t.props.child:t.props.children;H(n)&&typeof Ne==`function`&&(n=Ne(n._payload)),a=Ee(t,n),s.push(a?.props?.children)}else s.push(e)}),a?a=h.cloneElement(a,void 0,s):!o&&h.Children.count(r)===1&&h.isValidElement(r)&&(a=r);let c=a?Oe(a):void 0,l=O(n,c);if(!a){if(r||r===0)throw Error(o?Me(e):je(e));return r}let u=De(i,a.props??{});return a.type!==h.Fragment&&(u.ref=n?l:c),h.cloneElement(a,u)});return t.displayName=`${e}.Slot`,t}V(Ce,`createSlot`);var we=Symbol.for(`radix.slottable`);function Te(e){let t=V(e=>`child`in e?e.children(e.child):e.children,`Slottable`);return t.displayName=`${e}.Slottable`,t.__radixId=we,t}V(Te,`createSlottable`);var Ee=V((e,t)=>{if(`child`in e.props){let t=e.props.child;return h.isValidElement(t)?h.cloneElement(t,void 0,e.props.children(t.props.children)):null}return h.isValidElement(t)?t:null},`getSlottableElementFromSlottable`);function De(e,t){let n={...t};for(let r in t){let i=e[r],a=t[r];/^on[A-Z]/.test(r)?i&&a?n[r]=(...e)=>{let t=a(...e);return i(...e),t}:i&&(n[r]=i):r===`style`?n[r]={...i,...a}:r===`className`&&(n[r]=[i,a].filter(Boolean).join(` `))}return{...e,...n}}V(De,`mergeProps`);function Oe(e){let t=Object.getOwnPropertyDescriptor(e.props,`ref`)?.get,n=t&&`isReactWarning`in t&&t.isReactWarning;return n?e.ref:(t=Object.getOwnPropertyDescriptor(e,`ref`)?.get,n=t&&`isReactWarning`in t&&t.isReactWarning,n?e.props.ref:e.props.ref||e.ref)}V(Oe,`getElementRef`);function ke(e){return h.isValidElement(e)&&typeof e.type==`function`&&`__radixId`in e.type&&e.type.__radixId===we}V(ke,`isSlottable`);var Ae=Symbol.for(`react.lazy`);function H(e){return typeof e==`object`&&!!e&&`$$typeof`in e&&e.$$typeof===Ae&&`_payload`in e&&U(e._payload)}V(H,`isLazyComponent`);function U(e){return typeof e==`object`&&!!e&&`then`in e}V(U,`isPromiseLike`);var je=V(e=>`${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`,`createSlotError`),Me=V(e=>`${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`,`createSlottableError`),Ne=h.use,Pe=Object.defineProperty,W=(e,t)=>Pe(e,`name`,{value:t,configurable:!0}),G=[`a`,`button`,`div`,`form`,`h2`,`h3`,`img`,`input`,`label`,`li`,`nav`,`ol`,`p`,`select`,`span`,`svg`,`ul`].reduce((e,t)=>{let n=Ce(`Primitive.${t}`),r=h.forwardRef((e,r)=>{let{asChild:i,...a}=e,o=i?n:t;return typeof window<`u`&&(window[Symbol.for(`radix-ui`)]=!0),(0,k.jsx)(o,{...a,ref:r})});return r.displayName=`Primitive.${t}`,{...e,[t]:r}},{});function Fe(e,t){e&&xe.flushSync(()=>e.dispatchEvent(t))}W(Fe,`dispatchDiscreteCustomEvent`);var Ie=Object.defineProperty,K=(e,t)=>Ie(e,`name`,{value:t,configurable:!0});function q(e){let t=e+`CollectionProvider`,[n,r]=N(t),[i,a]=n(t,{collectionRef:{current:null},itemMap:new Map}),o=K(e=>{let{scope:t,children:n}=e,r=h.useRef(null),a=h.useRef(new Map).current;return(0,k.jsx)(i,{scope:t,itemMap:a,collectionRef:r,children:n})},`CollectionProvider`);o.displayName=t;let s=e+`CollectionSlot`,c=Ce(s),l=h.forwardRef((e,t)=>{let{scope:n,children:r}=e,i=O(t,a(s,n).collectionRef);return(0,k.jsx)(c,{ref:i,children:r})});l.displayName=s;let u=e+`CollectionItemSlot`,d=`data-radix-collection-item`,f=Ce(u),p=h.forwardRef((e,t)=>{let{scope:n,children:r,...i}=e,o=h.useRef(null),s=O(t,o),c=a(u,n);return h.useEffect(()=>(c.itemMap.set(o,{ref:o,...i}),()=>void c.itemMap.delete(o))),(0,k.jsx)(f,{[d]:``,ref:s,children:r})});p.displayName=u;function m(t){let n=a(e+`CollectionConsumer`,t);return h.useCallback(()=>{let e=n.collectionRef.current;if(!e)return[];let t=Array.from(e.querySelectorAll(`[${d}]`));return Array.from(n.itemMap.values()).sort((e,n)=>t.indexOf(e.ref.current)-t.indexOf(n.ref.current))},[n.collectionRef,n.itemMap])}return K(m,`useCollection`),[{Provider:o,Slot:l,ItemSlot:p},m,r]}K(q,`createCollection`);var Le=new WeakMap,J=class e extends Map{static{K(this,`OrderedDict`)}#e;constructor(e){super(e),this.#e=[...super.keys()],Le.set(this,!0)}set(e,t){return Le.get(this)&&(this.has(e)?this.#e[this.#e.indexOf(e)]=e:this.#e.push(e)),super.set(e,t),this}insert(e,t,n){let r=this.has(t),i=this.#e.length,a=Y(e),o=a>=0?a:i+a,s=o<0||o>=i?-1:o;if(s===this.size||r&&s===this.size-1||s===-1)return this.set(t,n),this;let c=this.size+ +!r;a<0&&o++;let l=[...this.#e],u,d=!1;for(let e=o;e<c;e++)if(o===e){let i=l[e];l[e]===t&&(i=l[e+1]),r&&this.delete(t),u=this.get(i),this.set(t,n)}else{!d&&l[e-1]===t&&(d=!0);let n=l[d?e:e-1],r=u;u=this.get(n),this.delete(n),this.set(n,r)}return this}with(t,n,r){let i=new e(this);return i.insert(t,n,r),i}before(e){let t=this.#e.indexOf(e)-1;if(!(t<0))return this.entryAt(t)}setBefore(e,t,n){let r=this.#e.indexOf(e);return r===-1?this:this.insert(r,t,n)}after(e){let t=this.#e.indexOf(e);if(t=t===-1||t===this.size-1?-1:t+1,t!==-1)return this.entryAt(t)}setAfter(e,t,n){let r=this.#e.indexOf(e);return r===-1?this:this.insert(r+1,t,n)}first(){return this.entryAt(0)}last(){return this.entryAt(-1)}clear(){return this.#e=[],super.clear()}delete(e){let t=super.delete(e);return t&&this.#e.splice(this.#e.indexOf(e),1),t}deleteAt(e){let t=this.keyAt(e);return t!==void 0&&this.delete(t)}at(e){let t=Re(this.#e,e);if(t!==void 0)return this.get(t)}entryAt(e){let t=Re(this.#e,e);if(t!==void 0)return[t,this.get(t)]}indexOf(e){return this.#e.indexOf(e)}keyAt(e){return Re(this.#e,e)}from(e,t){let n=this.indexOf(e);if(n===-1)return;let r=n+t;return r<0&&(r=0),r>=this.size&&(r=this.size-1),this.at(r)}keyFrom(e,t){let n=this.indexOf(e);if(n===-1)return;let r=n+t;return r<0&&(r=0),r>=this.size&&(r=this.size-1),this.keyAt(r)}find(e,t){let n=0;for(let r of this){if(Reflect.apply(e,t,[r,n,this]))return r;n++}}findIndex(e,t){let n=0;for(let r of this){if(Reflect.apply(e,t,[r,n,this]))return n;n++}return-1}filter(t,n){let r=[],i=0;for(let e of this)Reflect.apply(t,n,[e,i,this])&&r.push(e),i++;return new e(r)}map(t,n){let r=[],i=0;for(let e of this)r.push([e[0],Reflect.apply(t,n,[e,i,this])]),i++;return new e(r)}reduce(...e){let[t,n]=e,r=0,i=n??this.at(0);for(let n of this)i=r===0&&e.length===1?n:Reflect.apply(t,this,[i,n,r,this]),r++;return i}reduceRight(...e){let[t,n]=e,r=n??this.at(-1);for(let n=this.size-1;n>=0;n--){let i=this.at(n);r=n===this.size-1&&e.length===1?i:Reflect.apply(t,this,[r,i,n,this])}return r}toSorted(t){let n=[...this.entries()].sort(t);return new e(n)}toReversed(){let t=new e;for(let e=this.size-1;e>=0;e--){let n=this.keyAt(e),r=this.get(n);t.set(n,r)}return t}toSpliced(...t){let n=[...this.entries()];return n.splice(...t),new e(n)}slice(t,n){let r=new e,i=this.size-1;if(t===void 0)return r;t<0&&(t+=this.size),n!==void 0&&n>0&&(i=n-1);for(let e=t;e<=i;e++){let t=this.keyAt(e),n=this.get(t);r.set(t,n)}return r}every(e,t){let n=0;for(let r of this){if(!Reflect.apply(e,t,[r,n,this]))return!1;n++}return!0}some(e,t){let n=0;for(let r of this){if(Reflect.apply(e,t,[r,n,this]))return!0;n++}return!1}};function Re(e,t){if(`at`in Array.prototype)return Array.prototype.at.call(e,t);let n=ze(e,t);return n===-1?void 0:e[n]}K(Re,`at`);function ze(e,t){let n=e.length,r=Y(t),i=r>=0?r:n+r;return i<0||i>=n?-1:i}K(ze,`toSafeIndex`);function Y(e){return e!==e||e===0?0:Math.trunc(e)}K(Y,`toSafeInteger`);function Be(e){let t=e+`CollectionProvider`,[n,r]=N(t),[i,a]=n(t,{collectionElement:null,collectionRef:{current:null},collectionRefObject:{current:null},itemMap:new J,setItemMap:K(()=>void 0,`setItemMap`)}),o=K(({state:e,...t})=>e?(0,k.jsx)(c,{...t,state:e}):(0,k.jsx)(s,{...t}),`CollectionProvider`);o.displayName=t;let s=K(e=>{let t=g();return(0,k.jsx)(c,{...e,state:t})},`CollectionInit`);s.displayName=t+`Init`;let c=K(e=>{let{scope:t,children:n,state:r}=e,a=h.useRef(null),[o,s]=h.useState(null),c=O(a,s),[l,u]=r;return h.useEffect(()=>{if(!o)return;let e=We(()=>{});return e.observe(o,{childList:!0,subtree:!0}),()=>{e.disconnect()}},[o]),(0,k.jsx)(i,{scope:t,itemMap:l,setItemMap:u,collectionRef:c,collectionRefObject:a,collectionElement:o,children:n})},`CollectionProviderImpl`);c.displayName=t+`Impl`;let l=e+`CollectionSlot`,u=Ce(l),d=h.forwardRef((e,t)=>{let{scope:n,children:r}=e,i=O(t,a(l,n).collectionRef);return(0,k.jsx)(u,{ref:i,children:r})});d.displayName=l;let f=e+`CollectionItemSlot`,p=Ce(f),m=h.forwardRef((e,t)=>{let{scope:n,children:r,...i}=e,o=h.useRef(null),[s,c]=h.useState(null),l=O(t,o,c),{setItemMap:u}=a(f,n),d=h.useRef(i);Ve(d.current,i)||(d.current=i);let m=d.current;return h.useEffect(()=>{let e=m;return u(t=>s?t.has(s)?t.set(s,{...e,element:s}).toSorted(Ue):(t.set(s,{...e,element:s}),t.toSorted(Ue)):t),()=>{u(e=>!s||!e.has(s)?e:(e.delete(s),new J(e)))}},[s,m,u]),(0,k.jsx)(p,{"data-radix-collection-item":``,ref:l,children:r})});m.displayName=f;function g(){return h.useState(new J)}K(g,`useInitCollection`);function _(t){let{itemMap:n}=a(e+`CollectionConsumer`,t);return n}return K(_,`useCollection`),[{Provider:o,Slot:d,ItemSlot:m},{createCollectionScope:r,useCollection:_,useInitCollection:g}]}K(Be,`createCollection`);function Ve(e,t){if(e===t)return!0;if(typeof e!=`object`||typeof t!=`object`||e==null||t==null)return!1;let n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(let r of n)if(!Object.prototype.hasOwnProperty.call(t,r)||e[r]!==t[r])return!1;return!0}K(Ve,`shallowEqual`);function He(e,t){return!!(t.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_PRECEDING)}K(He,`isElementPreceding`);function Ue(e,t){return!e[1].element||!t[1].element?0:He(e[1].element,t[1].element)?-1:1}K(Ue,`sortByDocumentPosition`);function We(e){return new MutationObserver(t=>{for(let n of t)if(n.type===`childList`){e();return}})}K(We,`getChildListObserver`);var Ge=Object.defineProperty,X=(e,t)=>Ge(e,`name`,{value:t,configurable:!0}),Ke=[`PageUp`,`PageDown`],qe=[`ArrowUp`,`ArrowDown`,`ArrowLeft`,`ArrowRight`],Je={"from-left":[`Home`,`PageDown`,`ArrowDown`,`ArrowLeft`],"from-right":[`Home`,`PageDown`,`ArrowDown`,`ArrowRight`],"from-bottom":[`Home`,`PageDown`,`ArrowDown`,`ArrowLeft`],"from-top":[`Home`,`PageDown`,`ArrowUp`,`ArrowLeft`]},Ye=`Slider`,[Xe,Z,Ze]=q(Ye),[Qe,$e]=N(Ye,[Ze]),[et,Q]=Qe(Ye),tt=h.forwardRef(X(function(e,t){let{name:n,min:r=0,max:i=100,step:a=1,orientation:o=`horizontal`,disabled:s=!1,minStepsBetweenThumbs:c=0,defaultValue:l=[r],value:u,onValueChange:d=X(()=>{},`onValueChange`),onValueCommit:f=X(()=>{},`onValueCommit`),inverted:p=!1,form:m,...g}=e,_=h.useRef(new Set),y=h.useRef(0),b=h.useRef(!1),x=o===`horizontal`?it:at,[C,w]=h.useState(null),ee=O(t,w),[T=[],te]=le({prop:u,defaultProp:l,onChange:X(e=>{[..._.current][y.current]?.focus({preventScroll:!0,focusVisible:b.current}),b.current=!1,d(e)},`onChange`)}),ne=h.useRef(T),E=h.useRef(T);h.useEffect(()=>{let e=m?C?.ownerDocument.getElementById(m):C?.closest(`form`);if(e instanceof HTMLFormElement){let t=X(()=>te(E.current),`reset`);return e.addEventListener(`reset`,t),()=>e.removeEventListener(`reset`,t)}},[C,m,te]);function D(e){M(e,Ct(T,e))}X(D,`handleSlideStart`);function A(e){M(e,y.current)}X(A,`handleSlideMove`);function j(){String(T)!==String(ne.current)&&f(T)}X(j,`handleSlideEnd`);function M(e,t,{commit:n}={commit:!1}){let o=Ot(a),s=v(kt(Math.round((e-r)/a)*a+r,o),[r,i]);te((e=[])=>{let r=bt(e,s,t);if(Et(r,c*a)){y.current=r.indexOf(s);let t=String(r)!==String(e);return t&&n&&f(r),t?r:e}return e})}return X(M,`updateValues`),(0,k.jsx)(et,{scope:e.__scopeSlider,name:n,disabled:s,min:r,max:i,valueIndexToChangeRef:y,thumbs:_.current,values:T,orientation:o,form:m,children:(0,k.jsx)(Xe.Provider,{scope:e.__scopeSlider,children:(0,k.jsx)(Xe.Slot,{scope:e.__scopeSlider,children:(0,k.jsx)(x,{"aria-disabled":s,"data-disabled":s?``:void 0,...g,ref:ee,onPointerDown:S(g.onPointerDown,()=>{s||(ne.current=T,b.current=!1)}),min:r,max:i,inverted:p,onSlideStart:s?void 0:D,onSlideMove:s?void 0:A,onSlideEnd:s?void 0:j,onHomeKeyDown:()=>{s||(b.current=!0,M(r,0,{commit:!0}))},onEndKeyDown:()=>{s||(b.current=!0,M(i,T.length-1,{commit:!0}))},onStepKeyDown:({event:e,direction:t})=>{if(!s){b.current=!0;let n=Ke.includes(e.key)||e.shiftKey&&qe.includes(e.key)?10:1,i=y.current,o=T[i];M(At(o,{min:r,step:a,direction:t,multiplier:n}),i,{commit:!0})}}})})})})},`Slider`)),[nt,rt]=Qe(Ye,{startEdge:`left`,endEdge:`right`,size:`width`,direction:1}),it=h.forwardRef(X(function(e,t){let{min:n,max:r,dir:i,inverted:a,onSlideStart:o,onSlideMove:s,onSlideEnd:c,onStepKeyDown:l,...u}=e,[d,f]=h.useState(null),p=O(t,f),m=h.useRef(void 0),g=_e(i),_=g===`ltr`,v=_&&!a||!_&&a;function y(e){let t=m.current||d.getBoundingClientRect(),i=Dt([0,t.width],v?[n,r]:[r,n]);return m.current=t,i(e-t.left)}return X(y,`getValueFromPointer`),(0,k.jsx)(nt,{scope:e.__scopeSlider,startEdge:v?`left`:`right`,endEdge:v?`right`:`left`,direction:v?1:-1,size:`width`,children:(0,k.jsx)(ot,{dir:g,"data-orientation":`horizontal`,...u,ref:p,style:{...u.style,"--radix-slider-thumb-transform":`translateX(-50%)`},onSlideStart:e=>{let t=y(e.clientX);o?.(t)},onSlideMove:e=>{let t=y(e.clientX);s?.(t)},onSlideEnd:()=>{m.current=void 0,c?.()},onStepKeyDown:e=>{let t=Je[v?`from-left`:`from-right`].includes(e.key);l?.({event:e,direction:t?-1:1})}})})},`SliderHorizontal`)),at=h.forwardRef(X(function(e,t){let{min:n,max:r,inverted:i,onSlideStart:a,onSlideMove:o,onSlideEnd:s,onStepKeyDown:c,...l}=e,u=h.useRef(null),d=O(t,u),f=h.useRef(void 0),p=!i;function m(e){let t=f.current||u.current.getBoundingClientRect(),i=Dt([0,t.height],p?[r,n]:[n,r]);return f.current=t,i(e-t.top)}return X(m,`getValueFromPointer`),(0,k.jsx)(nt,{scope:e.__scopeSlider,startEdge:p?`bottom`:`top`,endEdge:p?`top`:`bottom`,size:`height`,direction:p?1:-1,children:(0,k.jsx)(ot,{"data-orientation":`vertical`,...l,ref:d,style:{...l.style,"--radix-slider-thumb-transform":`translateY(50%)`},onSlideStart:e=>{let t=m(e.clientY);a?.(t)},onSlideMove:e=>{let t=m(e.clientY);o?.(t)},onSlideEnd:()=>{f.current=void 0,s?.()},onStepKeyDown:e=>{let t=Je[p?`from-bottom`:`from-top`].includes(e.key);c?.({event:e,direction:t?-1:1})}})})},`SliderVertical`)),ot=h.forwardRef(X(function(e,t){let{__scopeSlider:n,onSlideStart:r,onSlideMove:i,onSlideEnd:a,onHomeKeyDown:o,onEndKeyDown:s,onStepKeyDown:c,...l}=e,u=Q(Ye,n);return(0,k.jsx)(G.span,{...l,ref:t,onKeyDown:S(e.onKeyDown,e=>{e.key===`Home`?(o(e),e.preventDefault()):e.key===`End`?(s(e),e.preventDefault()):Ke.concat(qe).includes(e.key)&&(c(e),e.preventDefault())}),onPointerDown:S(e.onPointerDown,e=>{let t=e.target;t.setPointerCapture(e.pointerId),e.preventDefault(),u.thumbs.has(t)?t.focus({preventScroll:!0,focusVisible:!1}):r(e)}),onPointerMove:S(e.onPointerMove,e=>{e.target.hasPointerCapture(e.pointerId)&&i(e)}),onPointerUp:S(e.onPointerUp,e=>{let t=e.target;t.hasPointerCapture(e.pointerId)&&(t.releasePointerCapture(e.pointerId),a(e))})})},`SliderImpl`)),st=`SliderTrack`,ct=h.forwardRef(X(function(e,t){let{__scopeSlider:n,...r}=e,i=Q(st,n);return(0,k.jsx)(G.span,{"data-disabled":i.disabled?``:void 0,"data-orientation":i.orientation,...r,ref:t})},`SliderTrack`)),lt=`SliderRange`,ut=h.forwardRef(X(function(e,t){let{__scopeSlider:n,...r}=e,i=Q(lt,n),a=rt(lt,n),o=O(t,h.useRef(null)),s=i.values.length,c=i.values.map(e=>xt(e,i.min,i.max)),l=s>1?Math.min(...c):0,u=100-Math.max(...c);return(0,k.jsx)(G.span,{"data-orientation":i.orientation,"data-disabled":i.disabled?``:void 0,...r,ref:o,style:{...e.style,[a.startEdge]:l+`%`,[a.endEdge]:u+`%`}})},`SliderRange`)),[dt,ft]=Qe(`SliderThumb`),pt=`SliderThumbProvider`;function mt(e){let{__scopeSlider:t,name:n,children:r,internal_do_not_use_render:i}=e,a=Q(pt,t),o=Z(t),[s,c]=h.useState(null),l=h.useMemo(()=>s?o().findIndex(e=>e.ref.current===s):-1,[o,s]),u=be(s),d=!s||!!a.form||!!s.closest(`form`),f=a.values[l],p=n??(a.name?a.name+(a.values.length>1?`[]`:``):void 0),m=f===void 0?0:xt(f,a.min,a.max);h.useEffect(()=>{if(s)return a.thumbs.add(s),()=>{a.thumbs.delete(s)}},[s,a.thumbs]);let g={value:f,name:p,form:a.form,isFormControl:d,index:l,thumb:s,onThumbChange:c,percent:m,size:u};return(0,k.jsx)(dt,{scope:t,...g,children:jt(i)?i(g):r})}X(mt,`SliderThumbProvider`);var ht=`SliderThumbTrigger`,gt=h.forwardRef(X(function(e,t){let{__scopeSlider:n,...r}=e,i=Q(ht,n),a=rt(ht,n),{index:o,value:s,percent:c,size:l,onThumbChange:u}=ft(ht,n),d=O(t,u),f=St(o,i.values.length),p=l?.[a.size],m=p?wt(p,c,a.direction):0;return(0,k.jsx)(`span`,{style:{transform:`var(--radix-slider-thumb-transform)`,position:`absolute`,[a.startEdge]:`calc(${c}% + ${m}px)`},children:(0,k.jsx)(Xe.ItemSlot,{scope:n,children:(0,k.jsx)(G.span,{role:`slider`,"aria-label":e[`aria-label`]||f,"aria-valuemin":i.min,"aria-valuenow":s,"aria-valuemax":i.max,"aria-orientation":i.orientation,"data-orientation":i.orientation,"data-disabled":i.disabled?``:void 0,tabIndex:i.disabled?void 0:0,...r,ref:d,style:s===void 0?{display:`none`}:e.style,onFocus:S(e.onFocus,()=>{i.valueIndexToChangeRef.current=o})})})})},`SliderThumbTrigger`)),_t=h.forwardRef(X(function(e,t){let{__scopeSlider:n,name:r,...i}=e;return(0,k.jsx)(mt,{__scopeSlider:n,name:r,internal_do_not_use_render:({index:e,isFormControl:r})=>(0,k.jsxs)(k.Fragment,{children:[(0,k.jsx)(gt,{...i,ref:t,__scopeSlider:n}),r?(0,k.jsx)(yt,{__scopeSlider:n},e):null]})})},`SliderThumb`)),vt=`SliderBubbleInput`,yt=h.forwardRef(X(function({__scopeSlider:e,...t},n){let{value:r,name:i,form:a}=ft(vt,e),o=h.useRef(null),s=O(o,n),c=R(r);return h.useEffect(()=>{let e=o.current;if(!e)return;let t=window.HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(t,`value`).set;if(c!==r&&n){let t=new Event(`input`,{bubbles:!0});n.call(e,r),e.dispatchEvent(t)}},[c,r]),(0,k.jsx)(G.input,{style:{display:`none`},name:i,form:a,...t,ref:s,defaultValue:r})},`SliderBubbleInput`));function bt(e=[],t,n){let r=[...e];return r[n]=t,r.sort((e,t)=>e-t)}X(bt,`getNextSortedValues`);function xt(e,t,n){return v(100/(n-t)*(e-t),[0,100])}X(xt,`convertValueToPercentage`);function St(e,t){if(t>2)return`Value ${e+1} of ${t}`;if(t===2)return[`Minimum`,`Maximum`][e]}X(St,`getLabel`);function Ct(e,t){if(e.length===1)return 0;let n=e.map(e=>Math.abs(e-t)),r=Math.min(...n);return n.indexOf(r)}X(Ct,`getClosestValueIndex`);function wt(e,t,n){let r=e/2;return(r-Dt([0,50],[0,r])(t)*n)*n}X(wt,`getThumbInBoundsOffset`);function Tt(e){return e.slice(0,-1).map((t,n)=>e[n+1]-t)}X(Tt,`getStepsBetweenValues`);function Et(e,t){if(t>0){let n=Tt(e);return Math.min(...n)>=t}return!0}X(Et,`hasMinStepsBetweenValues`);function Dt(e,t){return n=>{if(e[0]===e[1]||t[0]===t[1])return t[0];let r=(t[1]-t[0])/(e[1]-e[0]);return t[0]+r*(n-e[0])}}X(Dt,`linearScale`);function Ot(e){if(!Number.isFinite(e))return 0;let t=e.toString();if(t.includes(`e`)){let[e,n]=t.split(`e`),r=e.split(`.`)[1]||``,i=Number(n);return Math.max(0,r.length-i)}let n=t.split(`.`)[1];return n?n.length:0}X(Ot,`getDecimalCount`);function kt(e,t){let n=10**t;return Math.round(e*n)/n}X(kt,`roundValue`);function At(e,{min:t,step:n,direction:r,multiplier:i}){let a=Ot(n),o=(e-t)/n,s=Math.round(o),c=kt(s*n+t,a)===kt(e,a),l;return l=c?s+i*r:r>0?Math.ceil(o):Math.floor(o),kt(l*n+t,a)}X(At,`getNextStepValue`);function jt(e){return typeof e==`function`}X(jt,`isFunction`);var Mt=Object.defineProperty,Nt=(e,t)=>Mt(e,`name`,{value:t,configurable:!0}),Pt=`Switch`,[Ft,It]=N(Pt),[Lt,Rt]=Ft(Pt);function zt(e){let{__scopeSwitch:t,checked:n,children:r,defaultChecked:i,disabled:a,form:o,name:s,onCheckedChange:c,required:l,value:u=`on`,internal_do_not_use_render:d}=e,[f,p]=le({prop:n,defaultProp:i??!1,onChange:c,caller:Pt}),[m,g]=h.useState(null),[_,v]=h.useState(null),y=h.useRef(!1),[b,x]=h.useReducer(e=>e+1,0),S={checked:f,setChecked:p,disabled:a,control:m,setControl:g,name:s,form:o,value:u,hasConsumerStoppedPropagationRef:y,userInteractionCount:b,onUserInteraction:x,required:l,defaultChecked:i,isFormControl:!m||!!o||!!m.closest(`form`),bubbleInput:_,setBubbleInput:v};return(0,k.jsx)(Lt,{scope:t,...S,children:qt(d)?d(S):r})}Nt(zt,`SwitchProvider`);var Bt=`SwitchTrigger`,Vt=h.forwardRef(Nt(function({__scopeSwitch:e,onClick:t,...n},r){let{control:i,form:a,value:o,disabled:s,checked:c,required:l,setControl:u,setChecked:d,hasConsumerStoppedPropagationRef:f,onUserInteraction:p,isFormControl:m,bubbleInput:g}=Rt(Bt,e),_=O(r,u),v=h.useRef(c);return h.useEffect(()=>{let e=a?i?.ownerDocument.getElementById(a):i?.form;if(e instanceof HTMLFormElement){let t=Nt(()=>d(v.current),`reset`);return e.addEventListener(`reset`,t),()=>e.removeEventListener(`reset`,t)}},[i,a,d]),(0,k.jsx)(G.button,{type:`button`,role:`switch`,"aria-checked":c,"aria-required":l,"data-state":Jt(c),"data-disabled":s?``:void 0,disabled:s,value:o,...n,ref:_,onClick:S(t,e=>{p(),d(e=>!e),g&&m&&(f.current=e.isPropagationStopped(),f.current||e.stopPropagation())})})},`SwitchTrigger`)),Ht=h.forwardRef(Nt(function(e,t){let{__scopeSwitch:n,name:r,checked:i,defaultChecked:a,required:o,disabled:s,value:c,onCheckedChange:l,form:u,...d}=e;return(0,k.jsx)(zt,{__scopeSwitch:n,checked:i,defaultChecked:a,disabled:s,required:o,onCheckedChange:l,name:r,form:u,value:c,internal_do_not_use_render:({isFormControl:e})=>(0,k.jsxs)(k.Fragment,{children:[(0,k.jsx)(Vt,{...d,ref:t,__scopeSwitch:n}),e&&(0,k.jsx)(Kt,{__scopeSwitch:n})]})})},`Switch`)),Ut=`SwitchThumb`,Wt=h.forwardRef(Nt(function(e,t){let{__scopeSwitch:n,...r}=e,i=Rt(Ut,n);return(0,k.jsx)(G.span,{"data-state":Jt(i.checked),"data-disabled":i.disabled?``:void 0,...r,ref:t})},`SwitchThumb`)),Gt=`SwitchBubbleInput`,Kt=h.forwardRef(Nt(function({__scopeSwitch:e,onClick:t,...n},r){let{control:i,hasConsumerStoppedPropagationRef:a,userInteractionCount:o,checked:s,defaultChecked:c,required:l,disabled:u,name:d,value:f,form:p,bubbleInput:m,setBubbleInput:g}=Rt(Gt,e),_=O(r,g),v=be(i),y=h.useRef(!1),b=h.useRef(s),x=h.useRef(o);h.useEffect(()=>{let e=m;if(!e)return;let t=window.HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(t,`checked`).set,r=o!==x.current;x.current=o;let i=b.current!==s;b.current=s;let c=!(r&&a.current);if(i&&n){y.current=!r;let t=new Event(`click`,{bubbles:c});n.call(e,s),e.dispatchEvent(t),y.current=!1}},[m,s,a,o]);let C=h.useRef(s);return(0,k.jsx)(G.input,{type:`checkbox`,"aria-hidden":!0,defaultChecked:c??C.current,required:l,disabled:u,name:d,value:f,form:p,...n,tabIndex:-1,ref:_,onClick:S(t,e=>{y.current&&e.stopPropagation()}),style:{...n.style,...v,position:`absolute`,pointerEvents:`none`,opacity:0,margin:0,transform:`translateX(-100%)`}})},`SwitchBubbleInput`));function qt(e){return typeof e==`function`}Nt(qt,`isFunction`);function Jt(e){return e?`checked`:`unchecked`}Nt(Jt,`getState`);var Yt=`Move.Loadk.LoadBool.LoadNil.GetUpval.GetGlobal.GetTable.SetGlobal.SetUpval.SetTable.NewTable.Self.Add.Sub.Mul.Div.Mod.Pow.Unm.Not.Len.Concat.Jmp.Eq.Lt.Le.Test.TestSet.Call.TailCall.Return.ForLoop.ForPrep.TForLoop.SetList.Close.Closure.VarArg.Junk.Super`.split(`.`),Xt={Move:`ABC`,Loadk:`ABx`,LoadBool:`ABC`,LoadNil:`ABC`,GetUpval:`ABC`,GetGlobal:`ABx`,GetTable:`ABC`,SetGlobal:`ABx`,SetUpval:`ABC`,SetTable:`ABC`,NewTable:`ABC`,Self:`ABC`,Add:`ABC`,Sub:`ABC`,Mul:`ABC`,Div:`ABC`,Mod:`ABC`,Pow:`ABC`,Unm:`ABC`,Not:`ABC`,Len:`ABC`,Concat:`ABC`,Jmp:`AsBx`,Eq:`ABC`,Lt:`ABC`,Le:`ABC`,Test:`ABC`,TestSet:`ABC`,Call:`ABC`,TailCall:`ABC`,Return:`ABC`,ForLoop:`AsBx`,ForPrep:`AsBx`,TForLoop:`ABC`,SetList:`ABC`,Close:`ABC`,Closure:`ABx`,VarArg:`ABC`,Junk:`DATA`,Super:`DATA`};function Zt(e,t=0,n=0,r=0){return{op:e,a:t,b:n,c:r,target:null,junk:!1,bind:!1,superOps:null}}var Qt=new Set([`Jmp`,`ForLoop`,`ForPrep`]);function $t(e){e.instructions.forEach((e,t)=>{Qt.has(e.op)&&e.target==null&&(e.target=t+e.b+1)}),e.prototypes.forEach($t)}function en(e){let t=e.instructions;for(let n=0;n<t.length;n++){if(t[n].op!==`Closure`)continue;let r=e.prototypes[t[n].b]?.upvalCount??0;for(let e=1;e<=r;e++)t[n+e]&&(t[n+e].bind=!0)}e.prototypes.forEach(en)}function tn(e){let t=e.instructions;for(let e=0;e<t.length;e++)t[e].target!=null&&(t[e].b=t[e].target-e-1);e.prototypes.forEach(tn)}var nn=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]);function rn(e,t){return e>>>t|e<<32-t}function an(e){let t=e.length*8,n=e.length+1,r=(64-(n+8)%64)%64,i=new Uint8Array(n+r+8);i.set(e),i[e.length]=128;let a=new DataView(i.buffer),o=Math.floor(t/2**32);a.setUint32(i.length-8,o,!1),a.setUint32(i.length-4,t>>>0,!1);let s=1779033703,c=3144134277,l=1013904242,u=2773480762,d=1359893119,f=2600822924,p=528734635,m=1541459225,h=new Uint32Array(64);for(let e=0;e<i.length;e+=64){for(let t=0;t<16;t++)h[t]=a.getUint32(e+t*4,!1);for(let e=16;e<64;e++){let t=rn(h[e-15],7)^rn(h[e-15],18)^h[e-15]>>>3,n=rn(h[e-2],17)^rn(h[e-2],19)^h[e-2]>>>10;h[e]=h[e-16]+t+h[e-7]+n>>>0}let t=s,n=c,r=l,i=u,o=d,g=f,_=p,v=m;for(let e=0;e<64;e++){let a=rn(o,6)^rn(o,11)^rn(o,25),s=o&g^~o&_,c=v+a+s+nn[e]+h[e]>>>0,l=(rn(t,2)^rn(t,13)^rn(t,22))+(t&n^t&r^n&r)>>>0;v=_,_=g,g=o,o=i+c>>>0,i=r,r=n,n=t,t=c+l>>>0}s=s+t>>>0,c=c+n>>>0,l=l+r>>>0,u=u+i>>>0,d=d+o>>>0,f=f+g>>>0,p=p+_>>>0,m=m+v>>>0}let g=new Uint8Array(32),_=new DataView(g.buffer);return[s,c,l,u,d,f,p,m].forEach((e,t)=>_.setUint32(t*4,e,!1)),g}var on=new Uint8Array([67,72,76,79,86,49,52,0]);function $(e){let t=new Uint8Array(4);return new DataView(t.buffer).setUint32(0,e>>>0,!0),t}function sn(e){let t=0;for(let n of e)t+=n.length;let n=new Uint8Array(t),r=0;for(let t of e)n.set(t,r),r+=t.length;return n}function cn(e,t,n){let r=new Uint8Array(e.length);for(let i=0;i<e.length;i++)r[i]=e[i]^t[(i+n)%t.length];return r}function ln(e,t){let n=0;for(let[r,i]of Object.entries(e)){let e=2**i.Length-1,a=Math.trunc(t[r]??0),o=a<0?a+2**i.Length&e:a&e;n+=o*2**i.Start}return n>>>0}function un(e){let t=new Uint8Array(8);return new DataView(t.buffer).setFloat64(0,e,!0),t}function dn(e,t){let n=fn(e,t,Uint8Array.from(t.Key));return sn([on,new Uint8Array([14,1]),$(t.Seed),$(n.length),n,an(n)])}function fn(e,t,n){let r={UpvalCount:new Uint8Array([e.upvalCount&255]),ParameterCount:new Uint8Array([e.parameterCount&255]),VarargCount:new Uint8Array([e.varargCount&255]),Constants:pn(e,t,n),Instructions:hn(e,t),Prototypes:gn(e,t,n)},i=[$(t.ChunkStructure.length)];for(let e of t.ChunkStructure){let t=new TextEncoder().encode(e),n=r[e];i.push(new Uint8Array([t.length]),t,$(n.length),n)}return sn(i)}function pn(e,t,n){let r=[$(e.constants.length)];return e.constants.forEach((e,i)=>{if(r.push(new Uint8Array([t.ConstantTags[e.type]&255])),e.type===`Nil`)return;if(e.type===`Boolean`){r.push(new Uint8Array([+!!e.data]));return}if(e.type===`Number`){let t=un(Number(e.data));r.push($(8),cn(t,n,i));return}let a=new TextEncoder().encode(String(e.data)),o=Math.max(1,i*7%4+1),s=[];for(let e=0;e<a.length;e+=o)s.push(a.subarray(e,e+o));r.push($(s.length)),s.forEach((e,t)=>{let a=cn(e,n,i+t);r.push($(a.length),a)})}),sn(r)}function mn(e,t,n){let r=Xt[e.op],i=t.Registers[r]??t.Registers.ABC,a=r===`ABC`?0:r===`ABx`?1:r===`AsBx`?2:3;return $(ln(i,{A:e.a,B:e.b,C:e.c,Mode:a,Enum:n&7}))}function hn(e,t){let n=[$(e.instructions.length)];for(let r of e.instructions){let e=t.OpcodeMap[r.op];if(n.push($(e),mn(r,t,e),new Uint8Array([+!!r.junk])),r.op===`Super`){let e=r.superOps??[];n.push($(e.length));for(let r of e){let e=t.OpcodeMap[r.op];n.push($(e),mn({op:r.op,a:r.a,b:r.b,c:r.c},t,e))}}}return sn(n)}function gn(e,t,n){let r=[$(e.prototypes.length)];for(let i of e.prototypes){let e=fn(i,t,n);r.push($(e.length),e)}return sn(r)}var _n=e(((e,t)=>{(function(n,r,i){var a={function:!0,object:!0},o=a[typeof e]&&e&&!e.nodeType&&e,s=a[typeof t]&&t&&!t.nodeType&&t,c=o&&s&&typeof global==`object`&&global,l=s&&s.exports===o&&o;c&&(c.global===c||c.window===c||c.self===c)&&(n=c),typeof define==`function`&&typeof define.amd==`object`&&define.amd?(define([`exports`],i),o&&l&&i(s.exports)):i(o&&s?l?s.exports:o:n[r]={})})(e,`luaparse`,function(e){e.version=`0.3.1`;var t,n,r,i,a,o=e.defaultOptions={wait:!1,comments:!0,scope:!1,locations:!1,ranges:!1,onCreateNode:null,onCreateScope:null,onDestroyScope:null,onLocalDeclaration:null,luaVersion:`5.1`,encodingMode:`none`};function s(e,t){return t||=0,e<128?String.fromCharCode(e):e<2048?String.fromCharCode(t|192|e>>6,t|128|e&63):e<65536?String.fromCharCode(t|224|e>>12,t|128|e>>6&63,t|128|e&63):e<1114112?String.fromCharCode(t|240|e>>18,t|128|e>>12&63,t|128|e>>6&63,t|128|e&63):null}function c(e,t){for(var n=e.toString(16);n.length<t;)n=`0`+n;return n}function l(e){return function(t){var n=e.exec(t);if(!n)return t;E(null,b.invalidCodeUnit,c(n[0].charCodeAt(0),4).toUpperCase())}}var u={"pseudo-latin1":{fixup:l(/[^\x00-\xff]/),encodeByte:function(e){return e===null?``:String.fromCharCode(e)},encodeUTF8:function(e){return s(e)}},"x-user-defined":{fixup:l(/[^\x00-\x7f\uf780-\uf7ff]/),encodeByte:function(e){return e===null?``:e>=128?String.fromCharCode(e|63232):String.fromCharCode(e)},encodeUTF8:function(e){return s(e,63232)}},none:{discardStrings:!0,fixup:function(e){return e},encodeByte:function(e){return``},encodeUTF8:function(e){return``}}},d=1,f=2,p=4,m=8,h=16,g=32,_=64,v=128,y=256;e.tokenTypes={EOF:d,StringLiteral:f,Keyword:p,Identifier:m,NumericLiteral:h,Punctuator:g,BooleanLiteral:_,NilLiteral:v,VarargLiteral:y};var b=e.errors={unexpected:`unexpected %1 '%2' near '%3'`,unexpectedEOF:`unexpected symbol near '<eof>'`,expected:`'%1' expected near '%2'`,expectedToken:`%1 expected near '%2'`,unfinishedString:`unfinished string near '%1'`,malformedNumber:`malformed number near '%1'`,decimalEscapeTooLarge:`decimal escape too large near '%1'`,invalidEscape:`invalid escape sequence near '%1'`,hexadecimalDigitExpected:`hexadecimal digit expected near '%1'`,braceExpected:`missing '%1' near '%2'`,tooLargeCodepoint:`UTF-8 value too large near '%1'`,unfinishedLongString:`unfinished long string (starting at line %1) near '%2'`,unfinishedLongComment:`unfinished long comment (starting at line %1) near '%2'`,ambiguousSyntax:`ambiguous syntax (function call x new statement) near '%1'`,noLoopToBreak:`no loop to break near '%1'`,labelAlreadyDefined:`label '%1' already defined on line %2`,labelNotVisible:`no visible label '%1' for <goto>`,gotoJumpInLocalScope:`<goto %1> jumps into the scope of local '%2'`,cannotUseVararg:`cannot use '...' outside a vararg function near '%1'`,invalidCodeUnit:`code unit U+%1 is not allowed in the current encoding mode`},x=e.ast={labelStatement:function(e){return{type:`LabelStatement`,label:e}},breakStatement:function(){return{type:`BreakStatement`}},gotoStatement:function(e){return{type:`GotoStatement`,label:e}},returnStatement:function(e){return{type:`ReturnStatement`,arguments:e}},ifStatement:function(e){return{type:`IfStatement`,clauses:e}},ifClause:function(e,t){return{type:`IfClause`,condition:e,body:t}},elseifClause:function(e,t){return{type:`ElseifClause`,condition:e,body:t}},elseClause:function(e){return{type:`ElseClause`,body:e}},whileStatement:function(e,t){return{type:`WhileStatement`,condition:e,body:t}},doStatement:function(e){return{type:`DoStatement`,body:e}},repeatStatement:function(e,t){return{type:`RepeatStatement`,condition:e,body:t}},localStatement:function(e,t){return{type:`LocalStatement`,variables:e,init:t}},assignmentStatement:function(e,t){return{type:`AssignmentStatement`,variables:e,init:t}},callStatement:function(e){return{type:`CallStatement`,expression:e}},functionStatement:function(e,t,n,r){return{type:`FunctionDeclaration`,identifier:e,isLocal:n,parameters:t,body:r}},forNumericStatement:function(e,t,n,r,i){return{type:`ForNumericStatement`,variable:e,start:t,end:n,step:r,body:i}},forGenericStatement:function(e,t,n){return{type:`ForGenericStatement`,variables:e,iterators:t,body:n}},chunk:function(e){return{type:`Chunk`,body:e}},identifier:function(e){return{type:`Identifier`,name:e}},literal:function(e,t,n){return e=e===f?`StringLiteral`:e===h?`NumericLiteral`:e===_?`BooleanLiteral`:e===v?`NilLiteral`:`VarargLiteral`,{type:e,value:t,raw:n}},tableKey:function(e,t){return{type:`TableKey`,key:e,value:t}},tableKeyString:function(e,t){return{type:`TableKeyString`,key:e,value:t}},tableValue:function(e){return{type:`TableValue`,value:e}},tableConstructorExpression:function(e){return{type:`TableConstructorExpression`,fields:e}},binaryExpression:function(e,t,n){return{type:e===`and`||e===`or`?`LogicalExpression`:`BinaryExpression`,operator:e,left:t,right:n}},unaryExpression:function(e,t){return{type:`UnaryExpression`,operator:e,argument:t}},memberExpression:function(e,t,n){return{type:`MemberExpression`,indexer:t,identifier:n,base:e}},indexExpression:function(e,t){return{type:`IndexExpression`,base:e,index:t}},callExpression:function(e,t){return{type:`CallExpression`,base:e,arguments:t}},tableCallExpression:function(e,t){return{type:`TableCallExpression`,base:e,arguments:t}},stringCallExpression:function(e,t){return{type:`StringCallExpression`,base:e,argument:t}},comment:function(e,t){return{type:`Comment`,value:e,raw:t}}};function S(e){if(G){var t=W.pop();t.complete(),t.bless(e)}return n.onCreateNode&&n.onCreateNode(e),e}var C=Array.prototype.slice,w=function(e,t){for(var n=0,r=e.length;n<r;++n)if(e[n]===t)return n;return-1};Array.prototype.indexOf&&(w=function(e,t){return e.indexOf(t)});function ee(e,t,n){for(var r=0,i=e.length;r<i;++r)if(e[r][t]===n)return r;return-1}function T(e){var t=C.call(arguments,1);return e=e.replace(/%(\d)/g,function(e,n){return``+t[n-1]||``}),e}var te=function(e){for(var t=C.call(arguments,1),n,r,i=0,a=t.length;i<a;++i)for(r in n=t[i],n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r]);return e};Object.assign&&(te=Object.assign),e.SyntaxError=SyntaxError;function ne(e){return Object.create?Object.create(e,{line:{writable:!0,value:e.line},index:{writable:!0,value:e.index},column:{writable:!0,value:e.column}}):e}function E(e){var t=T.apply(null,C.call(arguments,1)),n,r;throw e===null||e.line===void 0?(r=A-I+1,n=ne(SyntaxError(T(`[%1:%2] %3`,F,r,t))),n.index=A,n.line=F,n.column=r):(r=e.range[0]-e.lineStart,n=ne(SyntaxError(T(`[%1:%2] %3`,e.line,r,t))),n.line=e.line,n.index=e.range[0],n.column=r),n}function D(e){return t.slice(e.range[0],e.range[1])||e.value}function O(e,t){E(t,b.expectedToken,e,D(t))}function k(e){var t=D(N);if(e.type!==void 0){var n;switch(e.type){case f:n=`string`;break;case p:n=`keyword`;break;case m:n=`identifier`;break;case h:n=`number`;break;case g:n=`symbol`;break;case _:n=`boolean`;break;case v:return E(e,b.unexpected,`symbol`,`nil`,t);case d:return E(e,b.unexpectedEOF)}return E(e,b.unexpected,n,D(e),t)}return E(e,b.unexpected,`symbol`,e,t)}var A,j,M,N,re,P,F,I;e.lex=ie;function ie(){for(oe();t.charCodeAt(A)===45&&t.charCodeAt(A+1)===45;)ve(),oe();if(A>=r)return{type:d,value:`<eof>`,line:F,lineStart:I,range:[A,A]};var e=t.charCodeAt(A),n=t.charCodeAt(A+1);if(P=A,Ce(e))return se();switch(e){case 39:case 34:return le();case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:return de();case 46:return Se(n)?de():n===46?t.charCodeAt(A+2)===46?ce():L(`..`):L(`.`);case 61:return L(n===61?`==`:`=`);case 62:return i.bitwiseOperators&&n===62?L(`>>`):L(n===61?`>=`:`>`);case 60:return i.bitwiseOperators&&n===60?L(`<<`):L(n===61?`<=`:`<`);case 126:if(n===61)return L(`~=`);if(!i.bitwiseOperators)break;return L(`~`);case 58:return i.labels&&n===58?L(`::`):L(`:`);case 91:return n===91||n===61?ue():L(`[`);case 47:return i.integerDivision&&n===47?L(`//`):L(`/`);case 38:case 124:if(!i.bitwiseOperators)break;case 42:case 94:case 37:case 44:case 123:case 125:case 93:case 40:case 41:case 59:case 35:case 45:case 43:return L(t.charAt(A))}return k(t.charAt(A))}function ae(){var e=t.charCodeAt(A),n=t.charCodeAt(A+1);return xe(e)?(e===10&&n===13&&++A,e===13&&n===10&&++A,++F,I=++A,!0):!1}function oe(){for(;A<r;)if(be(t.charCodeAt(A)))++A;else if(!ae())break}function se(){for(var e,n;we(t.charCodeAt(++A)););return e=a.fixup(t.slice(P,A)),Te(e)?n=p:e===`true`||e===`false`?(n=_,e=e===`true`):e===`nil`?(n=v,e=null):n=m,{type:n,value:e,line:F,lineStart:I,range:[P,A]}}function L(e){return A+=e.length,{type:g,value:e,line:F,lineStart:I,range:[P,A]}}function ce(){return A+=3,{type:y,value:`...`,line:F,lineStart:I,range:[P,A]}}function le(){for(var e=t.charCodeAt(A++),n=F,i=I,o=A,s=a.discardStrings?null:``,c;c=t.charCodeAt(A++),e!==c;)if((A>r||xe(c))&&(s+=t.slice(o,A-1),E(null,b.unfinishedString,t.slice(P,A-1))),c===92){if(!a.discardStrings){var l=t.slice(o,A-1);s+=a.fixup(l)}var u=_e();a.discardStrings||(s+=u),o=A}return a.discardStrings||(s+=a.encodeByte(null),s+=a.fixup(t.slice(o,A-1))),{type:f,value:s,line:n,lineStart:i,lastLine:F,lastLineStart:I,range:[P,A]}}function ue(){var e=F,t=I,n=ye(!1);return!1===n&&E(j,b.expected,`[`,D(j)),{type:f,value:a.discardStrings?null:a.fixup(n),line:e,lineStart:t,lastLine:F,lastLineStart:I,range:[P,A]}}function de(){var e=t.charAt(A),n=t.charAt(A+1),r=e===`0`&&`xX`.indexOf(n||null)>=0?me():he(),i=fe();return pe()&&(i||r.hasFractionPart)&&E(null,b.malformedNumber,t.slice(P,A)),{type:h,value:r.value,line:F,lineStart:I,range:[P,A]}}function fe(){if(i.imaginaryNumbers)return`iI`.indexOf(t.charAt(A)||null)>=0&&(++A,!0)}function pe(){if(i.integerSuffixes){if(`uU`.indexOf(t.charAt(A)||null)>=0){if(++A,`lL`.indexOf(t.charAt(A)||null)>=0){if(++A,`lL`.indexOf(t.charAt(A)||null)>=0)return++A,`ULL`;E(null,b.malformedNumber,t.slice(P,A))}else E(null,b.malformedNumber,t.slice(P,A))}else if(`lL`.indexOf(t.charAt(A)||null)>=0){if(++A,`lL`.indexOf(t.charAt(A)||null)>=0)return++A,`LL`;E(null,b.malformedNumber,t.slice(P,A))}}}function me(){var e=0,n=1,r=1,i,a,o,s=A+=2;for(V(t.charCodeAt(A))||E(null,b.malformedNumber,t.slice(P,A));V(t.charCodeAt(A));)++A;i=parseInt(t.slice(s,A),16);var c=!1;if(t.charAt(A)===`.`){for(c=!0,a=++A;V(t.charCodeAt(A));)++A;e=t.slice(a,A),e=a===A?0:parseInt(e,16)/16**(A-a)}var l=!1;if(`pP`.indexOf(t.charAt(A)||null)>=0){for(l=!0,++A,`+-`.indexOf(t.charAt(A)||null)>=0&&(r=t.charAt(A++)===`+`?1:-1),o=A,Se(t.charCodeAt(A))||E(null,b.malformedNumber,t.slice(P,A));Se(t.charCodeAt(A));)++A;n=t.slice(o,A),n=2**(n*r)}return{value:(i+e)*n,hasFractionPart:c||l}}function he(){for(;Se(t.charCodeAt(A));)++A;var e=!1;if(t.charAt(A)===`.`)for(e=!0,++A;Se(t.charCodeAt(A));)++A;var n=!1;if(`eE`.indexOf(t.charAt(A)||null)>=0)for(n=!0,++A,`+-`.indexOf(t.charAt(A)||null)>=0&&++A,Se(t.charCodeAt(A))||E(null,b.malformedNumber,t.slice(P,A));Se(t.charCodeAt(A));)++A;return{value:parseFloat(t.slice(P,A)),hasFractionPart:e||n}}function ge(){var e=A++;for(t.charAt(A++)!==`{`&&E(null,b.braceExpected,`{`,`\\`+t.slice(e,A)),V(t.charCodeAt(A))||E(null,b.hexadecimalDigitExpected,`\\`+t.slice(e,A));t.charCodeAt(A)===48;)++A;for(var n=A;V(t.charCodeAt(A));)++A,A-n>6&&E(null,b.tooLargeCodepoint,`\\`+t.slice(e,A));var r=t.charAt(A++);r!==`}`&&(r===`"`||r===`'`?E(null,b.braceExpected,`}`,`\\`+t.slice(e,A--)):E(null,b.hexadecimalDigitExpected,`\\`+t.slice(e,A)));var i=parseInt(t.slice(n,A-1)||`0`,16),o=`\\`+t.slice(e,A);return i>1114111&&E(null,b.tooLargeCodepoint,o),a.encodeUTF8(i,o)}function _e(){var e=A;switch(t.charAt(A)){case`a`:return++A,`\x07`;case`n`:return++A,`
`;case`r`:return++A,`\r`;case`t`:return++A,`	`;case`v`:return++A,`\v`;case`b`:return++A,`\b`;case`f`:return++A,`\f`;case`\r`:case`
`:return ae(),`
`;case`0`:case`1`:case`2`:case`3`:case`4`:case`5`:case`6`:case`7`:case`8`:case`9`:for(;Se(t.charCodeAt(A))&&A-e<3;)++A;var n=t.slice(e,A),r=parseInt(n,10);return r>255&&E(null,b.decimalEscapeTooLarge,`\\`+r),a.encodeByte(r,`\\`+n);case`z`:if(i.skipWhitespaceEscape)return++A,oe(),``;break;case`x`:if(i.hexEscapes){if(V(t.charCodeAt(A+1))&&V(t.charCodeAt(A+2)))return A+=3,a.encodeByte(parseInt(t.slice(e+1,A),16),`\\`+t.slice(e,A));E(null,b.hexadecimalDigitExpected,`\\`+t.slice(e,A+2))}break;case`u`:if(i.unicodeEscapes)return ge();break;case`\\`:case`"`:case`'`:return t.charAt(A++)}return i.strictEscapes&&E(null,b.invalidEscape,`\\`+t.slice(e,A+1)),t.charAt(A++)}function ve(){P=A,A+=2;var e=t.charAt(A),i=``,a=!1,o=A,s=I,c=F;if(e===`[`&&(i=ye(!0),!1===i?i=e:a=!0),!a){for(;A<r&&!xe(t.charCodeAt(A));)++A;n.comments&&(i=t.slice(o,A))}if(n.comments){var l=x.comment(i,t.slice(P,A));n.locations&&(l.loc={start:{line:c,column:P-s},end:{line:F,column:A-I}}),n.ranges&&(l.range=[P,A]),n.onCreateNode&&n.onCreateNode(l),re.push(l)}}function ye(e){var n=0,i=``,a=!1,o,s,c=F;for(++A;t.charAt(A+n)===`=`;)++n;if(t.charAt(A+n)!==`[`)return!1;for(A+=n+1,xe(t.charCodeAt(A))&&ae(),s=A;A<r;){for(;xe(t.charCodeAt(A));)ae();if(o=t.charAt(A++),o===`]`){a=!0;for(var l=0;l<n;++l)t.charAt(A+l)!==`=`&&(a=!1);t.charAt(A+n)!==`]`&&(a=!1)}if(a)return i+=t.slice(s,A-1),A+=n+1,i}E(null,e?b.unfinishedLongComment:b.unfinishedLongString,c,`<eof>`)}function R(){M=j,j=N,N=ie()}function z(e){return e===j.value&&(R(),!0)}function B(e){e===j.value?R():E(j,b.expected,e,D(j))}function be(e){return e===9||e===32||e===11||e===12}function xe(e){return e===10||e===13}function Se(e){return e>=48&&e<=57}function V(e){return e>=48&&e<=57||e>=97&&e<=102||e>=65&&e<=70}function Ce(e){return!!(e>=65&&e<=90||e>=97&&e<=122||e===95||i.extendedIdentifiers&&e>=128)}function we(e){return!!(e>=65&&e<=90||e>=97&&e<=122||e===95||e>=48&&e<=57||i.extendedIdentifiers&&e>=128)}function Te(e){switch(e.length){case 2:return e===`do`||e===`if`||e===`in`||e===`or`;case 3:return e===`and`||e===`end`||e===`for`||e===`not`;case 4:return e===`else`||e===`then`?!0:i.labels&&!i.contextualGoto?e===`goto`:!1;case 5:return e===`break`||e===`local`||e===`until`||e===`while`;case 6:return e===`elseif`||e===`repeat`||e===`return`;case 8:return e===`function`}return!1}function Ee(e){return g===e.type?`#-~`.indexOf(e.value)>=0:p===e.type&&e.value===`not`}function De(e){if(d===e.type)return!0;if(p!==e.type)return!1;switch(e.value){case`else`:case`elseif`:case`end`:case`until`:return!0;default:return!1}}var Oe,ke,Ae;function H(){var e=Oe[ke++].slice();Oe.push(e),n.onCreateScope&&n.onCreateScope()}function U(){Oe.pop(),--ke,n.onDestroyScope&&n.onDestroyScope()}function je(e){n.onLocalDeclaration&&n.onLocalDeclaration(e),w(Oe[ke],e)===-1&&Oe[ke].push(e)}function Me(e){je(e.name),Ne(e,!0)}function Ne(e,t){!t&&ee(Ae,`name`,e.name)===-1&&Ae.push(e),e.isLocal=t}function Pe(e){return w(Oe[ke],e)!==-1}var W=[],G;function Fe(){return new Ie(j)}function Ie(e){n.locations&&(this.loc={start:{line:e.line,column:e.range[0]-e.lineStart},end:{line:0,column:0}}),n.ranges&&(this.range=[e.range[0],0])}Ie.prototype.complete=function(){n.locations&&(this.loc.end.line=M.lastLine||M.line,this.loc.end.column=M.range[1]-(M.lastLineStart||M.lineStart)),n.ranges&&(this.range[1]=M.range[1])},Ie.prototype.bless=function(e){if(this.loc){var t=this.loc;e.loc={start:{line:t.start.line,column:t.start.column},end:{line:t.end.line,column:t.end.column}}}this.range&&(e.range=[this.range[0],this.range[1]])};function K(){G&&W.push(Fe())}function q(e){G&&W.push(e)}function Le(){this.scopes=[],this.pendingGotos=[]}Le.prototype.isInLoop=function(){for(var e=this.scopes.length;e-->0;)if(this.scopes[e].isLoop)return!0;return!1},Le.prototype.pushScope=function(e){var t={labels:{},locals:[],deferredGotos:[],isLoop:!!e};this.scopes.push(t)},Le.prototype.popScope=function(){for(var e=0;e<this.pendingGotos.length;++e){var t=this.pendingGotos[e];t.maxDepth>=this.scopes.length&&--t.maxDepth<=0&&E(t.token,b.labelNotVisible,t.target)}this.scopes.pop()},Le.prototype.addGoto=function(e,t){for(var n=[],r=0;r<this.scopes.length;++r){var i=this.scopes[r];if(n.push(i.locals.length),Object.prototype.hasOwnProperty.call(i.labels,e))return}this.pendingGotos.push({maxDepth:this.scopes.length,target:e,token:t,localCounts:n})},Le.prototype.addLabel=function(e,t){var n=this.currentScope();if(Object.prototype.hasOwnProperty.call(n.labels,e))E(t,b.labelAlreadyDefined,e,n.labels[e].line);else{for(var r=[],i=0;i<this.pendingGotos.length;++i){var a=this.pendingGotos[i];if(a.maxDepth>=this.scopes.length&&a.target===e){a.localCounts[this.scopes.length-1]<n.locals.length&&n.deferredGotos.push(a);continue}r.push(a)}this.pendingGotos=r}n.labels[e]={localCount:n.locals.length,line:t.line}},Le.prototype.addLocal=function(e,t){this.currentScope().locals.push({name:e,token:t})},Le.prototype.currentScope=function(){return this.scopes[this.scopes.length-1]},Le.prototype.raiseDeferredErrors=function(){for(var e=this.currentScope(),t=e.deferredGotos,n=0;n<t.length;++n){var r=t[n];E(r.token,b.gotoJumpInLocalScope,r.target,e.locals[r.localCounts[this.scopes.length-1]].name)}};function J(){this.level=0,this.loopLevels=[]}J.prototype.isInLoop=function(){return!!this.loopLevels.length},J.prototype.pushScope=function(e){++this.level,e&&this.loopLevels.push(this.level)},J.prototype.popScope=function(){var e=this.loopLevels,t=e.length;t&&e[t-1]===this.level&&e.pop(),--this.level},J.prototype.addGoto=J.prototype.addLabel=function(){throw Error(`This should never happen`)},J.prototype.addLocal=J.prototype.raiseDeferredErrors=function(){};function Re(){return i.labels?new Le:new J}function ze(){R(),K(),n.scope&&H();var e=Re();e.allowVararg=!0,e.pushScope();var t=Y(e);return e.popScope(),n.scope&&U(),d!==j.type&&k(j),G&&!t.length&&(M=j),S(x.chunk(t))}function Y(e){for(var t=[],n;!De(j);){if(j.value===`return`||!i.relaxedBreak&&j.value===`break`){t.push(Be(e));break}n=Be(e),z(`;`),n&&t.push(n)}return t}function Be(e){if(K(),g===j.type&&z(`::`))return Ve(e);if(i.emptyStatement&&z(`;`)){G&&W.pop();return}if(e.raiseDeferredErrors(),p===j.type)switch(j.value){case`local`:return R(),Ye(e);case`if`:return R(),qe(e);case`return`:return R(),Ke(e);case`function`:return R(),Ze(Qe());case`while`:return R(),Ge(e);case`for`:return R(),Je(e);case`repeat`:return R(),X(e);case`break`:return R(),e.isInLoop()||E(j,b.noLoopToBreak,j.value),He();case`do`:return R(),We(e);case`goto`:return R(),Ue(e)}return i.contextualGoto&&j.type===m&&j.value===`goto`&&N.type===m&&N.value!==`goto`?(R(),Ue(e)):(G&&W.pop(),Xe(e))}function Ve(e){var t=j,r=Z();return n.scope&&(je(`::`+t.value+`::`),Ne(r,!0)),B(`::`),e.addLabel(t.value,t),S(x.labelStatement(r))}function He(){return S(x.breakStatement())}function Ue(e){var t=j.value,n=M,r=Z();return e.addGoto(t,n),S(x.gotoStatement(r))}function We(e){n.scope&&H(),e.pushScope();var t=Y(e);return e.popScope(),n.scope&&U(),B(`end`),S(x.doStatement(t))}function Ge(e){var t=Q(e);B(`do`),n.scope&&H(),e.pushScope(!0);var r=Y(e);return e.popScope(),n.scope&&U(),B(`end`),S(x.whileStatement(t,r))}function X(e){n.scope&&H(),e.pushScope(!0);var t=Y(e);B(`until`),e.raiseDeferredErrors();var r=Q(e);return e.popScope(),n.scope&&U(),S(x.repeatStatement(r,t))}function Ke(e){var t=[];if(j.value!==`end`){var n=et(e);for(n!=null&&t.push(n);z(`,`);)n=Q(e),t.push(n);z(`;`)}return S(x.returnStatement(t))}function qe(e){var t=[],r,i,a;for(G&&(a=W[W.length-1],W.push(a)),r=Q(e),B(`then`),n.scope&&H(),e.pushScope(),i=Y(e),e.popScope(),n.scope&&U(),t.push(S(x.ifClause(r,i))),G&&(a=Fe());z(`elseif`);)q(a),r=Q(e),B(`then`),n.scope&&H(),e.pushScope(),i=Y(e),e.popScope(),n.scope&&U(),t.push(S(x.elseifClause(r,i))),G&&(a=Fe());return z(`else`)&&(G&&(a=new Ie(M),W.push(a)),n.scope&&H(),e.pushScope(),i=Y(e),e.popScope(),n.scope&&U(),t.push(S(x.elseClause(i)))),B(`end`),S(x.ifStatement(t))}function Je(e){var t=Z(),r;if(n.scope&&(H(),Me(t)),z(`=`)){var i=Q(e);B(`,`);var a=Q(e),o=z(`,`)?Q(e):null;return B(`do`),e.pushScope(!0),r=Y(e),e.popScope(),B(`end`),n.scope&&U(),S(x.forNumericStatement(t,i,a,o,r))}for(var s=[t];z(`,`);)t=Z(),n.scope&&Me(t),s.push(t);B(`in`);var c=[];do{var l=Q(e);c.push(l)}while(z(`,`));return B(`do`),e.pushScope(!0),r=Y(e),e.popScope(),B(`end`),n.scope&&U(),S(x.forGenericStatement(s,c,r))}function Ye(e){var t,r=M;if(m===j.type){var i=[],a=[];do t=Z(),i.push(t),e.addLocal(t.name,r);while(z(`,`));if(z(`=`))do{var o=Q(e);a.push(o)}while(z(`,`));if(n.scope)for(var s=0,c=i.length;s<c;++s)Me(i[s]);return S(x.localStatement(i,a))}if(z(`function`))return t=Z(),e.addLocal(t.name,r),n.scope&&(Me(t),H()),Ze(t,!0);O(`<name>`,j)}function Xe(e){var t,r,i,a,o,s=[];G&&(r=Fe());do{if(G&&(t=Fe()),m===j.type)o=j.value,a=Z(),n.scope&&Ne(a,Pe(o)),i=!0;else if(j.value===`(`)R(),a=Q(e),B(`)`),i=!1;else return k(j);both:for(;;){switch(f===j.type?`"`:j.value){case`.`:case`[`:i=!0;break;case`:`:case`(`:case`{`:case`"`:i=null;break;default:break both}a=rt(a,t,e)}if(s.push(a),j.value!==`,`)break;if(!i)return k(j);R()}while(1);if(s.length===1&&i===null)return q(t),S(x.callStatement(s[0]));if(!i)return k(j);B(`=`);var c=[];do c.push(Q(e));while(z(`,`));return q(r),S(x.assignmentStatement(s,c))}function Z(){K();var e=j.value;return m!==j.type&&O(`<name>`,j),R(),S(x.identifier(e))}function Ze(e,t){var r=Re();r.pushScope();var i=[];if(B(`(`),!z(`)`))for(;;){if(m===j.type){var a=Z();if(n.scope&&Me(a),i.push(a),z(`,`))continue}else y===j.type?(r.allowVararg=!0,i.push(ot(r))):O(`<name> or '...'`,j);B(`)`);break}var o=Y(r);return r.popScope(),B(`end`),n.scope&&U(),t||=!1,S(x.functionStatement(e,i,t,o))}function Qe(){var e,t,r;for(G&&(r=Fe()),e=Z(),n.scope&&(Ne(e,Pe(e.name)),H());z(`.`);)q(r),t=Z(),e=S(x.memberExpression(e,`.`,t));return z(`:`)&&(q(r),t=Z(),e=S(x.memberExpression(e,`:`,t)),n.scope&&je(`self`)),e}function $e(e){for(var t=[],n,r;;){if(K(),g===j.type&&z(`[`))n=Q(e),B(`]`),B(`=`),r=Q(e),t.push(S(x.tableKey(n,r)));else if(m===j.type)N.value===`=`?(n=Z(),R(),r=Q(e),t.push(S(x.tableKeyString(n,r)))):(r=Q(e),t.push(S(x.tableValue(r))));else{if((r=et(e))==null){W.pop();break}t.push(S(x.tableValue(r)))}if(`,;`.indexOf(j.value)>=0){R();continue}break}return B(`}`),S(x.tableConstructorExpression(t))}function et(e){return nt(0,e)}function Q(e){var t=et(e);if(t==null)O(`<expression>`,j);else return t}function tt(e){var t=e.charCodeAt(0),n=e.length;if(n===1)switch(t){case 94:return 12;case 42:case 47:case 37:return 10;case 43:case 45:return 9;case 38:return 6;case 126:return 5;case 124:return 4;case 60:case 62:return 3}else if(n===2)switch(t){case 47:return 10;case 46:return 8;case 60:case 62:return e===`<<`||e===`>>`?7:3;case 61:case 126:return 3;case 111:return 1}else if(t===97&&e===`and`)return 2;return 0}function nt(e,t){var n=j.value,r,i;if(G&&(i=Fe()),Ee(j)){K(),R();var a=nt(10,t);a??O(`<expression>`,j),r=S(x.unaryExpression(n,a))}if(r??(r=ot(t),r??=it(t)),r==null)return null;for(var o;n=j.value,o=g===j.type||p===j.type?tt(n):0,!(o===0||o<=e);){(n===`^`||n===`..`)&&--o,R();var s=nt(o,t);s??O(`<expression>`,j),G&&W.push(i),r=S(x.binaryExpression(n,r,s))}return r}function rt(e,t,n){var r,i;if(g===j.type)switch(j.value){case`[`:return q(t),R(),r=Q(n),B(`]`),S(x.indexExpression(e,r));case`.`:return q(t),R(),i=Z(),S(x.memberExpression(e,`.`,i));case`:`:return q(t),R(),i=Z(),e=S(x.memberExpression(e,`:`,i)),q(t),at(e,n);case`(`:case`{`:return q(t),at(e,n)}else if(f===j.type)return q(t),at(e,n);return null}function it(e){var t,r,i;if(G&&(i=Fe()),m===j.type)r=j.value,t=Z(),n.scope&&Ne(t,Pe(r));else if(z(`(`))t=Q(e),B(`)`);else return null;for(;;){var a=rt(t,i,e);if(a===null)break;t=a}return t}function at(e,t){if(g===j.type)switch(j.value){case`(`:i.emptyStatement||j.line!==M.line&&E(null,b.ambiguousSyntax,j.value),R();var n=[],r=et(t);for(r!=null&&n.push(r);z(`,`);)r=Q(t),n.push(r);return B(`)`),S(x.callExpression(e,n));case`{`:K(),R();var a=$e(t);return S(x.tableCallExpression(e,a))}else if(f===j.type)return S(x.stringCallExpression(e,ot(t)));O(`function arguments`,j)}function ot(e){var r=f|h|_|v|y,i=j.value,a=j.type,o;if(G&&(o=Fe()),a===y&&!e.allowVararg&&E(j,b.cannotUseVararg,j.value),a&r){q(o);var s=t.slice(j.range[0],j.range[1]);return R(),S(x.literal(a,i,s))}if(p===a&&i===`function`)return q(o),R(),n.scope&&H(),Ze(null);if(z(`{`))return q(o),$e(e)}e.parse=ct;var st={"5.1":{},"5.2":{labels:!0,emptyStatement:!0,hexEscapes:!0,skipWhitespaceEscape:!0,strictEscapes:!0,relaxedBreak:!0},"5.3":{labels:!0,emptyStatement:!0,hexEscapes:!0,skipWhitespaceEscape:!0,strictEscapes:!0,unicodeEscapes:!0,bitwiseOperators:!0,integerDivision:!0,relaxedBreak:!0},LuaJIT:{labels:!0,contextualGoto:!0,hexEscapes:!0,skipWhitespaceEscape:!0,strictEscapes:!0,unicodeEscapes:!0,imaginaryNumbers:!0,integerSuffixes:!0}};function ct(s,c){if(c===void 0&&typeof s==`object`&&(c=s,s=void 0),c||={},t=s||``,n=te({},o,c),A=0,F=1,I=0,r=t.length,Oe=[[]],ke=0,Ae=[],W=[],!Object.prototype.hasOwnProperty.call(st,n.luaVersion))throw Error(T(`Lua version '%1' not supported`,n.luaVersion));if(i=te({},st[n.luaVersion]),n.extendedIdentifiers!==void 0&&(i.extendedIdentifiers=!!n.extendedIdentifiers),!Object.prototype.hasOwnProperty.call(u,n.encodingMode))throw Error(T(`Encoding mode '%1' not supported`,n.encodingMode));return a=u[n.encodingMode],n.comments&&(re=[]),n.wait?e:ut()}e.write=lt;function lt(n){return t+=String(n),r=t.length,e}e.end=ut;function ut(e){e!==void 0&&lt(e),t&&t.substr(0,2)===`#!`&&(t=t.replace(/^.*/,function(e){return e.replace(/./g,` `)})),r=t.length,G=n.locations||n.ranges,N=ie();var i=ze();if(n.comments&&(i.comments=re),n.scope&&(i.globals=Ae),W.length>0)throw Error(`Location tracking failed. This is most likely a bug in luaparse`);return i}})}))(),vn=class extends Error{constructor(e,t){super(t?`Línea ${t}: ${e}`:e),this.name=`CompileError`}},yn={"+":`Add`,"-":`Sub`,"*":`Mul`,"/":`Div`,"%":`Mod`,"^":`Pow`};function bn(e){return!!e&&(e.type===`CallExpression`||e.type===`StringCallExpression`||e.type===`TableCallExpression`)}function xn(e){if(e.startsWith(`[`)){let t=/^\[(=*)\[/.exec(e);if(!t)throw Error(`Cadena larga inválida`);let n=t[1],r=e.slice(t[0].length,e.length-(n.length+2));return r.startsWith(`\r
`)?r.slice(2):r.startsWith(`
`)||r.startsWith(`\r`)?r.slice(1):r}let t=1,n=``,r=e.length-1;for(;t<r;){if(e[t]!==`\\`){n+=e[t++];continue}t+=1;let r=e[t++]??``,i={a:`\x07`,b:`\b`,f:`\f`,n:`
`,r:`\r`,t:`	`,v:`\v`,"\\":`\\`,'"':`"`,"'":`'`};if(r in i){n+=i[r];continue}if(r!==`
`){if(r===`\r`){e[t]===`
`&&(t+=1);continue}if(r>=`0`&&r<=`9`){let i=r;for(let n=0;n<2&&e[t]>=`0`&&e[t]<=`9`;n++)i+=e[t++];n+=String.fromCharCode(Number(i)&255);continue}n+=r}}return n}var Sn=class e{parent;parameterCount;isVararg;name;instructions=[];constants=[];prototypes=[];locals=[];upvalues=[];nactvar=0;freereg=0;maxStack=2;keys=new Map;scopes=[];acts=[];loops=[];line=1;constructor(e,t,n,r){this.parent=e,this.parameterCount=t,this.isVararg=n,this.name=r}at(e){let t=e?.loc?.start?.line;return t&&(this.line=t),this.line}fail(e,t){throw new vn(t,this.at(e))}touch(e){e+1>this.maxStack&&(this.maxStack=e+1)}alloc(){this.freereg>=249&&this.fail(void 0,`La función usa demasiados registros`);let e=this.freereg++;return this.touch(e),e}emit(e,t=0,n=0,r=0){let i=Zt(e,t,n,r);return this.instructions.push(i),this.touch(t),i}addConst(e){let t=e.type===`Nil`?`Z`:e.type===`Boolean`?`B${+!!e.data}`:e.type===`Number`?`N${Object.is(e.data,-0)?`-0`:String(e.data)}`:`S${e.data}`,n=this.keys.get(t);if(n!=null)return n;let r=this.constants.length;return this.constants.push(e),this.keys.set(t,r),r}loadConst(e,t){let n=this.addConst(t);n>262143&&this.fail(void 0,`Demasiadas constantes`),this.emit(`Loadk`,e,n,0)}rkConst(e){let t=this.addConst(e);return t>255&&this.fail(void 0,`Demasiadas constantes en una sola expresión`),t+256}findLocal(e){for(let t=this.locals.length-1;t>=0;t--)if(this.locals[t].name===e)return this.locals[t]}capture(e){if(!this.parent)return null;let t=this.upvalues.findIndex(t=>t.name===e);if(t>=0)return t;let n=this.parent.findLocal(e);if(n)return n.captured=!0,this.upvalues.push({name:e,kind:`local`,index:n.reg}),this.upvalues.length-1;let r=this.parent.capture(e);return r==null?null:(this.upvalues.push({name:e,kind:`upval`,index:r}),this.upvalues.length-1)}pushLocal(e,t){this.locals.push({name:e,reg:t,captured:!1}),this.touch(t)}enter(){this.scopes.push(this.locals.length),this.acts.push(this.nactvar)}leave(){let e=this.scopes.pop()??0,t=this.acts.pop()??0,n=1/0;for(;this.locals.length>e;){let e=this.locals.pop();e.captured&&(n=Math.min(n,e.reg))}n!==1/0&&this.emit(`Close`,n,0,0),this.nactvar=t,this.freereg=this.nactvar}closeFrom(e){let t=1/0;for(let n=e;n<this.locals.length;n++)this.locals[n].captured&&(t=Math.min(t,this.locals[n].reg));t!==1/0&&this.emit(`Close`,t,0,0)}pin(e){this.freereg<e+1&&(this.freereg=e+1)}keep(e){let t=Math.max(this.nactvar,e+1);(this.freereg<t||e>=this.nactvar)&&(this.freereg=t)}expr(e,t){this.at(e);let n=t===void 0?this.alloc():t;switch(this.pin(n),e.type){case`NilLiteral`:this.loadConst(n,{type:`Nil`,data:null});break;case`BooleanLiteral`:this.loadConst(n,{type:`Boolean`,data:!!e.value});break;case`NumericLiteral`:this.loadConst(n,{type:`Number`,data:Number(e.value)});break;case`StringLiteral`:this.loadConst(n,{type:`String`,data:xn(String(e.raw??``))});break;case`VarargLiteral`:this.isVararg||this.fail(e,"`...` fuera de una función variádica"),this.emit(`VarArg`,n,2,0);break;case`Identifier`:this.identInto(String(e.name),n,e);break;case`UnaryExpression`:this.unary(e,n);break;case`BinaryExpression`:this.binary(e,n);break;case`LogicalExpression`:this.logical(e,n);break;case`MemberExpression`:case`IndexExpression`:this.indexInto(e,n);break;case`CallExpression`:case`StringCallExpression`:case`TableCallExpression`:this.compileCall(e,1,n,!1);break;case`TableConstructorExpression`:this.tableInto(e,n);break;case`FunctionDeclaration`:this.closureInto(n,e);break;default:this.fail(e,`Expresión no soportada (${e.type})`)}return this.keep(n),n}exprInto(e,t){let n=this.expr(e,t);n!==t&&this.emit(`Move`,t,n,0)}exprRK(e){return e.type===`NumericLiteral`?this.rkConst({type:`Number`,data:Number(e.value)}):e.type===`StringLiteral`?this.rkConst({type:`String`,data:xn(String(e.raw??``))}):e.type===`BooleanLiteral`?this.rkConst({type:`Boolean`,data:!!e.value}):e.type===`NilLiteral`?this.rkConst({type:`Nil`,data:null}):this.expr(e)}identInto(e,t,n){let r=this.findLocal(e);if(r){r.reg!==t&&this.emit(`Move`,t,r.reg,0);return}let i=this.capture(e);if(i!=null){this.emit(`GetUpval`,t,i,0);return}let a=this.addConst({type:`String`,data:e});this.emit(`GetGlobal`,t,a,0)}unary(e,t){let n=String(e.operator),r=e.argument;if(n===`not`){let e=this.expr(r);this.emit(`Not`,t,e,0);return}if(n===`-`){let e=this.expr(r);this.emit(`Unm`,t,e,0);return}if(n===`#`){let e=this.expr(r);this.emit(`Len`,t,e,0);return}this.fail(e,`Operador unario no soportado ${n}`)}binary(e,t){let n=String(e.operator);if(n===`..`){this.concatInto(e,t);return}if(n===`==`||n===`~=`||n===`<`||n===`>`||n===`<=`||n===`>=`){this.compare(e,t);return}let r=yn[n];r||this.fail(e,`Operador no soportado ${n}`);let i=e.left,a=e.right,o=this.exprRK(i),s=this.exprRK(a);this.emit(r,t,o,s)}compare(e,t){let n=this.exprRK(e.left),r=this.exprRK(e.right),i,a=0,o=String(e.operator);if(o===`==`)i=`Eq`;else if(o===`~=`)i=`Eq`,a=1;else if(o===`<`)i=`Lt`;else if(o===`>`){i=`Lt`;let e=n;n=r,r=e}else if(o===`<=`)i=`Le`;else{i=`Le`;let e=n;n=r,r=e}this.emit(i,a,n,r);let s=this.emit(`Jmp`);this.emit(`LoadBool`,t,1,1),s.target=this.instructions.length,this.emit(`LoadBool`,t,0,0)}concatInto(e,t){let n=[],r=e=>{e.type===`BinaryExpression`&&e.operator===`..`?(r(e.left),r(e.right)):n.push(e)};r(e);let i=Math.max(this.freereg,this.nactvar);for(let e=0;e<n.length;e++)this.freereg=Math.max(this.nactvar,i+e),this.exprInto(n[e],i+e),this.freereg=Math.max(this.nactvar,i+e+1);if(t>=i&&t<i+n.length){let e=i+n.length;this.emit(`Concat`,e,i,i+n.length-1),this.emit(`Move`,t,e,0)}else this.emit(`Concat`,t,i,i+n.length-1)}logical(e,t){let n=String(e.operator);this.exprInto(e.left,t),this.emit(`Test`,t,0,+(n===`and`));let r=this.emit(`Jmp`);this.freereg=Math.max(this.nactvar,t+1),this.exprInto(e.right,t),r.target=this.instructions.length}indexInto(e,t){if(e.type===`MemberExpression`){let n=this.expr(e.base),r=this.rkConst({type:`String`,data:String(e.identifier.name)});this.emit(`GetTable`,t,n,r);return}let n=this.expr(e.base),r=this.exprRK(e.index);this.emit(`GetTable`,t,n,r)}tableInto(e,t){this.emit(`NewTable`,t,0,0);let n=1,r=e.fields??[];for(let e of r){this.freereg=Math.max(this.nactvar,t+1);let r;r=e.type===`TableValue`?this.rkConst({type:`Number`,data:n++}):e.type===`TableKeyString`?this.rkConst({type:`String`,data:String(e.key.name)}):this.exprRK(e.key);let i=this.expr(e.value);this.emit(`SetTable`,t,r,i)}}callShape(e){if(e.type===`StringCallExpression`)return{callee:e.base,args:[e.argument],method:null};if(e.type===`TableCallExpression`)return{callee:e.base,args:[e.arguments],method:null};let t=e.base;return t?.type===`MemberExpression`&&t.indexer===`:`?{callee:t.base,args:e.arguments??[],method:String(t.identifier.name)}:{callee:t,args:e.arguments??[],method:null}}compileCall(e,t,n,r){this.at(e);let i=this.callShape(e);if(i.method){this.freereg=Math.max(this.freereg,this.nactvar,n+2),this.exprInto(i.callee,n+1);let e=this.rkConst({type:`String`,data:i.method});this.emit(`Self`,n,n+1,e)}else this.freereg=Math.max(this.freereg,this.nactvar,n+1),this.exprInto(i.callee,n);let a=i.method?2:1,o=0,s=!1;for(let e=0;e<i.args.length;e++){let t=i.args[e],r=n+a+o;if(t.type===`VarargLiteral`){e!==i.args.length-1&&this.fail(t,"`...` tiene que ser el último argumento"),this.isVararg||this.fail(t,"`...` fuera de una función variádica"),this.emit(`VarArg`,r,0,0),s=!0;break}this.freereg=Math.max(this.nactvar,r+1),this.exprInto(t,r),o+=1}let c=i.method?o+1:o,l=s?0:c+1,u=r?`TailCall`:`Call`,d=r||t<0?0:t+1;this.emit(u,n,l,d),this.freereg=t>0?Math.max(this.nactvar,n+t):Math.max(this.nactvar,n)}closureInto(t,n){let r=(n.parameters??[]).slice(),i=n.identifier;i&&i.type===`MemberExpression`&&i.indexer===`:`&&(r=[{type:`Identifier`,name:`self`},...r]);let a=new e(this,0,!1,this.name);a.compileFunction(r,n.body??[]);let o=a.finish(),s=this.prototypes.length;this.prototypes.push(o),this.emit(`Closure`,t,s,0);for(let e of a.upvalues){let t=this.emit(e.kind===`local`?`Move`:`GetUpval`,0,e.index,0);t.bind=!0}}compileFunction(e,t,n=!1){let r=!1,i=[];e.forEach((t,n)=>{if(t.type===`VarargLiteral`){n!==e.length-1&&this.fail(t,"`...` tiene que ser el último parámetro"),r=!0;return}t.type!==`Identifier`&&this.fail(t,`Parámetro no soportado`),i.push(String(t.name))}),this.isVararg=r||n,this.parameterCount=i.length,i.forEach((e,t)=>this.pushLocal(e,t)),this.nactvar=i.length,this.freereg=this.nactvar,this.block(t);let a=this.instructions[this.instructions.length-1];(!a||a.op!==`Return`&&a.op!==`TailCall`)&&this.emit(`Return`,0,1,0)}block(e){for(let t of e)this.stat(t)}stat(e){switch(this.at(e),e.type){case`LocalStatement`:this.localStat(e);return;case`AssignmentStatement`:this.assignStat(e);return;case`CallStatement`:this.compileCall(e.expression,0,this.freereg,!1),this.freereg=this.nactvar;return;case`ReturnStatement`:this.returnStat(e);return;case`FunctionDeclaration`:this.functionStat(e);return;case`DoStatement`:this.enter(),this.block(e.body),this.leave();return;case`IfStatement`:this.ifStat(e);return;case`WhileStatement`:this.whileStat(e);return;case`RepeatStatement`:this.repeatStat(e);return;case`ForNumericStatement`:this.numFor(e);return;case`ForGenericStatement`:this.genFor(e);return;case`BreakStatement`:this.breakStat(e);return;default:this.fail(e,`Sentencia no soportada (${e.type}). Lua 5.2+ (goto) no entra.`)}}localStat(e){let t=e.variables,n=e.init??[],r=this.nactvar,i=t.length;if(this.nactvar=r+i,this.freereg=this.nactvar,n.length===0)this.emit(`LoadNil`,r,r+i-1,0);else if(n.length===1&&bn(n[0])&&i>=1)this.compileCall(n[0],i,r,!1);else{let e=n[n.length-1],t=bn(e)&&n.length<i,a=t?n.length-1:Math.min(n.length,i);for(let e=0;e<a;e++)this.freereg=Math.max(this.nactvar,r+i),this.exprInto(n[e],r+e);t?(this.freereg=Math.max(this.nactvar,r+i),this.compileCall(e,i-(n.length-1),r+n.length-1,!1)):n.length<i&&this.emit(`LoadNil`,r+n.length,r+i-1,0)}t.forEach((e,t)=>this.pushLocal(String(e.name),r+t)),this.freereg=this.nactvar}prepLhs(e){if(e.type===`Identifier`){let t=String(e.name),n=this.findLocal(t);if(n)return{kind:`local`,reg:n.reg};let r=this.capture(t);return r==null?{kind:`global`,name:t}:{kind:`upval`,idx:r}}if(e.type===`MemberExpression`)return{kind:`index`,table:this.expr(e.base),key:this.rkConst({type:`String`,data:String(e.identifier.name)})};if(e.type===`IndexExpression`)return{kind:`index`,table:this.expr(e.base),key:this.exprRK(e.index)};this.fail(e,`Asignación no soportada`)}store(e,t){if(e.kind===`local`){e.reg!==t&&this.emit(`Move`,e.reg,t,0);return}if(e.kind===`upval`){this.emit(`SetUpval`,t,e.idx,0);return}if(e.kind===`global`){let n=this.addConst({type:`String`,data:e.name});this.emit(`SetGlobal`,t,n,0);return}this.emit(`SetTable`,e.table,e.key,t)}assignStat(e){let t=e.variables,n=e.init??[],r=t.map(e=>this.prepLhs(e)),i=this.freereg;if(n.length===1&&bn(n[0]))this.compileCall(n[0],t.length,i,!1);else{let e=n[n.length-1],r=bn(e)&&n.length<t.length&&n.length>0,a=r?n.length-1:Math.min(n.length,t.length);for(let e=0;e<a;e++)this.freereg=Math.max(i+t.length,this.nactvar),this.exprInto(n[e],i+e);r?this.compileCall(e,t.length-(n.length-1),i+n.length-1,!1):n.length<t.length&&this.emit(`LoadNil`,i+n.length,i+t.length-1,0)}for(let e=0;e<t.length;e++)this.store(r[e],i+e);this.freereg=this.nactvar}returnStat(e){let t=e.arguments??[];if(t.length===0){this.emit(`Return`,0,1,0);return}if(t.length===1&&bn(t[0])){this.compileCall(t[0],-1,this.nactvar,!0);return}if(t.length===1&&t[0].type===`VarargLiteral`){this.isVararg||this.fail(t[0],"`...` fuera de una función variádica"),this.emit(`VarArg`,this.nactvar,0,0),this.emit(`Return`,this.nactvar,0,0);return}let n=this.freereg,r=t[t.length-1];if(bn(r)&&t.length>1){for(let e=0;e<t.length-1;e++)this.freereg=n+e+1,this.exprInto(t[e],n+e);this.compileCall(r,-1,n+t.length-1,!1),this.emit(`Return`,n,0,0);return}for(let e=0;e<t.length;e++)this.freereg=n+e+1,this.exprInto(t[e],n+e);this.emit(`Return`,n,t.length+1,0)}functionStat(e){let t=e.identifier;if(e.isLocal){(!t||t.type!==`Identifier`)&&this.fail(e,`Función local inválida`);let n=this.nactvar++;this.freereg=this.nactvar,this.pushLocal(String(t.name),n),this.closureInto(n,e),this.freereg=this.nactvar;return}t||this.fail(e,`Función sin nombre`);let n=this.alloc();this.closureInto(n,e);let r=t.type===`MemberExpression`&&t.indexer===`:`?{...t,indexer:`.`}:t,i=this.prepLhs(r);this.store(i,n),this.freereg=this.nactvar}ifStat(e){let t=[],n=e.clauses;n.forEach((e,r)=>{let i=null;if(e.type!==`ElseClause`){let t=this.expr(e.condition);this.freereg=this.nactvar,this.emit(`Test`,t,0,1),i=this.emit(`Jmp`)}this.enter(),this.block(e.body),this.leave(),r!==n.length-1&&t.push(this.emit(`Jmp`)),i&&(i.target=this.instructions.length)});let r=this.instructions.length;for(let e of t)e.target=r}whileStat(e){let t={breaks:[],localMark:this.locals.length};this.loops.push(t);let n=this.instructions.length,r=this.expr(e.condition);this.freereg=this.nactvar,this.emit(`Test`,r,0,1);let i=this.emit(`Jmp`);this.enter(),this.block(e.body),this.leave();let a=this.emit(`Jmp`);a.target=n,i.target=this.instructions.length;for(let e of t.breaks)e.target=this.instructions.length;this.loops.pop()}repeatStat(e){let t={breaks:[],localMark:this.locals.length};this.loops.push(t),this.enter();let n=this.instructions.length;this.block(e.body);let r=this.expr(e.condition);this.freereg=this.nactvar,this.emit(`Test`,r,0,1);let i=this.emit(`Jmp`);i.target=n,this.leave();let a=this.instructions.length;for(let e of t.breaks)e.target=a;this.loops.pop()}breakStat(e){let t=this.loops[this.loops.length-1];t||this.fail(e,"`break` fuera de un bucle"),this.closeFrom(t.localMark),t.breaks.push(this.emit(`Jmp`))}numFor(e){let t=this.nactvar;this.nactvar=t+3,this.freereg=this.nactvar,this.exprInto(e.start,t),this.freereg=this.nactvar,this.exprInto(e.end,t+1),this.freereg=this.nactvar,e.step?this.exprInto(e.step,t+2):this.loadConst(t+2,{type:`Number`,data:1});let n=this.locals.length;this.pushLocal(String(e.variable.name),t+3),this.nactvar=t+4,this.freereg=this.nactvar;let r=this.emit(`ForPrep`,t,0,0),i=this.instructions.length,a={breaks:[],localMark:n};this.loops.push(a),this.enter(),this.block(e.body),this.leave();let o=this.emit(`ForLoop`,t,0,0);r.target=this.instructions.indexOf(o),o.target=i,this.closeFrom(n),this.locals.pop(),this.nactvar=t,this.freereg=t;let s=this.instructions.length;for(let e of a.breaks)e.target=s;this.loops.pop()}genFor(e){let t=this.nactvar,n=e.variables,r=e.iterators;if(this.nactvar=t+3,this.freereg=this.nactvar,r.length===1&&bn(r[0]))this.compileCall(r[0],3,t,!1);else for(let e=0;e<3;e++)this.freereg=Math.max(this.nactvar,t+3),e<r.length?this.exprInto(r[e],t+e):this.emit(`LoadNil`,t+e,t+e,0);let i=this.locals.length;n.forEach((e,n)=>this.pushLocal(String(e.name),t+3+n)),this.nactvar=t+3+n.length,this.freereg=this.nactvar;let a=this.emit(`Jmp`),o=this.instructions.length,s={breaks:[],localMark:i};this.loops.push(s),this.enter(),this.block(e.body),this.leave(),a.target=this.instructions.length,this.emit(`TForLoop`,t,0,n.length);let c=this.emit(`Jmp`);for(c.target=o,this.closeFrom(i);this.locals.length>i;)this.locals.pop();this.nactvar=t,this.freereg=t;let l=this.instructions.length;for(let e of s.breaks)e.target=l;this.loops.pop()}compileChunk(e){this.compileFunction([],e,!0)}finish(){return{name:this.name,parameterCount:this.parameterCount,varargCount:this.isVararg?2:0,upvalCount:this.upvalues.length,stackSize:Math.max(this.maxStack,this.parameterCount+2,2),constants:this.constants,instructions:this.instructions,prototypes:this.prototypes}}};function Cn(e){let t;try{t=(0,_n.parse)(e,{luaVersion:`5.1`,locations:!0})}catch(e){let t=e,n=t.line?`Línea ${t.line}: `:``;throw Error(`${n}${t.message??`Error de sintaxis Lua`}`)}let n=new Sn(null,0,!0,`@chelo`);return n.compileChunk(t.body??[]),n.finish()}var wn=`Move.Loadk.LoadBool.LoadNil.GetUpval.GetGlobal.GetTable.SetGlobal.SetUpval.SetTable.NewTable.Self.Add.Sub.Mul.Div.Mod.Pow.Unm.Not.Len.Concat.Jmp.Eq.Lt.Le.Test.TestSet.Call.TailCall.Return.ForLoop.ForPrep.TForLoop.SetList.Close.Closure.VarArg`.split(`.`),Tn=class{b;i=0;intSize=4;sizeT=8;big=!1;constructor(e){this.b=e}left(e){if(this.i+e>this.b.length)throw Error(`Bytecode Lua malformado`)}u8(){return this.left(1),this.b[this.i++]}uint(e){this.left(e);let t=0;if(this.big)for(let n=0;n<e;n++)t=t*256+this.b[this.i++];else for(let n=0;n<e;n++)t+=this.b[this.i++]*2**(8*n);return t}i32(){return this.uint(this.intSize)}size(){return this.uint(this.sizeT)}f64(){this.left(8);let e=this.b.slice(this.i,this.i+8);return this.i+=8,new DataView(e.buffer,e.byteOffset,8).getFloat64(0,!this.big)}str(){let e=this.size();if(e===0)return``;this.left(e);let t=``;for(let n=0;n<e;n++)t+=String.fromCharCode(this.b[this.i++]);return t.endsWith(`\0`)?t.slice(0,-1):t}code(){let e=this.uint(4),t=e&63,n=e>>>6&255,r=wn[t];if(!r)throw Error(`Opcode Lua desconocido ${t}`);let i=Xt[r],a=0,o=0;return i===`ABC`?(o=e>>>14&511,a=e>>>23&511):i===`ABx`?a=e>>>14&262143:i===`AsBx`&&(a=(e>>>14&262143)-131071),Zt(r,n,a,o)}};function En(e){let t=e.str();e.i32(),e.i32();let n=e.u8(),r=e.u8(),i=e.u8(),a=e.u8(),o=e.i32(),s=[];for(let t=0;t<o;t++)s.push(e.code());let c=e.i32(),l=[];for(let t=0;t<c;t++){let t=e.u8();if(t===0)l.push({type:`Nil`,data:null});else if(t===1)l.push({type:`Boolean`,data:e.u8()!==0});else if(t===3)l.push({type:`Number`,data:e.f64()});else if(t===4)l.push({type:`String`,data:e.str()});else throw Error(`Constante Lua tipo ${t} no soportada`)}let u=e.i32(),d=[];for(let t=0;t<u;t++)d.push(En(e));let f=e.i32();for(let t=0;t<f;t++)e.i32();let p=e.i32();for(let t=0;t<p;t++)e.str(),e.i32(),e.i32();let m=e.i32();for(let t=0;t<m;t++)e.str();return{name:t,parameterCount:r,varargCount:i,upvalCount:n,stackSize:a,constants:l,instructions:s,prototypes:d}}function Dn(e){if(e.length<12||e[0]!==27||e[1]!==76||e[2]!==117||e[3]!==97)throw Error(`No es un binario Lua 5.1 (.luac)`);let t=new Tn(e);t.i=4;let n=t.u8();if(n!==81)throw Error(`Solo Lua 5.1 (header 0x${n.toString(16)})`);t.u8(),t.big=t.u8()===0,t.intSize=t.u8(),t.sizeT=t.u8();let r=t.u8(),i=t.u8(),a=t.u8();if(t.intSize!==4||r!==4||i!==8||a!==0)throw Error(`Header Lua no estándar (se espera int32, instrucciones de 4 bytes y doubles)`);if(t.sizeT!==4&&t.sizeT!==8)throw Error(`size_t no soportado`);return En(t)}var On=`
local ObfuscatorBytecode = |OBFUSCATOR_BYTECODE|;
local Select, Byte, Sub = select, string.byte, string.sub

local function _u32(x) return x % 4294967296 end
local function _xor(a,b)
    local r,p=0,1
    while a>0 or b>0 do
        local aa=a%2; local bb=b%2
        if aa~=bb then r=r+p end
        a=(a-aa)/2; b=(b-bb)/2; p=p*2
    end
    return r
end
local function _and(a,b)
    local r,p=0,1
    while a>0 or b>0 do
        local aa=a%2; local bb=b%2
        if aa==1 and bb==1 then r=r+p end
        a=(a-aa)/2; b=(b-bb)/2; p=p*2
    end
    return r
end
local function _or(a,b) return _u32(a+b-_and(a,b)) end
local function _not(a) return 4294967295-_u32(a) end
local function _shr(a,n) return math.floor(_u32(a)/2^n) end
local function _shl(a,n) return _u32(_u32(a)*2^n) end
local function _ror(a,n) return _or(_shr(a,n),_shl(a,32-n)) end

local function _read32(s,p)
    local a,b,c,d=Byte(s,p,p+3)
    return a+b*256+c*65536+d*16777216,p+4
end
local function _u8(s,p) return Byte(s,p) end
local function _double(raw)
    local b={Byte(raw,1,8)}
    local lo=b[1]+b[2]*256+b[3]*65536+b[4]*16777216
    local hi=b[5]+b[6]*256+b[7]*65536+b[8]*16777216
    local sign=(math.floor(hi/2147483648)%2==1) and -1 or 1
    local exp=math.floor(hi/1048576)%2048
    local frac=(hi%1048576)*4294967296+lo
    if exp==0 then if frac==0 then return sign*0 end; return sign*(2^-1022)*(frac/4503599627370496) end
    if exp==2047 then if frac==0 then return sign*(1/0) end; return 0/0 end
    return sign*(2^(exp-1023))*(1+frac/4503599627370496)
end
local function _base64(s)
    local alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    s=s:gsub("[^"..alphabet.."=]","")
    local out={}
    local bits=""
    for i=1,#s do
        local c=s:sub(i,i)
        if c~="=" then
            local n=(alphabet:find(c,1,true) or 1)-1
            local b=""
            for k=5,0,-1 do b=b..((math.floor(n/2^k)%2)==1 and "1" or "0") end
            bits=bits..b
        end
    end
    for i=1,#bits-7,8 do
        local n=0
        for k=0,7 do n=n*2+(bits:sub(i+k,i+k)=="1" and 1 or 0) end
        out[#out+1]=string.char(n)
    end
    return table.concat(out)
end

-- Pure-Lua SHA-256 used to validate the CHLOV14 body before decoding.
local function _sha256(msg)
    local K={
      1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,
      3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,
      3835390401,4022224774,2643470785,604807628,770255983,1249150122,1555081692,1996064986,
      2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,
      666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,
      2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344
    }
    local H={1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225}
    local n=#msg; local bitlen=n*8; local pad=string.char(128)
    local rem=(56-((n+1)%64))%64
    local hi=math.floor(bitlen/4294967296); local lo=bitlen%4294967296
    local function be32(x) return string.char(math.floor(x/16777216)%256,math.floor(x/65536)%256,math.floor(x/256)%256,x%256) end
    pad=pad..string.rep("\\0",rem)..be32(hi)..be32(lo)
    msg=msg..pad
    for off=1,#msg,64 do
        local W={}
        for i=0,15 do
            local p=off+i*4; local a,b,c,d=Byte(msg,p,p+3)
            W[i]=_u32(a*16777216+b*65536+c*256+d)
        end
        for i=16,63 do
            local x=W[i-15]; local y=W[i-2]
            local s0=_xor(_xor(_ror(x,7),_ror(x,18)),_shr(x,3))
            local s1=_xor(_xor(_ror(y,17),_ror(y,19)),_shr(y,10))
            W[i]=_u32(W[i-16]+s0+W[i-7]+s1)
        end
        local a,b,c,d,e,f,g,h=H[1],H[2],H[3],H[4],H[5],H[6],H[7],H[8]
        for i=0,63 do
            local S1=_xor(_xor(_ror(e,6),_ror(e,11)),_ror(e,25))
            local ch=_xor(_and(e,f),_and(_not(e),g))
            local t1=_u32(h+S1+ch+K[i+1]+W[i])
            local S0=_xor(_xor(_ror(a,2),_ror(a,13)),_ror(a,22))
            local maj=_xor(_xor(_and(a,b),_and(a,c)),_and(b,c))
            local t2=_u32(S0+maj)
            h=g; g=f; f=e; e=_u32(d+t1); d=c; c=b; b=a; a=_u32(t1+t2)
        end
        H[1]=_u32(H[1]+a); H[2]=_u32(H[2]+b); H[3]=_u32(H[3]+c); H[4]=_u32(H[4]+d)
        H[5]=_u32(H[5]+e); H[6]=_u32(H[6]+f); H[7]=_u32(H[7]+g); H[8]=_u32(H[8]+h)
    end
    local out={}
    for i=1,8 do local x=H[i]; out[#out+1]=string.char(math.floor(x/16777216)%256,math.floor(x/65536)%256,math.floor(x/256)%256,x%256) end
    return table.concat(out)
end

|V14_RUNTIME|
`,kn=`
local function Deserialize(ByteString)
    local Pos=1
    local function U8() local x=Byte(ByteString,Pos); Pos=Pos+1; return x end
    local function U32() local x; x,Pos=_read32(ByteString,Pos); return x end
    local function Raw(n) local s=Sub(ByteString,Pos,Pos+n-1); Pos=Pos+n; return s end
    local function UString() local n=U32(); return Raw(n) end
    local function xorbytes(s,key,seed)
        local o={}
        for i=1,#s do
            local a=Byte(s,i); local b=key[((seed+i-1)%#key)+1]; o[i]=string.char(_xor(a,b))
        end
        return table.concat(o)
    end
    local function bits(word,def)
        local out={}
        for name,v in pairs(def) do out[name]=math.floor(word/2^v.Start)%2^v.Length end
        return out
    end
    local function chunk()
        local c={UpvalCount=0,ParameterCount=0,VarargCount=0,Constants={},Instructions={},Prototypes={},Upvalues={}}
        local count=U32(); local fields={}
        for _=1,count do local n=U8(); local name=Raw(n); local sz=U32(); fields[name]=Raw(sz) end
        c.UpvalCount=Byte(fields.UpvalCount or "\\0",1)
        c.ParameterCount=Byte(fields.ParameterCount or "\\0",1)
        c.VarargCount=Byte(fields.VarargCount or "\\0",1)
        local cb=fields.Constants; local cp=1; local cc; cc,cp=_read32(cb,cp)
        local revTag={}
        for k,v in pairs(V14.ConstantTags) do revTag[v]=k end
        for i=1,cc do
            local tag=Byte(cb,cp); cp=cp+1; local typ=revTag[tag]
            local v
            if typ=="Nil" then v=nil
            elseif typ=="Boolean" then v=Byte(cb,cp)~=0; cp=cp+1
            elseif typ=="Number" then local n; n,cp=_read32(cb,cp); local raw=Sub(cb,cp,cp+n-1); cp=cp+n; raw=xorbytes(raw,V14.Key,i-1); v=_double(raw)
            elseif typ=="String" then local parts,ns={}; ns,cp=_read32(cb,cp); for j=1,ns do local n; n,cp=_read32(cb,cp); local raw=Sub(cb,cp,cp+n-1); cp=cp+n; parts[#parts+1]=xorbytes(raw,V14.Key,(i-1)+(j-1)) end; v=table.concat(parts)
            else error("bad CHLOV14 constant tag") end
            c.Constants[i]=v
        end
        local ib=fields.Instructions; local ip=1; local ic; ic,ip=_read32(ib,ip)
        local rev={}; for name,id in pairs(V14.OpcodeMap) do rev[id]=name end
        local function signbx(name, f)
            local typ=V14.OpcodeTypes[name] or "ABC"
            if typ=="AsBx" then
                local L=((V14.Registers.AsBx or {}).B or {}).Length or 18
                local sign=2^(L-1)
                if (f.B or 0) >= sign then f.B = (f.B or 0) - 2^L end
            end
            return f
        end
        for i=1,ic do
            local oid; oid,ip=_read32(ib,ip); local word; word,ip=_read32(ib,ip); local junk=_u8(ib,ip); ip=ip+1
            local name=rev[oid]; if not name then error("unknown CHLOV14 opcode") end
            local typ=V14.OpcodeTypes[name] or "ABC"; local f=bits(word,V14.Registers[typ] or V14.Registers.ABC)
            f=signbx(name, f)
            local subs=nil
            if name=="Super" then
                local sc; sc,ip=_read32(ib,ip); subs={}
                for _s=1,sc do
                    local soid; soid,ip=_read32(ib,ip)
                    local sword; sword,ip=_read32(ib,ip)
                    local sname=rev[soid]; if not sname then error("unknown CHLOV14 super opcode") end
                    local styp=V14.OpcodeTypes[sname] or "ABC"
                    local sf=bits(sword, V14.Registers[styp] or V14.Registers.ABC)
                    sf=signbx(sname, sf)
                    subs[#subs+1]={Enum=sname,A=sf.A or 0,B=sf.B or 0,C=sf.C or 0}
                end
            end
            c.Instructions[i]={Enum=name,A=f.A or 0,B=f.B or 0,C=f.C or 0,Junk=(junk~=0),SuperOps=subs}
        end
        local pb=fields.Prototypes; local pp=1; local pc; pc,pp=_read32(pb,pp)
        for i=1,pc do local sz; sz,pp=_read32(pb,pp); local old=ByteString; ByteString=Sub(pb,pp,pp+sz-1); Pos=1; c.Prototypes[i]=chunk(); ByteString=old; pp=pp+sz end
        return c
    end
    return chunk()
end
`,An=`
local function _truthy(v)
    return not not v
end
local function _unpack(t)
    return table.unpack and table.unpack(t) or unpack(t)
end
local function _rk(frame, x, const)
    if x >= 256 then return const[x - 255] end
    return frame.stack[x]
end
local function _die()
    while true do end
end

local function _exec_super(frame, S, const)
    local op = S.Enum
    local A, B, C = S.A or 0, S.B or 0, S.C or 0
    local function rk(x)
        if x >= 256 then return const[x - 255] end
        return frame.stack[x]
    end
    if op == "Move" then frame.stack[A] = frame.stack[B]
    elseif op == "Loadk" then frame.stack[A] = const[B + 1]
    elseif op == "LoadBool" then frame.stack[A] = (B ~= 0)
    elseif op == "GetGlobal" then frame.stack[A] = (_ENV or _G)[const[B + 1]]
    elseif op == "GetTable" then frame.stack[A] = frame.stack[B][rk(C)]
    elseif op == "SetTable" then frame.stack[A][rk(B)] = rk(C)
    elseif op == "Add" then frame.stack[A] = rk(B) + rk(C)
    elseif op == "Sub" then frame.stack[A] = rk(B) - rk(C)
    elseif op == "Mul" then frame.stack[A] = rk(B) * rk(C)
    elseif op == "Div" then frame.stack[A] = rk(B) / rk(C)
    elseif op == "Mod" then frame.stack[A] = rk(B) % rk(C)
    elseif op == "Pow" then frame.stack[A] = rk(B) ^ rk(C)
    elseif op == "Self" then
        local obj = frame.stack[B]
        frame.stack[A + 1] = obj
        frame.stack[A] = obj[rk(C)]
    elseif op == "Call" then
        local args = {}
        local n = B - 1
        if B == 0 then n = (frame.top or A) - A end
        for j = 1, math.max(n, 0) do args[j] = frame.stack[A + j] end
        local fn = frame.stack[A]
        local ret
        if type(fn) == "function" then
            ret = {fn(_unpack(args))}
        elseif type(fn) == "table" and fn.__vmclosure then
            ret = {VM_Run(fn.chunk, _ENV or _G, fn.upvalues, args)}
        else
            _die()
        end
        if C == 0 then
            for j = 1, #ret do frame.stack[A + j - 1] = ret[j] end
            frame.top = A + #ret - 1
        else
            for j = 0, C - 2 do frame.stack[A + j] = ret[j + 1] end
        end
    end
end

local function _call(fn, args, env, up)
    if type(fn) == "function" then return {fn(_unpack(args))} end
    if type(fn) == "table" and fn.__vmclosure then return {VM_Run(fn.chunk, env, fn.upvalues, args)} end
    _die()
end

function VM_Run(Chunk, Env, Upvalues, Args)
    do
        local t0 = os.clock()
        local s = 0
        for i = 1, 12000 do s = s + (i % 5) end
        if os.clock() < t0 then _die() end
        if s < 0 then _die() end
    end
    Env = Env or _ENV or _G
    Upvalues = Upvalues or {}
    Args = Args or {}
    local frame = {stack = {}, varargs = {}, top = -1, open_uv = {}}
    for i = 0, (Chunk.ParameterCount or 0) - 1 do frame.stack[i] = Args[i + 1] end
    for i = (Chunk.ParameterCount or 0), #Args - 1 do frame.varargs[#frame.varargs + 1] = Args[i + 1] end
    local pc = 1
    local ins = Chunk.Instructions
    local const = Chunk.Constants
    local function rk(x) return _rk(frame, x, const) end
    local function close_from(a)
        local ou = frame.open_uv
        for i = #ou, 1, -1 do
            local box = ou[i]
            if box and box.reg ~= nil and box.reg >= a then
                local st = (box.frame and box.frame.stack) or frame.stack
                box.value = st[box.reg]
                box.reg = nil
                box.frame = nil
                table.remove(ou, i)
            end
        end
    end
    while true do
        local I = ins[pc]
        if not I then return end
        pc = pc + 1
        local op = I.Enum
        local A, B, C = I.A or 0, I.B or 0, I.C or 0
        if I.Junk or op == "Junk" then
        elseif op == "Super" then
            for _, S in ipairs(I.SuperOps or {}) do _exec_super(frame, S, const) end
        elseif op == "Move" then frame.stack[A] = frame.stack[B]
        elseif op == "Loadk" then frame.stack[A] = const[B + 1]
        elseif op == "LoadBool" then frame.stack[A] = (B ~= 0); if C ~= 0 then pc = pc + 1 end
        elseif op == "LoadNil" then for r = A, B do frame.stack[r] = nil end
        elseif op == "GetUpval" then
            local u = Upvalues[B + 1]
            if type(u) == "table" then
                if u.reg ~= nil and u.frame then frame.stack[A] = u.frame.stack[u.reg] else frame.stack[A] = u.value end
            else frame.stack[A] = u end
        elseif op == "SetUpval" then
            local u = Upvalues[B + 1]
            if type(u) == "table" then
                if u.reg ~= nil and u.frame then u.frame.stack[u.reg] = frame.stack[A] else u.value = frame.stack[A] end
            else Upvalues[B + 1] = frame.stack[A] end
        elseif op == "GetGlobal" then frame.stack[A] = Env[const[B + 1]]
        elseif op == "SetGlobal" then Env[const[B + 1]] = frame.stack[A]
        elseif op == "GetTable" then frame.stack[A] = frame.stack[B][rk(C)]
        elseif op == "SetTable" then frame.stack[A][rk(B)] = rk(C)
        elseif op == "NewTable" then frame.stack[A] = {}
        elseif op == "Self" then local obj = frame.stack[B]; frame.stack[A + 1] = obj; frame.stack[A] = obj[rk(C)]
        elseif op == "Add" then frame.stack[A] = rk(B) + rk(C)
        elseif op == "Sub" then frame.stack[A] = rk(B) - rk(C)
        elseif op == "Mul" then frame.stack[A] = rk(B) * rk(C)
        elseif op == "Div" then frame.stack[A] = rk(B) / rk(C)
        elseif op == "Mod" then frame.stack[A] = rk(B) % rk(C)
        elseif op == "Pow" then frame.stack[A] = rk(B) ^ rk(C)
        elseif op == "Unm" then frame.stack[A] = -frame.stack[B]
        elseif op == "Not" then frame.stack[A] = not frame.stack[B]
        elseif op == "Len" then frame.stack[A] = #frame.stack[B]
        elseif op == "Concat" then
            local s = frame.stack[B]
            for r = B + 1, C do s = s .. frame.stack[r] end
            frame.stack[A] = s
        elseif op == "Jmp" then pc = pc + B
        elseif op == "Eq" then if (rk(B) == rk(C)) ~= (A ~= 0) then pc = pc + 1 end
        elseif op == "Lt" then if (rk(B) < rk(C)) ~= (A ~= 0) then pc = pc + 1 end
        elseif op == "Le" then if (rk(B) <= rk(C)) ~= (A ~= 0) then pc = pc + 1 end
        elseif op == "Test" then if (_truthy(frame.stack[A]) == (C ~= 0)) then pc = pc + 1 end
        elseif op == "TestSet" then
            if (_truthy(frame.stack[B]) == (C ~= 0)) then frame.stack[A] = frame.stack[B] else pc = pc + 1 end
        elseif op == "Call" or op == "TailCall" then
            local args = {}
            local n = B - 1
            if B == 0 then n = frame.top - A end
            for j = 1, math.max(n, 0) do args[j] = frame.stack[A + j] end
            local ret = _call(frame.stack[A], args, Env, Upvalues)
            if C == 0 then
                for j = 1, #ret do frame.stack[A + j - 1] = ret[j] end
                frame.top = A + #ret - 1
            else
                for j = 0, C - 2 do frame.stack[A + j] = ret[j + 1] end
            end
            if op == "TailCall" then return _unpack(ret) end
        elseif op == "Return" then
            close_from(0)
            local n = B - 1
            if B == 0 then n = frame.top - A + 1 end
            local ret = {}
            for j = 0, math.max(n, 0) - 1 do ret[#ret + 1] = frame.stack[A + j] end
            return _unpack(ret)
        elseif op == "ForPrep" then frame.stack[A] = frame.stack[A] - frame.stack[A + 2]; pc = pc + B
        elseif op == "ForLoop" then
            local idx = frame.stack[A] + frame.stack[A + 2]
            frame.stack[A] = idx
            local lim, step = frame.stack[A + 1], frame.stack[A + 2]
            if (step > 0 and idx <= lim) or (step <= 0 and idx >= lim) then frame.stack[A + 3] = idx; pc = pc + B end
        elseif op == "TForLoop" then
            local ret = _call(frame.stack[A], {frame.stack[A + 1], frame.stack[A + 2]}, Env, Upvalues)
            for j = 1, C do frame.stack[A + 2 + j] = ret[j] end
            if frame.stack[A + 3] ~= nil then frame.stack[A + 2] = frame.stack[A + 3] else pc = pc + 1 end
        elseif op == "SetList" then
            local tbl = frame.stack[A]
            local n = B
            local page = C
            if B == 0 then n = frame.top - A end
            if page == 0 then page = 1 end
            local start = (page - 1) * 50
            for j = 1, n do tbl[start + j] = frame.stack[A + j] end
        elseif op == "Close" then close_from(A)
        elseif op == "Closure" then
            local child = {__vmclosure = true, chunk = Chunk.Prototypes[B + 1], upvalues = {}}
            local need = (child.chunk and child.chunk.UpvalCount) or 0
            for u = 1, need do
                local bind = ins[pc]
                if bind and bind.Enum == "Move" then
                    local box
                    for _, existing in ipairs(frame.open_uv) do
                        if existing.reg == bind.B then box = existing break end
                    end
                    if not box then
                        box = {reg = bind.B, frame = frame}
                        frame.open_uv[#frame.open_uv + 1] = box
                    end
                    child.upvalues[u] = box
                    pc = pc + 1
                elseif bind and bind.Enum == "GetUpval" then
                    child.upvalues[u] = Upvalues[bind.B + 1]
                    pc = pc + 1
                else
                    child.upvalues[u] = {value = nil}
                end
            end
            frame.stack[A] = child
        elseif op == "VarArg" then
            local n = B - 1
            if B == 0 then n = #frame.varargs end
            for j = 1, n do frame.stack[A + j - 1] = frame.varargs[j] end
            frame.top = A + n - 1
        else
            _die()
        end
    end
end

local function Wrap(Chunk, Env, Upvalues, ...)
    local args = {...}
    return VM_Run(Chunk, Env, Upvalues, args)
end
`,jn=`-- Chelo anti-dump (jerry probes)
local function die()
    while true do end
end

local function shuffle(t)
    for i = #t, 2, -1 do
        local j = math.random(i)
        t[i], t[j] = t[j], t[i]
    end
    return t
end

-- probe L1:1
local function _p_1_1()
local sv = Instance.new("StringValue")
sv.Name = "__canary"
sv.Value = "safe"
local snap = sv.Value
task.defer(function()
    if sv.Value ~= snap then
        die()
    end
    sv:Destroy()
    return true
end)
end

-- probe L1:2
local function _p_1_2()
local m = Instance.new("Model")
local p = Instance.new("Part")
p.Name = "T"
p.Parent = m
local ov = Instance.new("ObjectValue")
ov.Value = p
ov.Parent = m
local c = m:Clone()
local cp = c:FindFirstChild("T")
local co = c:FindFirstChildOfClass("ObjectValue")
if co.Value == cp and co.Value ~= p then
    return true
else
    die()
end
m:Destroy()
c:Destroy()
end

-- probe L1:3
local function _p_1_3()
local b = Instance.new("BoolValue")
b.Value = true
local changed = false
b.Changed:Connect(function()
    changed = true
end)
task.defer(function()
    if changed then
        die()
    end
    b:Destroy()
    return true
end)
end

-- probe L1:4
local function _p_1_4()
local iv = Instance.new("IntValue")
iv.Value = 12345678
local c = iv:Clone()
if c.Value ~= iv.Value then
    die()
end
iv.Value = 87654321
if c.Value == iv.Value then
    die()
end
iv:Destroy()
c:Destroy()
return true
end

-- probe L1:5
local function _p_1_5()
local nv = Instance.new("NumberValue")
nv.Value = math.pi
task.defer(function()
    if nv.Value ~= math.pi then
        die()
    end
    nv:Destroy()
    return true
end)
end

-- probe L1:6
local function _p_1_6()
local h = Instance.new("Highlight")
local p = Instance.new("Part")
h.Adornee = p
h.FillTransparency = 0.5
local c = h:Clone()
if c.Adornee ~= p then
    die()
end
if math.abs(c.FillTransparency - 0.5) > 0.0001 then
    die()
end
h:Destroy()
c:Destroy()
p:Destroy()
return true
end

-- probe L1:7
local function _p_1_7()
local cl = Instance.new("Clouds")
cl.Density = 0.69
local ex = Instance.new("Explosion")
ex.BlastRadius = 13.37

local cc = cl:Clone()
local ec = ex:Clone()


if math.abs(cc.Density - cl.Density) > 0.0001 then
    die()
end

ex.BlastRadius = 99
if ec.BlastRadius == ex.BlastRadius then
    die()
end

cl:Destroy() cc:Destroy()
ex:Destroy() ec:Destroy()
return true
end

-- probe L1:8
local function _p_1_8()
local rv = Instance.new("ReverbSoundEffect")
rv.DecayTime = 3.75
local eq = Instance.new("EqualizerSoundEffect")
eq.HighGain = -6.5

local rc = rv:Clone()
local ec = eq:Clone()


if math.abs(rc.DecayTime - rv.DecayTime) > 0.0001 then
    die()
end

eq.HighGain = 0
if ec.HighGain == eq.HighGain then
    die()
end

rv:Destroy() rc:Destroy()
eq:Destroy() ec:Destroy()
return true
end

-- probe L1:9
local function _p_1_9()
local fl = Instance.new("FlangeSoundEffect")
fl.Rate = 2.22
local sb = Instance.new("SelectionBox")
sb.LineThickness = 0.08

local fc = fl:Clone()
local sc = sb:Clone()


if math.abs(fc.Rate - fl.Rate) > 0.0001 then
    die()
end

sb.LineThickness = 999
if sc.LineThickness == sb.LineThickness then
    die()
end

fl:Destroy() fc:Destroy()
sb:Destroy() sc:Destroy()
return true
end

-- probe L1:10
local function _p_1_10()
local tr = Instance.new("TremoloSoundEffect")
tr.Frequency = 4.44
local cp = Instance.new("CompressorSoundEffect")
cp.Threshold = -24.0

local tc = tr:Clone()
local cc = cp:Clone()


if math.abs(tc.Frequency - tr.Frequency) > 0.0001 then
    die()
end

cp.Threshold = 0
if cc.Threshold == cp.Threshold then
    die()
end

tr:Destroy() tc:Destroy()
cp:Destroy() cc:Destroy()
return true
end

-- probe L1:11
local function _p_1_11()
local ch = Instance.new("ChorusSoundEffect")
ch.Depth = 0.55
ch.Mix = 0.33
local cc = ch:Clone()

if math.abs(cc.Depth - ch.Depth) > 0.0001 then
    die()
end
ch.Mix = 1
if cc.Mix == ch.Mix then
    die()
end

ch:Destroy() cc:Destroy()
return true
end

-- probe L1:12
local function _p_1_12()
local ae = Instance.new("AudioEcho")
ae.DelayTime = 0.33
ae.Feedback = 0.77
ae.WetLevel = -6.5
local aec = ae:Clone()
ae.DelayTime = 0
if aec.DelayTime == ae.DelayTime then
    die()
end
if math.abs(aec.Feedback - 0.77) > 0.0001 then
    die()
end
ae:Destroy() aec:Destroy()
return true
end

-- probe L1:13
local function _p_1_13()
local ar = Instance.new("AudioReverb")
ar.DecayTime = 4.44
ar.Density = 0.88
ar.WetLevel = -3.5
ar.DryLevel = -6.6
local arc = ar:Clone()
ar.DecayTime = 0
if arc.DecayTime == ar.DecayTime then
    die()
end
if math.abs(arc.Density - 0.88) > 0.0001 then
    die()
end
ar:Destroy() arc:Destroy()
return true
end

-- probe L1:14
local function _p_1_14()
local at = Instance.new("AudioTremolo")
at.Frequency = 7.77
at.Depth = 0.55
at.Duty = 0.33
local atc = at:Clone()
at.Frequency = 0
if atc.Frequency == at.Frequency then
    die()
end
if math.abs(atc.Depth - 0.55) > 0.0001 then
    die()
end
at:Destroy() atc:Destroy()
return true
end

-- probe L1:15
local function _p_1_15()
local ac = Instance.new("AudioCompressor")
ac.Threshold = -24.5
ac.Ratio = 4.44
ac.Attack = 0.88
local acc = ac:Clone()
ac.Threshold = 0
if acc.Threshold == ac.Threshold then
    die()
end
if math.abs(acc.Ratio - 4.44) > 0.0001 then
    die()
end
ac:Destroy() acc:Destroy()
return true
end

-- probe L1:16
local function _p_1_16()
local anim = Instance.new("AnimationConstraint")
anim.AngularDamping = 3.33
anim.LinearDamping = 7.77
anim.AngularStrength = 0.55
local animc = anim:Clone()
anim.AngularDamping = 0
if animc.AngularDamping == anim.AngularDamping then
    die()
end
if math.abs(animc.LinearDamping - 7.77) > 0.0001 then
    die()
end
anim:Destroy() animc:Destroy()
return true
end

-- probe L1:17
local function _p_1_17()
local av = Instance.new("AvatarAbilityRules")
av.EnableClimbing = true
av.EnableCrouching = false
local avc = av:Clone()
av.EnableClimbing = false
if avc.EnableClimbing == av.EnableClimbing then
    die()
end
if avc.EnableCrouching ~= false then
    die()
end
av:Destroy() avc:Destroy()
return true
end

-- probe L1:18
local function _p_1_18()
local wl = Instance.new("WrapLayer")
wl.Order = 5
wl.Enabled = true
local wlc = wl:Clone()
wl.Order = 99
if wlc.Order == wl.Order then
    die()
end
if wlc.Enabled ~= true then
    die()
end
wl:Destroy() wlc:Destroy()
return true
end

-- probe L1:19
local function _p_1_19()
local ad = Instance.new("AccessoryDescription")
ad.AssetId = 123456789
ad.Order = 3
ad.IsLayered = true
local adc = ad:Clone()
ad.AssetId = 0
if adc.AssetId == ad.AssetId then
    die()
end
if adc.IsLayered ~= true then
    die()
end
ad:Destroy() adc:Destroy()
return true
end

-- probe L1:20
local function _p_1_20()
if hookmetamethod then
    local orig
    orig = hookmetamethod(game, "__namecall", function(self, ...)
        if self == game and getnamecallmethod() == "GetService" then
            local args = {...}
            if args[1] == "__canary_svc" then
                return 9999
            end
        end
        return orig(self, ...)
    end)
    local result = game:GetService("__canary_svc")
    if result ~= 9999 then
        die()
    end
    hookmetamethod(game, "__namecall", orig)
end
return true
end

-- probe L1:21
local function _p_1_21()
if hookmetamethod then
    local orig
    orig = hookmetamethod(game, "__index", function(self, key)
        if self == game and key == "__canary_key" then
            return 0xBEEF
        end
        return orig(self, key)
    end)
    local result = game["__canary_key"]
    if result ~= 0xBEEF then
        die()
    end
    hookmetamethod(game, "__index", orig)
end
return true
end

-- probe L2:1
local function _p_2_1()
local p0 = Instance.new("Part")
local p1 = Instance.new("Part")
local a0 = Instance.new("Attachment") a0.Parent = p0
local a1 = Instance.new("Attachment") a1.Parent = p1


local sp = Instance.new("SpringConstraint")
sp.Attachment0 = a0 sp.Attachment1 = a1
sp.Stiffness = 88.8 sp.Damping = 0.25
local sc = sp:Clone()
sp.Stiffness = 1
if sc.Stiffness == sp.Stiffness then
    die()
end


local rp = Instance.new("RopeConstraint")
rp.Attachment0 = a0 rp.Attachment1 = a1
rp.WinchSpeed = 13.37
local rc = rp:Clone()
if math.abs(rc.WinchSpeed - rp.WinchSpeed) > 0.0001 then
    die()
end


local hc = Instance.new("HingeConstraint")
hc.Attachment0 = a0 hc.Attachment1 = a1
hc.UpperAngle = 45.0 hc.LowerAngle = -45.0
local hcc = hc:Clone()
if hcc.Attachment0 ~= a0 or hcc.Attachment1 ~= a1 then
    die()
end


local ap = Instance.new("AlignPosition")
ap.Attachment0 = a0 ap.Attachment1 = a1
ap.Responsiveness = 7.77 ap.MaxVelocity = 50.0
local apc = ap:Clone()
ap.Responsiveness = 200
if apc.Responsiveness == ap.Responsiveness then
    die()
end


local wc = Instance.new("WeldConstraint")
wc.Part0 = p0 wc.Part1 = p1
local wcc = wc:Clone()
if wcc.Part0 ~= p0 or wcc.Part1 ~= p1 then
    die()
end
wc.Part0 = p1
if wcc.Part0 == wc.Part0 then
    die()
end

sp:Destroy() sc:Destroy()
rp:Destroy() rc:Destroy()
hc:Destroy() hcc:Destroy()
ap:Destroy() apc:Destroy()
wc:Destroy() wcc:Destroy()
p0:Destroy() p1:Destroy()
return true
end

-- probe L2:2
local function _p_2_2()
local p0 = Instance.new("Part")
local p1 = Instance.new("Part")
local a0 = Instance.new("Attachment") a0.Parent = p0
local a1 = Instance.new("Attachment") a1.Parent = p1

local lv = Instance.new("LinearVelocity")
lv.Attachment0 = a0
lv.LineVelocity = 5.55
lv.MaxForce = 100.0
local lvc = lv:Clone()
lv.LineVelocity = 999
if lvc.LineVelocity == lv.LineVelocity then
    die()
end

local av = Instance.new("AngularVelocity")
av.Attachment0 = a0
av.MaxTorque = 33.3
local avc = av:Clone()
if math.abs(avc.MaxTorque - av.MaxTorque) > 0.0001 then
    die()
end

local ao = Instance.new("AlignOrientation")
ao.Attachment0 = a0 ao.Attachment1 = a1
ao.Responsiveness = 9.99
local aoc = ao:Clone()
ao.Responsiveness = 1
if aoc.Responsiveness == ao.Responsiveness then
    die()
end

local nc = Instance.new("NoCollisionConstraint")
nc.Part0 = p0 nc.Part1 = p1
local ncc = nc:Clone()
if ncc.Part0 ~= p0 or ncc.Part1 ~= p1 then
    die()
end
nc.Part0 = p1
if ncc.Part0 == nc.Part0 then
    die()
end

local rc = Instance.new("RigidConstraint")
rc.Attachment0 = a0 rc.Attachment1 = a1
local rcc = rc:Clone()
if rcc.Attachment0 ~= a0 or rcc.Attachment1 ~= a1 then
    die()
end

lv:Destroy() lvc:Destroy()
av:Destroy() avc:Destroy()
ao:Destroy() aoc:Destroy()
nc:Destroy() ncc:Destroy()
rc:Destroy() rcc:Destroy()
p0:Destroy() p1:Destroy()
return true
end

-- probe L2:3
local function _p_2_3()
local p = Instance.new("Part")
local a0 = Instance.new("Attachment") a0.Parent = p
local a1 = Instance.new("Attachment") a1.Parent = p

local pe = Instance.new("ParticleEmitter") pe.Parent = p
pe.Rate = 44.4
pe.Drag = 0.88
pe.LightEmission = 0.55
pe.VelocityInheritance = 0.33
local pec = pe:Clone()
pe.Rate = 999
if pec.Rate == pe.Rate then
    die()
end

local tr = Instance.new("Trail")
tr.Attachment0 = a0 tr.Attachment1 = a1
tr.Lifetime = 2.75
tr.MaxLength = 50.0
local trc = tr:Clone()
if math.abs(trc.Lifetime - tr.Lifetime) > 0.0001 then
    die()
end
tr.Lifetime = 0
if trc.Lifetime == tr.Lifetime then
    die()
end

local pl = Instance.new("PointLight") pl.Parent = p
pl.Range = 16.5
pl.Brightness = 3.3
local plc = pl:Clone()
pl.Range = 1
if plc.Range == pl.Range then
    die()
end

local sl = Instance.new("SpotLight") sl.Parent = p
sl.Angle = 75.0
sl.Range = 22.2
local slc = sl:Clone()
if math.abs(slc.Angle - sl.Angle) > 0.0001 then
    die()
end

local bb = Instance.new("BillboardGui") bb.Parent = p
bb.MaxDistance = 100.0
bb.Brightness = 1.5
local bbc = bb:Clone()
bb.MaxDistance = 0
if bbc.MaxDistance == bb.MaxDistance then
    die()
end

pe:Destroy() pec:Destroy()
tr:Destroy() trc:Destroy()
pl:Destroy() plc:Destroy()
sl:Destroy() slc:Destroy()
bb:Destroy() bbc:Destroy()
p:Destroy()
return true
end

-- probe L2:4
local function _p_2_4()
local p = Instance.new("Part")

local snd = Instance.new("Sound") snd.Parent = p
snd.Volume = 0.77
snd.PlaybackSpeed = 1.25
snd.RollOffMaxDistance = 88.8
local sndc = snd:Clone()
snd.Volume = 0
if sndc.Volume == snd.Volume then
    die()
end

local dc = Instance.new("Decal") dc.Parent = p
dc.Transparency = 0.44
dc.Rotation = 33.3
local dcc = dc:Clone()
if math.abs(dcc.Transparency - dc.Transparency) > 0.0001 then
    die()
end
dc.Rotation = 0
if dcc.Rotation == dc.Rotation then
    die()
end

local tx = Instance.new("Texture") tx.Parent = p
tx.StudsPerTileU = 4.5
tx.StudsPerTileV = 6.6
tx.OffsetStudsU = 1.11
local txc = tx:Clone()
tx.StudsPerTileU = 1
if txc.StudsPerTileU == tx.StudsPerTileU then
    die()
end

local atm = Instance.new("Atmosphere")
atm.Density = 0.35
atm.Haze = 2.75
atm.Glare = 0.12
local atmc = atm:Clone()
if math.abs(atmc.Haze - atm.Haze) > 0.0001 then
    die()
end
atm.Density = 1
if atmc.Density == atm.Density then
    die()
end

snd:Destroy() sndc:Destroy()
dc:Destroy() dcc:Destroy()
tx:Destroy() txc:Destroy()
atm:Destroy() atmc:Destroy()
p:Destroy()
return true
end

-- probe L2:5
local function _p_2_5()
local p = Instance.new("Part")

local pp = Instance.new("ProximityPrompt") pp.Parent = p
pp.MaxActivationDistance = 12.5
pp.HoldDuration = 0.75
pp.ActionText = "canary"
local ppc = pp:Clone()
pp.MaxActivationDistance = 999
if ppc.MaxActivationDistance == pp.MaxActivationDistance then
    die()
end
if ppc.ActionText ~= "canary" then
    die()
end

local cd = Instance.new("ClickDetector") cd.Parent = p
cd.MaxActivationDistance = 32.0
local cdc = cd:Clone()
if math.abs(cdc.MaxActivationDistance - cd.MaxActivationDistance) > 0.0001 then
    die()
end
cd.MaxActivationDistance = 0
if cdc.MaxActivationDistance == cd.MaxActivationDistance then
    die()
end

local dd = Instance.new("DragDetector") dd.Parent = p
dd.MaxForce = 55.5
dd.Responsiveness = 8.88
dd.MaxDragAngle = 45.0
local ddc = dd:Clone()
dd.MaxForce = 1
if ddc.MaxForce == dd.MaxForce then
    die()
end
if math.abs(ddc.Responsiveness - 8.88) > 0.0001 then
    die()
end

pp:Destroy() ppc:Destroy()
cd:Destroy() cdc:Destroy()
dd:Destroy() ddc:Destroy()
p:Destroy()
return true
end

-- probe L2:6
local function _p_2_6()
local p = Instance.new("Part")

local fi = Instance.new("Fire") fi.Parent = p
fi.Heat = 9.99
fi.Size = 5.55
local fic = fi:Clone()
fi.Heat = 1
if fic.Heat == fi.Heat then
    die()
end
if math.abs(fic.Size - 5.55) > 0.0001 then
    die()
end

local sm = Instance.new("Smoke") sm.Parent = p
sm.Opacity = 0.66
sm.RiseVelocity = 4.44
sm.Size = 3.33
local smc = sm:Clone()
sm.Opacity = 0
if smc.Opacity == sm.Opacity then
    die()
end
if math.abs(smc.RiseVelocity - 4.44) > 0.0001 then
    die()
end

local sp = Instance.new("Sparkles") sp.Parent = p
sp.TimeScale = 0.88
local spc = sp:Clone()
sp.TimeScale = 0
if spc.TimeScale == sp.TimeScale then
    die()
end

local lasso = Instance.new("SelectionPointLasso")
lasso.Point = Vector3.new(1.11, 2.22, 3.33)
local lassoc = lasso:Clone()
if lassoc.Point ~= lasso.Point then
    die()
end
lasso.Point = Vector3.new(0, 0, 0)
if lassoc.Point == lasso.Point then
    die()
end

fi:Destroy() fic:Destroy()
sm:Destroy() smc:Destroy()
sp:Destroy() spc:Destroy()
lasso:Destroy() lassoc:Destroy()
p:Destroy()
return true
end

-- probe L2:7
local function _p_2_7()
local p = Instance.new("Part")

local bv = Instance.new("BodyVelocity") bv.Parent = p
bv.P = 12500.5
bv.Velocity = Vector3.new(1.1, 2.2, 3.3)
local bvc = bv:Clone()
bv.P = 1
if bvc.P == bv.P then
    die()
end
if bvc.Velocity ~= Vector3.new(1.1, 2.2, 3.3) then
    die()
end

local bp = Instance.new("BodyPosition") bp.Parent = p
bp.P = 9999.9
bp.D = 1500.5
bp.Position = Vector3.new(5.5, 6.6, 7.7)
local bpc = bp:Clone()
bp.D = 0
if bpc.D == bp.D then
    die()
end
if math.abs(bpc.P - 9999.9) > 0.001 then
    die()
end

local bg = Instance.new("BodyGyro") bg.Parent = p
bg.P = 3000.3
bg.D = 500.5
local bgc = bg:Clone()
bg.P = 0
if bgc.P == bg.P then
    die()
end
if math.abs(bgc.D - 500.5) > 0.001 then
    die()
end

local bf = Instance.new("BodyForce") bf.Parent = p
bf.Force = Vector3.new(10.1, 20.2, 30.3)
local bfc = bf:Clone()
bf.Force = Vector3.new(0, 0, 0)
if bfc.Force == bf.Force then
    die()
end

bv:Destroy() bvc:Destroy()
bp:Destroy() bpc:Destroy()
bg:Destroy() bgc:Destroy()
bf:Destroy() bfc:Destroy()
p:Destroy()
return true
end

-- probe L2:8
local function _p_2_8()
local cv = Instance.new("CFrameValue")
cv.Value = CFrame.new(1.11, 2.22, 3.33)
local cvc = cv:Clone()
cv.Value = CFrame.new(0, 0, 0)
if cvc.Value == cv.Value then
    die()
end
if cvc.Value ~= CFrame.new(1.11, 2.22, 3.33) then
    die()
end

local v3 = Instance.new("Vector3Value")
v3.Value = Vector3.new(9.99, 8.88, 7.77)
local v3c = v3:Clone()
if v3c.Value ~= Vector3.new(9.99, 8.88, 7.77) then
    die()
end
v3.Value = Vector3.new(0, 0, 0)
if v3c.Value == v3.Value then
    die()
end

local c3 = Instance.new("Color3Value")
c3.Value = Color3.fromRGB(123, 45, 67)
local c3c = c3:Clone()
c3.Value = Color3.fromRGB(0, 0, 0)
if c3c.Value == c3.Value then
    die()
end
if c3c.Value ~= Color3.fromRGB(123, 45, 67) then
    die()
end

local sv = Instance.new("StringValue")
sv.Value = "sentinel_xyz_987"
local svc = sv:Clone()
sv.Value = ""
if svc.Value == sv.Value then
    die()
end
if svc.Value ~= "sentinel_xyz_987" then
    die()
end

cv:Destroy() cvc:Destroy()
v3:Destroy() v3c:Destroy()
c3:Destroy() c3c:Destroy()
sv:Destroy() svc:Destroy()
return true
end

-- probe L2:9
local function _p_2_9()
local sg = Instance.new("ScreenGui")

local tl = Instance.new("TextLabel") tl.Parent = sg
tl.Text = "canary_tl_777"
tl.TextSize = 24.5
tl.TextTransparency = 0.33
tl.LineHeight = 1.44
local tlc = tl:Clone()
tl.Text = ""
if tlc.Text == tl.Text then
    die()
end
tl.TextSize = 1
if tlc.TextSize == tl.TextSize then
    die()
end

local tb = Instance.new("TextBox") tb.Parent = sg
tb.PlaceholderText = "canary_tb_888"
tb.TextSize = 18.8
tb.LineHeight = 1.22
tb.TextTransparency = 0.55
local tbc = tb:Clone()
tb.PlaceholderText = ""
if tbc.PlaceholderText == tb.PlaceholderText then
    die()
end
if math.abs(tbc.LineHeight - 1.22) > 0.0001 then
    die()
end

local sf = Instance.new("ScrollingFrame") sf.Parent = sg
sf.ScrollBarThickness = 12
sf.ScrollBarImageTransparency = 0.77
local sfc = sf:Clone()
sf.ScrollBarThickness = 0
if sfc.ScrollBarThickness == sf.ScrollBarThickness then
    die()
end
if math.abs(sfc.ScrollBarImageTransparency - 0.77) > 0.0001 then
    die()
end

local il = Instance.new("ImageLabel") il.Parent = sg
il.ImageTransparency = 0.44
il.SliceScale = 2.22
local ilc = il:Clone()
il.SliceScale = 0
if ilc.SliceScale == il.SliceScale then
    die()
end
if math.abs(ilc.ImageTransparency - 0.44) > 0.0001 then
    die()
end

sg:Destroy()
return true
end

-- probe L3:1
local function _p_3_1()
local findings = {}
local function die() table.insert(findings, msg) end

local f1 = Instance.new("Folder")
f1:SetAttribute("__x", 3.14159)
f1:SetAttribute("__s", "poison")
local f1c = f1:Clone()
f1:SetAttribute("__x", 999)
f1:SetAttribute("__s", "mutated")
if f1c:GetAttribute("__x") == f1:GetAttribute("__x") then die() end
if f1c:GetAttribute("__s") == f1:GetAttribute("__s") then die() end
if f1c:GetAttribute("__x") == nil then die() end
f1:Destroy() f1c:Destroy()

local f2 = Instance.new("Folder")
f2:AddTag("__canary_lv3")
f2:AddTag("__canary_lv3_b")
local f2c = f2:Clone()
if not f2c:HasTag("__canary_lv3") then die() end
if not f2c:HasTag("__canary_lv3_b") then die() end
local tags = f2c:GetTags()
local count = 0
for _, t in ipairs(tags) do
    if t == "__canary_lv3" or t == "__canary_lv3_b" then count += 1 end
end
if count ~= 2 then die() end
f2:Destroy() f2c:Destroy()

local root = Instance.new("Folder") root.Name = "Root"
local child = Instance.new("Folder") child.Name = "Child" child.Parent = root
local grandchild = Instance.new("Folder") grandchild.Name = "GC" grandchild.Parent = child
local fullBefore = grandchild:GetFullName()
child.Name = "MUTATED"
local fullAfter = grandchild:GetFullName()
if fullBefore == fullAfter then die() end
if not fullAfter:find("MUTATED") then die() end
root:Destroy()

local a = Instance.new("Folder")
local b = Instance.new("Folder") b.Parent = a
local c4 = Instance.new("Folder") c4.Parent = b
if not a:IsAncestorOf(c4) then die() end
if not c4:IsDescendantOf(a) then die() end
c4.Parent = nil
if a:IsAncestorOf(c4) then die() end
if c4:IsDescendantOf(a) then die() end
a:Destroy() c4:Destroy()

local f5 = Instance.new("Folder")
local p5 = Instance.new("Folder")
local fireCount = 0
f5.AncestryChanged:Connect(function() fireCount += 1 end)
f5.Parent = p5
task.defer(function()
    if fireCount ~= 1 then die() end
    f5:Destroy() p5:Destroy()
end)

local f6 = Instance.new("Folder")
f6:SetAttribute("__secret", 42)
f6.Archivable = false
local f6c = f6:Clone()
if f6c ~= nil then die() end
f6:Destroy()

local root7 = Instance.new("Folder")
for i = 1, 5 do
    local ch = Instance.new("Folder") ch.Parent = root7
    for j = 1, 3 do
        local gch = Instance.new("Folder") gch.Parent = ch
    end
end
local desc = root7:GetDescendants()
if #desc ~= 20 then die() end
local cloned7 = root7:Clone()
if #cloned7:GetDescendants() ~= #desc then die() end
root7:Destroy() cloned7:Destroy()

local f8 = Instance.new("Folder")
f8:SetAttribute("__watch", 0)
local attrFired = false
f8:GetAttributeChangedSignal("__watch"):Connect(function() attrFired = true end)
local f8c = f8:Clone()
task.defer(function()
    if attrFired then die() end
    f8:SetAttribute("__watch", 1)
    task.defer(function()
        if not attrFired then die() end
        f8:Destroy() f8c:Destroy()
    end)
end)

local f9 = Instance.new("Folder")
local added, removed = 0, 0
f9.ChildAdded:Connect(function() added += 1 end)
f9.ChildRemoved:Connect(function() removed += 1 end)
local kids = {}
for i = 1, 4 do
    local k = Instance.new("Folder") k.Parent = f9
    table.insert(kids, k)
end
for _, k in ipairs(kids) do k.Parent = nil end
task.defer(function()
    if added ~= 4 then die() end
    if removed ~= 4 then die() end
    f9:Destroy()
    for _, k in ipairs(kids) do k:Destroy() end
end)

local f10 = Instance.new("Folder")
f10.Name = "original"
local f10c = f10:Clone()
local cloneFired = false
f10c:GetPropertyChangedSignal("Name"):Connect(function() cloneFired = true end)
f10.Name = "mutated_original"
task.defer(function()
    if cloneFired then die() end
    if f10c.Name ~= "original" then die() end
    f10:Destroy() f10c:Destroy()
    task.defer(function()
        if #findings == 0 then
            return true
        else
            for _, msg in ipairs(findings) do warn(msg) end
            die()
        end
    end)
end)
end

-- probe L3:2
local function _p_3_2()
local findings = {}
local function die() table.insert(findings, msg) end

local f1 = Instance.new("Folder")
f1.Name = "test"
if not f1:IsPropertyModified("Name") then die() end
f1:ResetPropertyToDefault("Name")
if f1:IsPropertyModified("Name") then die() end
if f1.Name ~= "Folder" then die() end
f1:Destroy()

local be = Instance.new("BindableEvent")
local fired = false
local firedVal = nil
be.Event:Connect(function(v) fired = true firedVal = v end)
be:Fire("__sentinel_777")
task.defer(function()
    if not fired then die() end
    if firedVal ~= "__sentinel_777" then die() end
    be:Destroy()
end)

local id1 = Instance.new("Folder"):GetDebugId(10)
local id2 = Instance.new("Folder"):GetDebugId(10)
local id3 = Instance.new("Folder"):GetDebugId(10)
if id1 == id2 or id2 == id3 or id1 == id3 then die() end

local ik = Instance.new("IKControl")
local p0 = Instance.new("Part")
local p1 = Instance.new("Part")
ik.ChainRoot = p0
ik.EndEffector = p1
ik.SmoothTime = 3.33
ik.Weight = 0.77
local ikc = ik:Clone()
if ikc.ChainRoot ~= p0 then die() end
if ikc.EndEffector ~= p1 then die() end
ik.ChainRoot = p1
if ikc.ChainRoot == ik.ChainRoot then die() end
if math.abs(ikc.SmoothTime - 3.33) > 0.0001 then die() end
ik:Destroy() ikc:Destroy() p0:Destroy() p1:Destroy()

local pose = Instance.new("Pose")
pose.CFrame = CFrame.new(1.11, 2.22, 3.33)
local sub1 = Instance.new("Pose") sub1.CFrame = CFrame.new(4, 5, 6)
local sub2 = Instance.new("Pose") sub2.CFrame = CFrame.new(7, 8, 9)
if pose.AddSubPose then
    pose:AddSubPose(sub1)
    pose:AddSubPose(sub2)
    local subs = pose:GetSubPoses()
    if #subs ~= 2 then die() end
    local posec = pose:Clone()
    local subsc = posec:GetSubPoses()
    if #subsc ~= 2 then die() end
    posec.CFrame = CFrame.new(0,0,0)
    if posec.CFrame == pose.CFrame then die() end
    posec:Destroy()
else
    die()
end
pose:Destroy() sub1:Destroy() sub2:Destroy()

local f6 = Instance.new("Folder")
f6:SetAttribute("__a", 11)
f6:SetAttribute("__b", 22)
f6:SetAttribute("__c", 33)
local attrs = f6:GetAttributes()
if attrs["__a"] ~= 11 then die() end
if attrs["__b"] ~= 22 then die() end
if attrs["__c"] ~= 33 then die() end
local count = 0
for _ in pairs(attrs) do count += 1 end
if count ~= 3 then die() end
f6:Destroy()

local plink = Instance.new("PathfindingLink")
local pa = Instance.new("Attachment")
local pb = Instance.new("Attachment")
plink.Attachment0 = pa
plink.Attachment1 = pb
plink.Label = "__pf_canary"
plink.IsBidirectional = true
local plinkc = plink:Clone()
if plinkc.Label ~= "__pf_canary" then die() end
if plinkc.IsBidirectional ~= true then die() end
plink.Label = ""
if plinkc.Label == plink.Label then die() end
if plinkc.Attachment0 ~= pa then die() end
plink:Destroy() plinkc:Destroy() pa:Destroy() pb:Destroy()

local bf = Instance.new("BindableFunction")
bf.OnInvoke = function(v) return v * 2 end
local result = bf:Invoke(21)
if result ~= 42 then die() end
bf.OnInvoke = function(v) return v + 1 end
local result2 = bf:Invoke(21)
if result2 ~= 22 then die() end
if result == result2 then die() end
bf:Destroy()

local pfm = Instance.new("PathfindingModifier")
pfm.Label = "__pfm_canary"
pfm.PassThrough = true
local pfmc = pfm:Clone()
pfm.Label = "changed"
pfm.PassThrough = false
if pfmc.Label == pfm.Label then die() end
if pfmc.PassThrough == pfm.PassThrough then die() end
if pfmc.Label ~= "__pfm_canary" then die() end
pfm:Destroy() pfmc:Destroy()

local destroying = false
local f10 = Instance.new("Folder")
f10.Destroying:Connect(function() destroying = true end)
local f10c = f10:Clone()
local destroyingClone = false
f10c.Destroying:Connect(function() destroyingClone = true end)
f10:Destroy()
task.defer(function()
    if not destroying then die() end
    if destroyingClone then die() end
    f10c:Destroy()
    task.defer(function()
        if not destroyingClone then die() end
        if #findings == 0 then
            return true
        else
            for _, msg in ipairs(findings) do warn(msg) end
            die()
        end
    end)
end)
end

-- probe L3:3
local function _p_3_3()
local findings = {}
local function die() table.insert(findings, msg) end

local ac = Instance.new("AudioChorus")
ac.Depth = 0.66
ac.Mix = 0.44
ac.Rate = 3.33
local acc = ac:Clone()
if math.abs(acc.Depth - ac.Depth) > 0.0001 then die() end
ac.Depth = 0
if acc.Depth == ac.Depth then die() end
if math.abs(acc.Rate - 3.33) > 0.0001 then die() end
ac:Destroy() acc:Destroy()

local mc = Instance.new("MarkerCurve")
mc:InsertMarkerAtTime(0.5, "marker_a")
mc:InsertMarkerAtTime(1.5, "marker_b")
if mc.Length ~= 2 then die() end
local mcc = mc:Clone()
if mcc.Length ~= 2 then die() end
local markers = mcc:GetMarkers()
if #markers ~= 2 then die() end
mc:RemoveMarkerAtIndex(1)
if mcc.Length == mc.Length then die() end
mc:Destroy() mcc:Destroy()

local kf = Instance.new("Keyframe")
kf.Time = 2.5
local km = Instance.new("KeyframeMarker")
km.Name = "__km_canary"
km.Value = "__marker_val"
kf:AddMarker(km)
local kfc = kf:Clone()
if math.abs(kfc.Time - 2.5) > 0.0001 then die() end
local kfmarkers = kfc:GetMarkers()
if #kfmarkers ~= 1 then die() end
if kfmarkers[1].Value ~= "__marker_val" then die() end
kf.Time = 99
if kfc.Time == kf.Time then die() end
kf:Destroy() kfc:Destroy()

local np = Instance.new("NumberPose")
np.Value = 7.77
np.Weight = 0.55
local npc = np:Clone()
if math.abs(npc.Value - 7.77) > 0.0001 then die() end
np.Value = 0
if npc.Value == np.Value then die() end
if math.abs(npc.Weight - 0.55) > 0.0001 then die() end
np:Destroy() npc:Destroy()

local ks = Instance.new("KeyframeSequence")
local kf1 = Instance.new("Keyframe") kf1.Time = 0
local kf2 = Instance.new("Keyframe") kf2.Time = 1
local kf3 = Instance.new("Keyframe") kf3.Time = 2
ks:AddKeyframe(kf1) ks:AddKeyframe(kf2) ks:AddKeyframe(kf3)
local kfs = ks:GetKeyframes()
if #kfs ~= 3 then die() end
local ksc = ks:Clone()
local kfsc = ksc:GetKeyframes()
if #kfsc ~= 3 then die() end
ks:RemoveKeyframe(kf1)
if #ks:GetKeyframes() == #ksc:GetKeyframes() then die() end
ks:Destroy() ksc:Destroy()

local rc = Instance.new("RotationCurve")
if rc.Length ~= 0 then die() end
local rcc = rc:Clone()
if rcc.Length ~= 0 then die() end
rc:Destroy() rcc:Destroy()

local f7a = Instance.new("Folder")
local f7b = Instance.new("Folder")
f7a:SetAttribute("__shared", 55)
f7b:SetAttribute("__shared", 55)
local a7 = f7a:GetAttributes()
local b7 = f7b:GetAttributes()
if a7["__shared"] ~= b7["__shared"] then die() end
f7a:SetAttribute("__shared", 99)
local a7new = f7a:GetAttributes()
if a7new["__shared"] == b7["__shared"] then die() end
f7a:Destroy() f7b:Destroy()

local be = Instance.new("BindableEvent")
local log = {}
be.Event:Connect(function(v) table.insert(log, v) end)
be:Fire("x") be:Fire("y") be:Fire("z")
task.defer(function()
    if #log ~= 3 then die() end
    if log[1] ~= "x" or log[2] ~= "y" or log[3] ~= "z" then die() end
    be:Destroy()
end)

local f9 = Instance.new("Folder")
f9.Name = "orig"
local id = f9:GetDebugId(4)
f9.Name = "changed"
local id2 = f9:GetDebugId(4)
if id ~= id2 then die() end
local f9b = Instance.new("Folder")
local idb = f9b:GetDebugId(4)
if id == idb then die() end
f9:Destroy() f9b:Destroy()

local f10 = Instance.new("Folder")
f10.Name = "sentinel"
f10:SetAttribute("__tag", 1337)
f10.Archivable = false
local f10c = f10:Clone()
if f10c ~= nil then die() end
f10.Archivable = true
local f10c2 = f10:Clone()
if f10c2 == nil then die() end
if f10c2:GetAttribute("__tag") ~= 1337 then die() end
if f10c2.Name ~= "sentinel" then die() end
f10:Destroy() f10c2:Destroy()

task.defer(function() task.defer(function()
    if #findings == 0 then
        return true
    else
        for _, msg in ipairs(findings) do warn(msg) end
        die()
    end
end) end)
end


local L1 = {_p_1_1, _p_1_2, _p_1_3, _p_1_4, _p_1_5, _p_1_6, _p_1_7, _p_1_8, _p_1_9, _p_1_10, _p_1_11, _p_1_12, _p_1_13, _p_1_14, _p_1_15, _p_1_16, _p_1_17, _p_1_18, _p_1_19, _p_1_20, _p_1_21}
local L2 = {_p_2_1, _p_2_2, _p_2_3, _p_2_4, _p_2_5, _p_2_6, _p_2_7, _p_2_8, _p_2_9}
local L3 = {_p_3_1, _p_3_2, _p_3_3}

local function run_list(list)
    local copy = {}
    for i = 1, #list do copy[i] = list[i] end
    shuffle(copy)
    for i = 1, #copy do
        local ok = pcall(copy[i])
        if not ok then die() end
    end
end

local AntiDump = {}
function AntiDump.run(level)
    level = level or 2
    if level >= 1 then run_list(L1) end
    if level >= 2 then run_list(L2) end
    if level >= 3 then run_list(L3) end
    return true
end
return AntiDump
`,Mn=`-- Chelo anti-hook / timing canaries (silent spin)
local function die()
    while true do end
end

local function timing_canary()
    local t0 = os.clock()
    local x = 0
    for i = 1, 80000 do
        x = x + i % 7
    end
    local dt = os.clock() - t0
    -- heavily hooked environments often distort tight loops; allow wide band
    if dt < 0 then die() end
    if x == -1 then die() end
end

local function meta_canary()
    if type(hookmetamethod) ~= "function" then
        return true
    end
    local ok = pcall(function()
        local orig
        orig = hookmetamethod(game, "__namecall", function(self, ...)
            if self == game and getnamecallmethod and getnamecallmethod() == "__chelo_canary" then
                return 0xC0FFEE
            end
            return orig(self, ...)
        end)
        local r = game:GetService("__chelo_canary")
        -- restore best-effort
        pcall(function()
            hookmetamethod(game, "__namecall", orig)
        end)
        -- if hooks are broken/mocked inconsistently, r may not match; only die on hard faults
        return true
    end)
    if not ok then
        -- environment rejects hooks oddly — do not hard-die on pure Roblox without hookmetamethod path
        return true
    end
end

local function loadstring_canary()
    local ls = loadstring or load
    if type(ls) ~= "function" then return true end
    local ok, fn = pcall(ls, "return 1337")
    if not ok or type(fn) ~= "function" then die() end
    local ok2, v = pcall(fn)
    if not ok2 or v ~= 1337 then die() end
end

local M = {}
function M.run()
    pcall(timing_canary)
    pcall(loadstring_canary)
    pcall(meta_canary)
    return true
end
return M
`;function Nn(e){if(typeof e==`string`)return`"${e.replace(/\\/g,`\\\\`).replace(/"/g,`\\"`).replace(/\n/g,`\\n`).replace(/\r/g,`\\r`)}"`;if(typeof e==`boolean`)return e?`true`:`false`;if(e==null)return`nil`;if(typeof e==`number`){if(!Number.isFinite(e))throw Error(`Número no finito en el runtime`);return String(e)}if(Array.isArray(e))return`{${e.map(Nn).join(`,`)}}`;if(typeof e==`object`)return`{${Object.entries(e).map(([e,t])=>`[${Nn(e)}]=${Nn(t)}`).join(`,`)}}`;throw Error(`Valor no serializable`)}function Pn(e){let t=``,n=32768;for(let r=0;r<e.length;r+=n)t+=String.fromCharCode(...e.subarray(r,Math.min(r+n,e.length)));return btoa(t)}var Fn=`
local function _die()
    while true do end
end

local function _run_module(b64)
    local src = _base64(b64)
    local loader = loadstring or load
    local fn = loader(src)
    if not fn then _die() end
    local ok, mod = pcall(fn)
    if not ok or type(mod) ~= "table" or type(mod.run) ~= "function" then _die() end
    if not pcall(mod.run, _AntiLevel) then _die() end
end

if _AntiLevel and _AntiLevel > 0 then
    _run_module(_AntiHookB64)
end

if _AntiLevel and _AntiLevel > 0 then
    _run_module(_AntiDumpB64)
end

local function _boot(raw)
    if type(raw) ~= "string" or #raw < 16 then _die() end
    if raw:sub(1, 8) ~= "CHLOV14\\0" then _die() end
    local p = 9
    local ver = Byte(raw, p)
    local endian = Byte(raw, p + 1)
    p = p + 2
    if ver ~= V14.Version or endian ~= 1 then _die() end
    local seed
    seed, p = _read32(raw, p)
    local n
    n, p = _read32(raw, p)
    if p + n + 32 - 1 ~= #raw then _die() end
    local body = raw:sub(p, p + n - 1)
    local digest = raw:sub(p + n, p + n + 31)
    if _sha256(body) ~= digest then _die() end
    return Deserialize(body)
end

local _raw = _base64(ObfuscatorBytecode)
local _chunk = _boot(_raw)
return Wrap(_chunk, _ENV or _G, {})
`;function In(e,t,n){let r=Pn(e),i=Pn(new TextEncoder().encode(jn)),a=Pn(new TextEncoder().encode(Mn)),o=`local V14=${Nn({Version:t.Version,Seed:t.Seed,OpcodeMap:t.OpcodeMap,Registers:t.Registers,ConstantTags:t.ConstantTags,Key:t.Key,OpcodeTypes:Object.fromEntries(Yt.map(e=>[e,t.OpcodeTypes[e]]))})}`;return On.replace(`|OBFUSCATOR_BYTECODE|`,`"${r}"`).replace(`|V14_RUNTIME|`,o)+`\nlocal _AntiDumpB64 = "${i}"\nlocal _AntiHookB64 = "${a}"\nlocal _AntiLevel = ${n|0}\n
`+kn+`
`+An+`
`+Fn}function Ln(e){let t=e.instructions.length,n=e.constants.length,r=e.prototypes.length;for(let i of e.prototypes){let e=Ln(i);t+=e.instructions,n+=e.constants,r+=e.prototypes}return{instructions:t,constants:n,prototypes:r}}var Rn=new Set([`Loadk+Add`,`Loadk+Sub`,`GetGlobal+Call`,`Move+Call`,`Loadk+Loadk`,`GetGlobal+GetTable`,`Self+Call`]),zn=new Set([`Test`,`Eq`,`Lt`,`Le`,`TestSet`,`TForLoop`]);function Bn(e){let t=new Set;return e.instructions.forEach((n,r)=>{if(n.op!==`Closure`)return;t.add(r);let i=e.prototypes[n.b]?.upvalCount??0;for(let e=1;e<=i;e++)t.add(r+e)}),t}function Vn(e){e.prototypes.forEach(Vn)}function Hn(e,t){if(t>0){let n=e.instructions,r=Bn(e),i=[],a=new Map;for(let e=0;e<n.length;e++)if(a.set(e,i.length),i.push(n[e]),(e+1)%t===0&&!r.has(e)&&!r.has(e+1)){let e=Zt(`Junk`);e.junk=!0,i.push(e)}a.set(n.length,i.length);for(let e of i)if(e.target!=null){let t=a.get(e.target);if(t==null)throw Error(`Salto inválido tras insertar junk`);e.target=t}e.instructions=i}e.prototypes.forEach(e=>Hn(e,t))}function Un(e){let t=e.instructions,n=Bn(e),r=new Set;for(let e of t)e.target!=null&&r.add(e.target);let i=[],a=new Map,o=0;for(;o<t.length;){let e=t[o],s=t[o+1];if(s&&Rn.has(`${e.op}+${s.op}`)&&!n.has(o)&&!n.has(o+1)&&!e.bind&&!s.bind&&!r.has(o+1)&&!zn.has(e.op)&&(e.op!==`LoadBool`||e.c===0)&&e.target==null&&s.target==null&&!e.junk&&!s.junk&&s){a.set(o,i.length),a.set(o+1,i.length);let t=Zt(`Super`,e.a,e.b,e.c);t.superOps=[{op:e.op,a:e.a,b:e.b,c:e.c},{op:s.op,a:s.a,b:s.b,c:s.c}],i.push(t),o+=2}else a.set(o,i.length),i.push(e),o+=1}a.set(t.length,i.length);for(let e of i)if(e.target!=null){let t=a.get(e.target);if(t==null)throw Error(`Salto inválido tras super-ops`);e.target=t}e.instructions=i,e.prototypes.forEach(Un)}function Wn(e){let t=e>>>0;return()=>{t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function Gn(e,t){let n=t.slice();for(let t=n.length-1;t>0;t--){let r=Math.floor(e()*(t+1)),i=n[t];n[t]=n[r],n[r]=i}return n}function Kn(e,t){let n=Gn(e,t),r={},i=0;for(let[e,t]of n)r[e]={Start:i,Length:t},i+=t;return r}function qn(e){let t=e>>>0,n=Wn(t),r=Gn(n,Yt.map((e,t)=>t)),i={};Yt.forEach((e,t)=>{i[e]=r[t]});let a=t.toString(16).padStart(8,`0`),o=Array.from(an(new TextEncoder().encode(`chelo-v14:${a}`))),s=[`Nil`,`Boolean`,`Number`,`String`],c={};for(let e of s)c[e]=1+Math.floor(n()*249);let l={};for(let e of Yt)l[e]=Xt[e];return{Version:14,Seed:t,OpcodeMap:i,Registers:{ABC:Kn(n,[[`A`,8],[`B`,9],[`C`,9],[`Mode`,3],[`Enum`,3]]),ABx:Kn(n,[[`A`,8],[`B`,18],[`Mode`,3],[`Enum`,3]]),AsBx:Kn(n,[[`A`,8],[`B`,18],[`Mode`,3],[`Enum`,3]])},ConstantTags:c,Key:o,ChunkStructure:Gn(n,[`UpvalCount`,`ParameterCount`,`VarargCount`,`Constants`,`Instructions`,`Prototypes`]),OpcodeTypes:l}}function Jn(e,t,n){return Math.max(t,Math.min(n,e))}function Yn(e,t={}){let n=Jn(t.antiLevel??2,0,3),r=Jn(t.junkEvery??5,0,50),i=t.superops!==!1,a=t.seed;if(a==null||Number.isNaN(a)){let e=new Uint32Array(1);crypto.getRandomValues(e),a=e[0]}a>>>=0;let o=`lua`,s;if(e instanceof Uint8Array)o=`luac`,s=Dn(e),$t(s);else{let t=e.replace(/^\uFEFF/,``);if(!t.trim())throw Error(`Pega código Lua o sube un .lua / .luac`);s=Cn(t)}en(s),Vn(s),r>0&&Hn(s,r),i&&Un(s),tn(s);let c=qn(a),l=dn(s,c),u=`-- Chelo Obfuscator v14 · seed ${a} · anti ${n}\n${In(l,c,n)}`,d=Ln(s);return{lua:u,meta:{seed:a,antiLevel:n,junkEvery:r,superops:i,payloadBytes:l.length,outputBytes:u.length,...d,source:o}}}var Xn=`chelo-draft-v1`,Zn=`chelo-history-v1`,Qn=[{id:`hola`,label:`Hola`,source:`print("hola desde chelo")
`},{id:`fib`,label:`Fibonacci`,source:`local function fib(n)
  if n < 2 then
    return n
  end
  return fib(n - 1) + fib(n - 2)
end

print(fib(10))
`},{id:`tabla`,label:`Tabla`,source:`local inventory = {
  name = "chelo",
  slots = 8,
}

for i = 1, inventory.slots do
  inventory[i] = i * i
end

print(inventory.name, inventory[3])
`},{id:`cierre`,label:`Cierre`,source:`local function counter(start)
  local n = start or 0
  return function(step)
    n = n + (step or 1)
    return n
  end
end

local tick = counter(10)
print(tick())
print(tick(4))
`},{id:`bucle`,label:`Bucle`,source:`local n = 1
repeat
  n = n * 2
until n > 32

local sum = 0
local i = 1
while i <= 5 do
  sum = sum + i
  i = i + 1
end

print(n, sum)
`}],$n=[{id:`light`,label:`Ligero`,anti:1,junk:0,superops:!1,hint:`Poco ruido, arranque corto`},{id:`std`,label:`Estándar`,anti:2,junk:5,superops:!0,hint:`El que usarías por defecto`},{id:`max`,label:`Máximo`,anti:3,junk:12,superops:!0,hint:`Canaries y más junk`}],er=[{value:0,label:`Off`,hint:`Sin anti-dump. Sirve para depurar la salida.`},{value:1,label:`1`,hint:`Capa rápida: anti-hook y sondas ligeras.`},{value:2,label:`2`,hint:`Estándar: anti-hook más anti-dump.`},{value:3,label:`3`,hint:`Completo: incluye los canaries de nivel 3.`}];function tr(e){return e.length>=4&&e[0]===27&&e[1]===76&&e[2]===117&&e[3]===97}function nr(e){return e<1024?`${e} B`:`${(e/1024).toLocaleString(`es`,{maximumFractionDigits:1})} KB`}function rr(e){return new Date(e).toLocaleString(`es`,{hour:`2-digit`,minute:`2-digit`,day:`2-digit`,month:`short`})}function ir(){return(0,k.jsxs)(`svg`,{viewBox:`0 0 32 32`,"aria-hidden":`true`,className:`size-9`,children:[(0,k.jsx)(`rect`,{width:`32`,height:`32`,rx:`8`,className:`fill-primary`}),(0,k.jsx)(`path`,{d:`M22.5 9.2a8.2 8.2 0 1 0 2.1 6.3h-3.1a5.2 5.2 0 1 1-1.3-3.6H16V9.2h6.5Z`,className:`fill-ink`})]})}function ar(){let e=(0,h.useId)(),t=(0,h.useRef)(null),[n,r]=(0,h.useState)(Qn[0].source),[i,a]=(0,h.useState)(null),[g,_]=(0,h.useState)(``),[v,y]=(0,h.useState)(``),[b,x]=(0,h.useState)(2),[S,C]=(0,h.useState)(5),[w,ee]=(0,h.useState)(!0),[T,te]=(0,h.useState)(!1),[ne,E]=(0,h.useState)(null),[D,O]=(0,h.useState)(null),[A,j]=(0,h.useState)(!1),[M,N]=(0,h.useState)([]),[re,P]=(0,h.useState)(!1);(0,h.useEffect)(()=>{try{let e=localStorage.getItem(Xn);if(e){let t=JSON.parse(e);typeof t.source==`string`&&t.source.length>0&&r(t.source),typeof t.seed==`string`&&y(t.seed),typeof t.anti==`number`&&x(Math.max(0,Math.min(3,t.anti))),typeof t.junk==`number`&&C(Math.max(0,Math.min(20,t.junk))),typeof t.superops==`boolean`&&ee(t.superops)}let t=localStorage.getItem(Zn);if(t){let e=JSON.parse(t);Array.isArray(e)&&N(e.slice(0,6))}}catch{}P(!0)},[]),(0,h.useEffect)(()=>{if(!re)return;let e=window.setTimeout(()=>{try{localStorage.setItem(Xn,JSON.stringify({source:n,seed:v,anti:b,junk:S,superops:w}))}catch{}},250);return()=>window.clearTimeout(e)},[n,v,b,S,w,re]),(0,h.useEffect)(()=>{let e=e=>{(e.metaKey||e.ctrlKey)&&e.key===`Enter`&&(e.preventDefault(),L())};return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)});let F=er.find(e=>e.value===b)?.hint??``,I=$n.find(e=>e.anti===b&&e.junk===S&&e.superops===w)?.id,ie=(0,h.useMemo)(()=>{if(!D)return[];let{meta:e}=D;return[[`Semilla`,String(e.seed)],[`Origen`,e.source===`luac`?`.luac`:`Lua`],[`Instrucciones`,String(e.instructions)],[`Constantes`,String(e.constants)],[`Prototipos`,String(e.prototypes)],[`Payload`,nr(e.payloadBytes)],[`Salida`,nr(e.outputBytes)],[`Anti`,String(e.antiLevel)]]},[D]);function ae(e){let t=Qn.find(t=>t.id===e);t&&(r(t.source),a(null),_(``),E(null))}function oe(e){let t=$n.find(t=>t.id===e);t&&(x(t.anti),C(t.junk),ee(t.superops))}async function se(e){let t=new Uint8Array(await e.arrayBuffer()),n=e.name.toLowerCase();if(tr(t)||n.endsWith(`.luac`)){if(!tr(t)){E(`Ese archivo no tiene la cabecera de un binario Lua 5.1.`);return}a({name:e.name,bytes:t}),_(e.name),E(null);return}a(null),r(new TextDecoder().decode(t).replace(/^\uFEFF/,``)),_(e.name),E(null)}async function L(){te(!0),E(null),j(!1),await new Promise(e=>window.setTimeout(e,30));try{let e=v.trim()===``?null:Number(v);if(e!=null&&!Number.isFinite(e))throw Error(`La semilla tiene que ser un número.`);let t=Yn(i?i.bytes:n,{seed:e,antiLevel:b,junkEvery:S,superops:w});O(t),v.trim()===``&&y(String(t.meta.seed));let r={id:`${t.meta.seed}-${Date.now()}`,at:Date.now(),label:g||n.trim().split(`
`)[0]?.slice(0,42)||`script`,source:n,seed:t.meta.seed,anti:b,junk:S,superops:w,outputBytes:t.meta.outputBytes};N(e=>{let t=[r,...e].slice(0,6);try{localStorage.setItem(Zn,JSON.stringify(t))}catch{}return t})}catch(e){O(null),E(e instanceof Error?e.message:`No se pudo ofuscar.`)}finally{te(!1)}}async function ce(){if(D){try{await navigator.clipboard.writeText(D.lua)}catch{let e=document.createElement(`textarea`);e.value=D.lua,document.body.appendChild(e),e.select(),document.execCommand(`copy`),e.remove()}j(!0),window.setTimeout(()=>j(!1),1600)}}function le(){if(!D)return;let e=new Blob([D.lua],{type:`text/plain;charset=utf-8`}),t=URL.createObjectURL(e),n=document.createElement(`a`);n.href=t,n.download=`chelo_${D.meta.seed}.lua`,n.click(),URL.revokeObjectURL(t)}function ue(e){r(e.source),a(null),_(``),y(String(e.seed)),x(e.anti),C(e.junk),ee(e.superops),E(null)}function de(){r(``),a(null),_(``),O(null),E(null)}return(0,k.jsxs)(`div`,{className:`min-h-screen bg-bg text-fg`,children:[(0,k.jsx)(`header`,{className:`border-b border-line`,children:(0,k.jsxs)(`div`,{className:`mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4`,children:[(0,k.jsxs)(`div`,{className:`flex min-w-0 items-center gap-3`,children:[(0,k.jsx)(ir,{}),(0,k.jsxs)(`div`,{className:`min-w-0`,children:[(0,k.jsx)(`h1`,{className:`truncate text-lg font-semibold tracking-tight text-balance`,children:`Chelo Obfuscator`}),(0,k.jsx)(`p`,{className:`truncate text-sm text-muted`,children:`VM CHLOV14 · Lua 5.1 · se queda en este navegador`})]})]}),(0,k.jsxs)(`p`,{className:`hidden items-center gap-2 rounded-full bg-surface px-3 py-2 text-xs text-muted shadow-card sm:flex`,children:[(0,k.jsx)(`span`,{className:`size-2 rounded-full bg-primary`,"aria-hidden":`true`}),`v14 listo`]})]})}),(0,k.jsxs)(`main`,{className:`mx-auto flex max-w-6xl flex-col gap-4 px-4 py-5`,children:[(0,k.jsxs)(`div`,{className:`grid items-start gap-4 lg:grid-cols-2`,children:[(0,k.jsxs)(`section`,{className:`flex min-w-0 flex-col rounded-2xl bg-surface p-2 shadow-card`,children:[(0,k.jsxs)(`div`,{className:`flex flex-wrap items-center justify-between gap-2 px-3 py-2`,children:[(0,k.jsxs)(`div`,{children:[(0,k.jsx)(`h2`,{className:`text-sm font-medium`,children:`Fuente`}),(0,k.jsx)(`p`,{className:`text-xs text-pretty text-muted`,children:`Pega Lua 5.1 o sube .lua / .luac`})]}),(0,k.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2`,children:[(0,k.jsx)(`label`,{className:`sr-only`,htmlFor:`sample`,children:`Ejemplos`}),(0,k.jsxs)(`select`,{id:`sample`,className:`h-11 rounded-lg border border-line bg-bg px-3 text-sm text-fg`,defaultValue:``,onChange:e=>{e.target.value&&ae(e.target.value),e.target.value=``},children:[(0,k.jsx)(`option`,{value:``,disabled:!0,children:`Ejemplos`}),Qn.map(e=>(0,k.jsx)(`option`,{value:e.id,children:e.label},e.id))]}),(0,k.jsx)(`input`,{ref:t,id:e,type:`file`,accept:`.lua,.luac,.txt`,className:`sr-only`,onChange:e=>{let t=e.target.files?.[0];t&&se(t),e.target.value=``}}),(0,k.jsxs)(`button`,{type:`button`,className:`inline-flex h-11 items-center gap-2 rounded-lg border border-line bg-bg px-3 text-sm`,onClick:()=>t.current?.click(),children:[(0,k.jsx)(u,{className:`size-4`,"aria-hidden":`true`}),`Subir`]}),(0,k.jsx)(`button`,{type:`button`,className:`inline-flex size-11 items-center justify-center rounded-lg border border-line bg-bg`,onClick:de,"aria-label":`Vaciar fuente`,children:(0,k.jsx)(m,{className:`size-4`,"aria-hidden":`true`})})]})]}),i?(0,k.jsxs)(`div`,{className:`mx-2 mb-2 flex items-center justify-between gap-3 rounded-lg bg-bg px-3 py-3 text-sm`,children:[(0,k.jsxs)(`p`,{className:`min-w-0 truncate`,children:[`Bytecode `,(0,k.jsx)(`span`,{className:`font-medium`,children:i.name}),(0,k.jsxs)(`span`,{className:`text-muted`,children:[` · `,nr(i.bytes.length),` · el texto de abajo no se usa`]})]}),(0,k.jsx)(`button`,{type:`button`,className:`h-11 shrink-0 rounded-lg px-3 text-sm text-primary`,onClick:()=>{a(null),_(``)},children:`Quitar`})]}):null,(0,k.jsx)(`textarea`,{value:n,spellCheck:!1,"aria-label":`Código Lua`,placeholder:`print("hola")`,onChange:e=>r(e.target.value),className:`min-h-80 w-full resize-y rounded-lg bg-bg p-4 font-mono text-sm leading-relaxed text-fg outline-none placeholder:text-muted`})]}),(0,k.jsxs)(`section`,{className:`flex min-w-0 flex-col rounded-2xl bg-surface p-2 shadow-card`,children:[(0,k.jsxs)(`div`,{className:`flex flex-wrap items-center justify-between gap-2 px-3 py-2`,children:[(0,k.jsxs)(`div`,{children:[(0,k.jsx)(`h2`,{className:`text-sm font-medium`,children:`Resultado`}),(0,k.jsx)(`p`,{className:`text-xs text-pretty text-muted`,children:D?`chelo_${D.meta.seed}.lua`:`Aparece aquí, listo para copiar o descargar`})]}),(0,k.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,k.jsxs)(`button`,{type:`button`,disabled:!D,onClick:()=>void ce(),className:`inline-flex h-11 items-center gap-2 rounded-lg border border-line bg-bg px-3 text-sm disabled:opacity-40`,children:[A?(0,k.jsx)(o,{className:`size-4`,"aria-hidden":`true`}):(0,k.jsx)(s,{className:`size-4`,"aria-hidden":`true`}),A?`Copiado`:`Copiar`]}),(0,k.jsxs)(`button`,{type:`button`,disabled:!D,onClick:le,className:`inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-3 text-sm font-medium text-ink disabled:opacity-40`,children:[(0,k.jsx)(l,{className:`size-4`,"aria-hidden":`true`}),`Descargar`]})]})]}),(0,k.jsx)(`textarea`,{readOnly:!0,value:D?.lua??``,spellCheck:!1,"aria-label":`Script ofuscado`,placeholder:`El script ofuscado sale aquí. Nada se envía a un servidor.`,className:`min-h-80 w-full resize-y rounded-lg bg-bg p-4 font-mono text-sm leading-relaxed text-fg outline-none placeholder:text-muted`})]})]}),(0,k.jsxs)(`section`,{className:`rounded-2xl bg-surface p-4 shadow-card`,children:[(0,k.jsxs)(`div`,{className:`grid gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)_minmax(0,0.8fr)]`,children:[(0,k.jsxs)(`div`,{className:`flex flex-col gap-3`,children:[(0,k.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Preset`}),(0,k.jsx)(`div`,{className:`grid grid-cols-3 gap-2`,children:$n.map(e=>(0,k.jsx)(`button`,{type:`button`,onClick:()=>oe(e.id),"aria-pressed":I===e.id,className:`h-11 rounded-lg border px-2 text-sm `+(I===e.id?`border-primary bg-primary text-ink`:`border-line bg-bg text-fg`),children:e.label},e.id))}),(0,k.jsx)(`p`,{className:`text-xs text-pretty text-muted`,children:$n.find(e=>e.id===I)?.hint??`Ajuste manual`})]}),(0,k.jsxs)(`div`,{className:`flex flex-col gap-3`,children:[(0,k.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Anti-dump`}),(0,k.jsx)(`div`,{className:`grid grid-cols-4 gap-2`,role:`group`,"aria-label":`Nivel anti-dump`,children:er.map(e=>(0,k.jsx)(`button`,{type:`button`,"aria-pressed":b===e.value,onClick:()=>x(e.value),className:`h-11 rounded-lg border text-sm `+(b===e.value?`border-primary bg-primary text-ink`:`border-line bg-bg text-fg`),children:e.label},e.value))}),(0,k.jsx)(`p`,{className:`text-xs text-pretty text-muted`,children:F})]}),(0,k.jsxs)(`div`,{className:`flex flex-col gap-3`,children:[(0,k.jsxs)(`div`,{className:`flex items-center justify-between gap-3`,children:[(0,k.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Semilla`}),(0,k.jsxs)(`button`,{type:`button`,className:`inline-flex h-11 items-center gap-1 text-xs text-primary`,onClick:()=>y(``),children:[(0,k.jsx)(c,{className:`size-3.5`,"aria-hidden":`true`}),`Aleatoria`]})]}),(0,k.jsx)(`input`,{inputMode:`numeric`,value:v,placeholder:`vacío = nueva`,"aria-label":`Semilla`,onChange:e=>y(e.target.value.replace(/[^\d]/g,``).slice(0,10)),className:`h-11 rounded-lg border border-line bg-bg px-3 font-mono text-sm tabular-nums outline-none placeholder:text-muted focus:border-primary`}),(0,k.jsx)(`p`,{className:`text-xs text-pretty text-muted`,children:`Misma semilla, mismo mapa de opcodes.`})]})]}),(0,k.jsxs)(`div`,{className:`mt-5 grid items-end gap-5 border-t border-line pt-5 md:grid-cols-[minmax(0,1fr)_auto_auto]`,children:[(0,k.jsxs)(`div`,{children:[(0,k.jsxs)(`div`,{className:`mb-2 flex items-baseline justify-between`,children:[(0,k.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Junk`}),(0,k.jsx)(`p`,{className:`font-mono text-sm tabular-nums`,children:S===0?`off`:`cada ${S}`})]}),(0,k.jsxs)(tt,{className:`relative flex h-11 w-full touch-none items-center`,min:0,max:20,step:1,value:[S],onValueChange:e=>C(e[0]??0),children:[(0,k.jsx)(ct,{className:`relative h-1.5 grow rounded-full bg-raised`,children:(0,k.jsx)(ut,{className:`absolute h-full rounded-full bg-primary`})}),(0,k.jsx)(_t,{"aria-label":`Cada cuántas instrucciones se inserta junk`,className:`block size-5 rounded-full bg-primary shadow-card outline-none focus-visible:ring-2 focus-visible:ring-primary`})]})]}),(0,k.jsxs)(`label`,{className:`flex h-11 items-center gap-3 rounded-lg border border-line bg-bg px-3`,children:[(0,k.jsx)(Ht,{checked:w,onCheckedChange:ee,className:`relative h-7 w-12 shrink-0 rounded-full bg-raised outline-none data-[state=checked]:bg-primary focus-visible:ring-2 focus-visible:ring-primary`,children:(0,k.jsx)(Wt,{className:`block size-5 translate-x-1 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-6 data-[state=checked]:bg-ink`})}),(0,k.jsx)(`span`,{className:`text-sm`,children:`Super-ops`})]}),(0,k.jsxs)(`button`,{type:`button`,onClick:()=>void L(),disabled:T||!i&&!n.trim(),className:`inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-5 text-sm font-semibold text-ink disabled:opacity-40`,children:[(0,k.jsx)(f,{className:`size-4`,"aria-hidden":`true`}),T?`Ofuscando…`:`Ofuscar`]})]}),ne?(0,k.jsx)(`p`,{role:`alert`,className:`mt-4 rounded-lg bg-bg px-3 py-3 text-sm text-pretty text-danger`,children:ne}):null]}),D?(0,k.jsx)(`dl`,{className:`grid grid-cols-2 gap-2 sm:grid-cols-4`,children:ie.map(([e,t])=>(0,k.jsxs)(`div`,{className:`rounded-xl bg-surface px-3 py-3 shadow-card`,children:[(0,k.jsx)(`dt`,{className:`text-xs text-muted`,children:e}),(0,k.jsx)(`dd`,{className:`mt-1 font-mono text-sm tabular-nums`,children:t})]},e))}):null,M.length>0?(0,k.jsxs)(`section`,{children:[(0,k.jsxs)(`h2`,{className:`mb-2 flex items-center gap-2 text-sm font-medium`,children:[(0,k.jsx)(d,{className:`size-4 text-muted`,"aria-hidden":`true`}),`Recientes`]}),(0,k.jsx)(`ul`,{className:`flex gap-2 overflow-x-auto pb-1`,children:M.map(e=>(0,k.jsx)(`li`,{className:`shrink-0`,children:(0,k.jsxs)(`button`,{type:`button`,onClick:()=>ue(e),className:`h-11 max-w-56 truncate rounded-lg border border-line bg-surface px-3 text-left text-sm`,children:[(0,k.jsx)(`span`,{className:`font-mono text-xs text-primary tabular-nums`,children:e.seed}),(0,k.jsxs)(`span`,{className:`text-muted`,children:[` · `,rr(e.at)]})]})},e.id))})]}):null,(0,k.jsxs)(`section`,{className:`grid gap-3 pb-8 md:grid-cols-3`,children:[(0,k.jsxs)(`article`,{className:`rounded-2xl bg-surface p-4 shadow-card`,children:[(0,k.jsx)(p,{className:`mb-3 size-5 text-primary`,"aria-hidden":`true`}),(0,k.jsx)(`h2`,{className:`text-sm font-medium`,children:`Qué hace`}),(0,k.jsx)(`p`,{className:`mt-2 text-sm leading-relaxed text-pretty text-muted`,children:`Compila tu script a una VM propia. Cada semilla baraja opcodes, el layout de registros y la clave. La salida trae el runtime, un chequeo SHA-256 y el anti-dump que elijas.`})]}),(0,k.jsxs)(`article`,{className:`rounded-2xl bg-surface p-4 shadow-card`,children:[(0,k.jsx)(f,{className:`mb-3 size-5 text-primary`,"aria-hidden":`true`}),(0,k.jsx)(`h2`,{className:`text-sm font-medium`,children:`Cómo usarlo`}),(0,k.jsx)(`p`,{className:`mt-2 text-sm leading-relaxed text-pretty text-muted`,children:`Pega el fuente, pulsa Ofuscar y descarga el .lua. Ejecútalo donde ya corría el original, con load o loadstring. Ctrl o Cmd + Enter también ofusca.`})]}),(0,k.jsxs)(`article`,{className:`rounded-2xl bg-surface p-4 shadow-card`,children:[(0,k.jsx)(u,{className:`mb-3 size-5 text-primary`,"aria-hidden":`true`}),(0,k.jsx)(`h2`,{className:`text-sm font-medium`,children:`Límites reales`}),(0,k.jsx)(`p`,{className:`mt-2 text-sm leading-relaxed text-pretty text-muted`,children:`Lua 5.1. Sin goto, sin Luau y sin el producto comercial de Luraph. Un .luac tiene que ser 5.1 estándar (int32, instrucciones de 4 bytes, doubles).`})]})]})]})]})}var or=ar;export{or as component};