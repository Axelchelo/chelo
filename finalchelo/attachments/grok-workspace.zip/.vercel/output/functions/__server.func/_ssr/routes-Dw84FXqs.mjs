import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as History, c as Dices, i as Lock, l as Copy, n as Trash2, o as FileUp, r as Shield, s as Download, u as Check } from "../_libs/lucide-react.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch } from "../_libs/radix-ui__react-switch.mjs";
import { t as require_luaparse } from "../_libs/luaparse.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dw84FXqs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_luaparse = require_luaparse();
var OPCODES = [
	"Move",
	"Loadk",
	"LoadBool",
	"LoadNil",
	"GetUpval",
	"GetGlobal",
	"GetTable",
	"SetGlobal",
	"SetUpval",
	"SetTable",
	"NewTable",
	"Self",
	"Add",
	"Sub",
	"Mul",
	"Div",
	"Mod",
	"Pow",
	"Unm",
	"Not",
	"Len",
	"Concat",
	"Jmp",
	"Eq",
	"Lt",
	"Le",
	"Test",
	"TestSet",
	"Call",
	"TailCall",
	"Return",
	"ForLoop",
	"ForPrep",
	"TForLoop",
	"SetList",
	"Close",
	"Closure",
	"VarArg",
	"Junk",
	"Super"
];
var OP_TYPE = {
	Move: "ABC",
	Loadk: "ABx",
	LoadBool: "ABC",
	LoadNil: "ABC",
	GetUpval: "ABC",
	GetGlobal: "ABx",
	GetTable: "ABC",
	SetGlobal: "ABx",
	SetUpval: "ABC",
	SetTable: "ABC",
	NewTable: "ABC",
	Self: "ABC",
	Add: "ABC",
	Sub: "ABC",
	Mul: "ABC",
	Div: "ABC",
	Mod: "ABC",
	Pow: "ABC",
	Unm: "ABC",
	Not: "ABC",
	Len: "ABC",
	Concat: "ABC",
	Jmp: "AsBx",
	Eq: "ABC",
	Lt: "ABC",
	Le: "ABC",
	Test: "ABC",
	TestSet: "ABC",
	Call: "ABC",
	TailCall: "ABC",
	Return: "ABC",
	ForLoop: "AsBx",
	ForPrep: "AsBx",
	TForLoop: "ABC",
	SetList: "ABC",
	Close: "ABC",
	Closure: "ABx",
	VarArg: "ABC",
	Junk: "DATA",
	Super: "DATA"
};
function makeIns(op, a = 0, b = 0, c = 0) {
	return {
		op,
		a,
		b,
		c,
		target: null,
		junk: false,
		bind: false,
		superOps: null
	};
}
var JUMPS = /* @__PURE__ */ new Set([
	"Jmp",
	"ForLoop",
	"ForPrep"
]);
function linkJumps(fn) {
	fn.instructions.forEach((ins, i) => {
		if (JUMPS.has(ins.op) && ins.target == null) ins.target = i + ins.b + 1;
	});
	fn.prototypes.forEach(linkJumps);
}
function markBinds(fn) {
	const ins = fn.instructions;
	for (let i = 0; i < ins.length; i++) {
		if (ins[i].op !== "Closure") continue;
		const n = fn.prototypes[ins[i].b]?.upvalCount ?? 0;
		for (let k = 1; k <= n; k++) if (ins[i + k]) ins[i + k].bind = true;
	}
	fn.prototypes.forEach(markBinds);
}
function finalizeJumps(fn) {
	const ins = fn.instructions;
	for (let i = 0; i < ins.length; i++) if (ins[i].target != null) ins[i].b = ins[i].target - i - 1;
	fn.prototypes.forEach(finalizeJumps);
}
var K = new Uint32Array([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]);
function rotr(x, n) {
	return x >>> n | x << 32 - n;
}
function sha256(data) {
	const bitLen = data.length * 8;
	const withOne = data.length + 1;
	const pad = (64 - (withOne + 8) % 64) % 64;
	const buf = new Uint8Array(withOne + pad + 8);
	buf.set(data);
	buf[data.length] = 128;
	const view = new DataView(buf.buffer);
	const hi = Math.floor(bitLen / 2 ** 32);
	view.setUint32(buf.length - 8, hi, false);
	view.setUint32(buf.length - 4, bitLen >>> 0, false);
	let h0 = 1779033703, h1 = 3144134277, h2 = 1013904242, h3 = 2773480762;
	let h4 = 1359893119, h5 = 2600822924, h6 = 528734635, h7 = 1541459225;
	const w = /* @__PURE__ */ new Uint32Array(64);
	for (let off = 0; off < buf.length; off += 64) {
		for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4, false);
		for (let i = 16; i < 64; i++) {
			const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
			const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
			w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
		}
		let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
		for (let i = 0; i < 64; i++) {
			const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
			const ch = e & f ^ ~e & g;
			const t1 = h + S1 + ch + K[i] + w[i] >>> 0;
			const t2 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + (a & b ^ a & c ^ b & c) >>> 0;
			h = g;
			g = f;
			f = e;
			e = d + t1 >>> 0;
			d = c;
			c = b;
			b = a;
			a = t1 + t2 >>> 0;
		}
		h0 = h0 + a >>> 0;
		h1 = h1 + b >>> 0;
		h2 = h2 + c >>> 0;
		h3 = h3 + d >>> 0;
		h4 = h4 + e >>> 0;
		h5 = h5 + f >>> 0;
		h6 = h6 + g >>> 0;
		h7 = h7 + h >>> 0;
	}
	const out = /* @__PURE__ */ new Uint8Array(32);
	const ov = new DataView(out.buffer);
	[
		h0,
		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		h7
	].forEach((h, i) => ov.setUint32(i * 4, h, false));
	return out;
}
var MAGIC = new Uint8Array([
	67,
	72,
	76,
	79,
	86,
	49,
	52,
	0
]);
function u32(n) {
	const b = /* @__PURE__ */ new Uint8Array(4);
	new DataView(b.buffer).setUint32(0, n >>> 0, true);
	return b;
}
function concat(parts) {
	let n = 0;
	for (const p of parts) n += p.length;
	const o = new Uint8Array(n);
	let i = 0;
	for (const p of parts) {
		o.set(p, i);
		i += p.length;
	}
	return o;
}
function xorBytes(data, key, salt) {
	const o = new Uint8Array(data.length);
	for (let i = 0; i < data.length; i++) o[i] = data[i] ^ key[(i + salt) % key.length];
	return o;
}
function pack(layout, values) {
	let out = 0;
	for (const [name, spec] of Object.entries(layout)) {
		const mask = 2 ** spec.Length - 1;
		const raw = Math.trunc(values[name] ?? 0);
		const v = raw < 0 ? raw + 2 ** spec.Length & mask : raw & mask;
		out += v * 2 ** spec.Start;
	}
	return out >>> 0;
}
function f64le(n) {
	const b = /* @__PURE__ */ new Uint8Array(8);
	new DataView(b.buffer).setFloat64(0, n, true);
	return b;
}
function encodeChunk(chunk, settings) {
	const body = writeChunk(chunk, settings, Uint8Array.from(settings.Key));
	return concat([
		MAGIC,
		new Uint8Array([14, 1]),
		u32(settings.Seed),
		u32(body.length),
		body,
		sha256(body)
	]);
}
function writeChunk(c, s, key) {
	const sections = {
		UpvalCount: new Uint8Array([c.upvalCount & 255]),
		ParameterCount: new Uint8Array([c.parameterCount & 255]),
		VarargCount: new Uint8Array([c.varargCount & 255]),
		Constants: writeConstants(c, s, key),
		Instructions: writeInstructions(c, s),
		Prototypes: writeProtos(c, s, key)
	};
	const parts = [u32(s.ChunkStructure.length)];
	for (const name of s.ChunkStructure) {
		const raw = new TextEncoder().encode(name);
		const data = sections[name];
		parts.push(new Uint8Array([raw.length]), raw, u32(data.length), data);
	}
	return concat(parts);
}
function writeConstants(c, s, key) {
	const parts = [u32(c.constants.length)];
	c.constants.forEach((k, i) => {
		parts.push(new Uint8Array([s.ConstantTags[k.type] & 255]));
		if (k.type === "Nil") return;
		if (k.type === "Boolean") {
			parts.push(new Uint8Array([k.data ? 1 : 0]));
			return;
		}
		if (k.type === "Number") {
			const raw = f64le(Number(k.data));
			parts.push(u32(8), xorBytes(raw, key, i));
			return;
		}
		const raw = new TextEncoder().encode(String(k.data));
		const step = Math.max(1, i * 7 % 4 + 1);
		const slices = [];
		for (let j = 0; j < raw.length; j += step) slices.push(raw.subarray(j, j + step));
		parts.push(u32(slices.length));
		slices.forEach((p, j) => {
			const e = xorBytes(p, key, i + j);
			parts.push(u32(e.length), e);
		});
	});
	return concat(parts);
}
function wordFor(ins, s, oid) {
	const typ = OP_TYPE[ins.op];
	const layout = s.Registers[typ] ?? s.Registers.ABC;
	const mode = typ === "ABC" ? 0 : typ === "ABx" ? 1 : typ === "AsBx" ? 2 : 3;
	return u32(pack(layout, {
		A: ins.a,
		B: ins.b,
		C: ins.c,
		Mode: mode,
		Enum: oid & 7
	}));
}
function writeInstructions(c, s) {
	const parts = [u32(c.instructions.length)];
	for (const ins of c.instructions) {
		const oid = s.OpcodeMap[ins.op];
		parts.push(u32(oid), wordFor(ins, s, oid), new Uint8Array([ins.junk ? 1 : 0]));
		if (ins.op === "Super") {
			const subs = ins.superOps ?? [];
			parts.push(u32(subs.length));
			for (const sub of subs) {
				const soid = s.OpcodeMap[sub.op];
				parts.push(u32(soid), wordFor({
					op: sub.op,
					a: sub.a,
					b: sub.b,
					c: sub.c
				}, s, soid));
			}
		}
	}
	return concat(parts);
}
function writeProtos(c, s, key) {
	const parts = [u32(c.prototypes.length)];
	for (const p of c.prototypes) {
		const body = writeChunk(p, s, key);
		parts.push(u32(body.length), body);
	}
	return concat(parts);
}
var CompileError = class extends Error {
	constructor(message, line) {
		super(line ? `Línea ${line}: ${message}` : message);
		this.name = "CompileError";
	}
};
var BIN = {
	"+": "Add",
	"-": "Sub",
	"*": "Mul",
	"/": "Div",
	"%": "Mod",
	"^": "Pow"
};
function isCall(node) {
	return !!node && (node.type === "CallExpression" || node.type === "StringCallExpression" || node.type === "TableCallExpression");
}
function luaString(raw) {
	if (raw.startsWith("[")) {
		const open = /^\[(=*)\[/.exec(raw);
		if (!open) throw new Error("Cadena larga inválida");
		const eq = open[1];
		const body = raw.slice(open[0].length, raw.length - (eq.length + 2));
		if (body.startsWith("\r\n")) return body.slice(2);
		if (body.startsWith("\n") || body.startsWith("\r")) return body.slice(1);
		return body;
	}
	let i = 1;
	let out = "";
	const end = raw.length - 1;
	while (i < end) {
		if (raw[i] !== "\\") {
			out += raw[i++];
			continue;
		}
		i += 1;
		const c = raw[i++] ?? "";
		const simple = {
			a: "\x07",
			b: "\b",
			f: "\f",
			n: "\n",
			r: "\r",
			t: "	",
			v: "\v",
			"\\": "\\",
			"\"": "\"",
			"'": "'"
		};
		if (c in simple) {
			out += simple[c];
			continue;
		}
		if (c === "\n") continue;
		if (c === "\r") {
			if (raw[i] === "\n") i += 1;
			continue;
		}
		if (c >= "0" && c <= "9") {
			let digits = c;
			for (let k = 0; k < 2 && raw[i] >= "0" && raw[i] <= "9"; k++) digits += raw[i++];
			out += String.fromCharCode(Number(digits) & 255);
			continue;
		}
		out += c;
	}
	return out;
}
var Func = class Func {
	parent;
	parameterCount;
	isVararg;
	name;
	instructions = [];
	constants = [];
	prototypes = [];
	locals = [];
	upvalues = [];
	nactvar = 0;
	freereg = 0;
	maxStack = 2;
	keys = /* @__PURE__ */ new Map();
	scopes = [];
	acts = [];
	loops = [];
	line = 1;
	constructor(parent, parameterCount, isVararg, name) {
		this.parent = parent;
		this.parameterCount = parameterCount;
		this.isVararg = isVararg;
		this.name = name;
	}
	at(node) {
		const line = node?.loc?.start?.line;
		if (line) this.line = line;
		return this.line;
	}
	fail(node, message) {
		throw new CompileError(message, this.at(node));
	}
	touch(reg) {
		if (reg + 1 > this.maxStack) this.maxStack = reg + 1;
	}
	alloc() {
		if (this.freereg >= 249) this.fail(void 0, "La función usa demasiados registros");
		const r = this.freereg++;
		this.touch(r);
		return r;
	}
	emit(op, a = 0, b = 0, c = 0) {
		const ins = makeIns(op, a, b, c);
		this.instructions.push(ins);
		this.touch(a);
		return ins;
	}
	addConst(c) {
		const key = c.type === "Nil" ? "Z" : c.type === "Boolean" ? `B${c.data ? 1 : 0}` : c.type === "Number" ? `N${Object.is(c.data, -0) ? "-0" : String(c.data)}` : `S${c.data}`;
		const hit = this.keys.get(key);
		if (hit != null) return hit;
		const idx = this.constants.length;
		this.constants.push(c);
		this.keys.set(key, idx);
		return idx;
	}
	loadConst(dest, c) {
		const idx = this.addConst(c);
		if (idx > 262143) this.fail(void 0, "Demasiadas constantes");
		this.emit("Loadk", dest, idx, 0);
	}
	rkConst(c) {
		const idx = this.addConst(c);
		if (idx > 255) this.fail(void 0, "Demasiadas constantes en una sola expresión");
		return idx + 256;
	}
	findLocal(name) {
		for (let i = this.locals.length - 1; i >= 0; i--) if (this.locals[i].name === name) return this.locals[i];
	}
	capture(name) {
		if (!this.parent) return null;
		const have = this.upvalues.findIndex((u) => u.name === name);
		if (have >= 0) return have;
		const local = this.parent.findLocal(name);
		if (local) {
			local.captured = true;
			this.upvalues.push({
				name,
				kind: "local",
				index: local.reg
			});
			return this.upvalues.length - 1;
		}
		const up = this.parent.capture(name);
		if (up == null) return null;
		this.upvalues.push({
			name,
			kind: "upval",
			index: up
		});
		return this.upvalues.length - 1;
	}
	pushLocal(name, reg) {
		this.locals.push({
			name,
			reg,
			captured: false
		});
		this.touch(reg);
	}
	enter() {
		this.scopes.push(this.locals.length);
		this.acts.push(this.nactvar);
	}
	leave() {
		const mark = this.scopes.pop() ?? 0;
		const act = this.acts.pop() ?? 0;
		let min = Infinity;
		while (this.locals.length > mark) {
			const loc = this.locals.pop();
			if (loc.captured) min = Math.min(min, loc.reg);
		}
		if (min !== Infinity) this.emit("Close", min, 0, 0);
		this.nactvar = act;
		this.freereg = this.nactvar;
	}
	closeFrom(mark) {
		let min = Infinity;
		for (let i = mark; i < this.locals.length; i++) if (this.locals[i].captured) min = Math.min(min, this.locals[i].reg);
		if (min !== Infinity) this.emit("Close", min, 0, 0);
	}
	pin(target) {
		if (this.freereg < target + 1) this.freereg = target + 1;
	}
	keep(target) {
		const next = Math.max(this.nactvar, target + 1);
		if (this.freereg < next) this.freereg = next;
		else if (target >= this.nactvar) this.freereg = next;
	}
	expr(node, dest) {
		this.at(node);
		const target = dest !== void 0 ? dest : this.alloc();
		this.pin(target);
		switch (node.type) {
			case "NilLiteral":
				this.loadConst(target, {
					type: "Nil",
					data: null
				});
				break;
			case "BooleanLiteral":
				this.loadConst(target, {
					type: "Boolean",
					data: Boolean(node.value)
				});
				break;
			case "NumericLiteral":
				this.loadConst(target, {
					type: "Number",
					data: Number(node.value)
				});
				break;
			case "StringLiteral":
				this.loadConst(target, {
					type: "String",
					data: luaString(String(node.raw ?? ""))
				});
				break;
			case "VarargLiteral":
				if (!this.isVararg) this.fail(node, "`...` fuera de una función variádica");
				this.emit("VarArg", target, 2, 0);
				break;
			case "Identifier":
				this.identInto(String(node.name), target, node);
				break;
			case "UnaryExpression":
				this.unary(node, target);
				break;
			case "BinaryExpression":
				this.binary(node, target);
				break;
			case "LogicalExpression":
				this.logical(node, target);
				break;
			case "MemberExpression":
			case "IndexExpression":
				this.indexInto(node, target);
				break;
			case "CallExpression":
			case "StringCallExpression":
			case "TableCallExpression":
				this.compileCall(node, 1, target, false);
				break;
			case "TableConstructorExpression":
				this.tableInto(node, target);
				break;
			case "FunctionDeclaration":
				this.closureInto(target, node);
				break;
			default: this.fail(node, `Expresión no soportada (${node.type})`);
		}
		this.keep(target);
		return target;
	}
	exprInto(node, dest) {
		const r = this.expr(node, dest);
		if (r !== dest) this.emit("Move", dest, r, 0);
	}
	exprRK(node) {
		if (node.type === "NumericLiteral") return this.rkConst({
			type: "Number",
			data: Number(node.value)
		});
		if (node.type === "StringLiteral") return this.rkConst({
			type: "String",
			data: luaString(String(node.raw ?? ""))
		});
		if (node.type === "BooleanLiteral") return this.rkConst({
			type: "Boolean",
			data: Boolean(node.value)
		});
		if (node.type === "NilLiteral") return this.rkConst({
			type: "Nil",
			data: null
		});
		return this.expr(node);
	}
	identInto(name, dest, node) {
		const local = this.findLocal(name);
		if (local) {
			if (local.reg !== dest) this.emit("Move", dest, local.reg, 0);
			return;
		}
		const up = this.capture(name);
		if (up != null) {
			this.emit("GetUpval", dest, up, 0);
			return;
		}
		const k = this.addConst({
			type: "String",
			data: name
		});
		this.emit("GetGlobal", dest, k, 0);
	}
	unary(node, target) {
		const op = String(node.operator);
		const arg = node.argument;
		if (op === "not") {
			const r = this.expr(arg);
			this.emit("Not", target, r, 0);
			return;
		}
		if (op === "-") {
			const r = this.expr(arg);
			this.emit("Unm", target, r, 0);
			return;
		}
		if (op === "#") {
			const r = this.expr(arg);
			this.emit("Len", target, r, 0);
			return;
		}
		this.fail(node, `Operador unario no soportado ${op}`);
	}
	binary(node, target) {
		const op = String(node.operator);
		if (op === "..") {
			this.concatInto(node, target);
			return;
		}
		if (op === "==" || op === "~=" || op === "<" || op === ">" || op === "<=" || op === ">=") {
			this.compare(node, target);
			return;
		}
		const opc = BIN[op];
		if (!opc) this.fail(node, `Operador no soportado ${op}`);
		const left = node.left;
		const right = node.right;
		const b = this.exprRK(left);
		const c = this.exprRK(right);
		this.emit(opc, target, b, c);
	}
	compare(node, target) {
		let b = this.exprRK(node.left);
		let c = this.exprRK(node.right);
		let code;
		let invert = 0;
		const op = String(node.operator);
		if (op === "==") code = "Eq";
		else if (op === "~=") {
			code = "Eq";
			invert = 1;
		} else if (op === "<") code = "Lt";
		else if (op === ">") {
			code = "Lt";
			const t = b;
			b = c;
			c = t;
		} else if (op === "<=") code = "Le";
		else {
			code = "Le";
			const t = b;
			b = c;
			c = t;
		}
		this.emit(code, invert, b, c);
		const jmp = this.emit("Jmp");
		this.emit("LoadBool", target, 1, 1);
		jmp.target = this.instructions.length;
		this.emit("LoadBool", target, 0, 0);
	}
	concatInto(node, target) {
		const parts = [];
		const flat = (n) => {
			if (n.type === "BinaryExpression" && n.operator === "..") {
				flat(n.left);
				flat(n.right);
			} else parts.push(n);
		};
		flat(node);
		const base = Math.max(this.freereg, this.nactvar);
		for (let i = 0; i < parts.length; i++) {
			this.freereg = Math.max(this.nactvar, base + i);
			this.exprInto(parts[i], base + i);
			this.freereg = Math.max(this.nactvar, base + i + 1);
		}
		if (target >= base && target < base + parts.length) {
			const tmp = base + parts.length;
			this.emit("Concat", tmp, base, base + parts.length - 1);
			this.emit("Move", target, tmp, 0);
		} else this.emit("Concat", target, base, base + parts.length - 1);
	}
	logical(node, target) {
		const op = String(node.operator);
		this.exprInto(node.left, target);
		this.emit("Test", target, 0, op === "and" ? 1 : 0);
		const jmp = this.emit("Jmp");
		this.freereg = Math.max(this.nactvar, target + 1);
		this.exprInto(node.right, target);
		jmp.target = this.instructions.length;
	}
	indexInto(node, target) {
		if (node.type === "MemberExpression") {
			const base = this.expr(node.base);
			const key = this.rkConst({
				type: "String",
				data: String(node.identifier.name)
			});
			this.emit("GetTable", target, base, key);
			return;
		}
		const base = this.expr(node.base);
		const key = this.exprRK(node.index);
		this.emit("GetTable", target, base, key);
	}
	tableInto(node, target) {
		this.emit("NewTable", target, 0, 0);
		let array = 1;
		const fields = node.fields ?? [];
		for (const field of fields) {
			this.freereg = Math.max(this.nactvar, target + 1);
			let key;
			if (field.type === "TableValue") key = this.rkConst({
				type: "Number",
				data: array++
			});
			else if (field.type === "TableKeyString") key = this.rkConst({
				type: "String",
				data: String(field.key.name)
			});
			else key = this.exprRK(field.key);
			const val = this.expr(field.value);
			this.emit("SetTable", target, key, val);
		}
	}
	callShape(node) {
		if (node.type === "StringCallExpression") return {
			callee: node.base,
			args: [node.argument],
			method: null
		};
		if (node.type === "TableCallExpression") return {
			callee: node.base,
			args: [node.arguments],
			method: null
		};
		const base = node.base;
		if (base?.type === "MemberExpression" && base.indexer === ":") return {
			callee: base.base,
			args: node.arguments ?? [],
			method: String(base.identifier.name)
		};
		return {
			callee: base,
			args: node.arguments ?? [],
			method: null
		};
	}
	compileCall(node, nresults, base, tail) {
		this.at(node);
		const shape = this.callShape(node);
		if (shape.method) {
			this.freereg = Math.max(this.freereg, this.nactvar, base + 2);
			this.exprInto(shape.callee, base + 1);
			const key = this.rkConst({
				type: "String",
				data: shape.method
			});
			this.emit("Self", base, base + 1, key);
		} else {
			this.freereg = Math.max(this.freereg, this.nactvar, base + 1);
			this.exprInto(shape.callee, base);
		}
		const arg0 = shape.method ? 2 : 1;
		let argc = 0;
		let vararg = false;
		for (let i = 0; i < shape.args.length; i++) {
			const arg = shape.args[i];
			const slot = base + arg0 + argc;
			if (arg.type === "VarargLiteral") {
				if (i !== shape.args.length - 1) this.fail(arg, "`...` tiene que ser el último argumento");
				if (!this.isVararg) this.fail(arg, "`...` fuera de una función variádica");
				this.emit("VarArg", slot, 0, 0);
				vararg = true;
				break;
			}
			this.freereg = Math.max(this.nactvar, slot + 1);
			this.exprInto(arg, slot);
			argc += 1;
		}
		const fixed = shape.method ? argc + 1 : argc;
		const B = vararg ? 0 : fixed + 1;
		const op = tail ? "TailCall" : "Call";
		const C = tail || nresults < 0 ? 0 : nresults + 1;
		this.emit(op, base, B, C);
		if (nresults > 0) this.freereg = Math.max(this.nactvar, base + nresults);
		else this.freereg = Math.max(this.nactvar, base);
	}
	closureInto(dest, node) {
		let params = (node.parameters ?? []).slice();
		const id = node.identifier;
		if (id && id.type === "MemberExpression" && id.indexer === ":") params = [{
			type: "Identifier",
			name: "self"
		}, ...params];
		const child = new Func(this, 0, false, this.name);
		child.compileFunction(params, node.body ?? []);
		const proto = child.finish();
		const idx = this.prototypes.length;
		this.prototypes.push(proto);
		this.emit("Closure", dest, idx, 0);
		for (const uv of child.upvalues) {
			const bind = this.emit(uv.kind === "local" ? "Move" : "GetUpval", 0, uv.index, 0);
			bind.bind = true;
		}
	}
	compileFunction(params, body, mainChunk = false) {
		let vararg = false;
		const names = [];
		params.forEach((p, i) => {
			if (p.type === "VarargLiteral") {
				if (i !== params.length - 1) this.fail(p, "`...` tiene que ser el último parámetro");
				vararg = true;
				return;
			}
			if (p.type !== "Identifier") this.fail(p, "Parámetro no soportado");
			names.push(String(p.name));
		});
		this.isVararg = vararg || mainChunk;
		this.parameterCount = names.length;
		names.forEach((name, i) => this.pushLocal(name, i));
		this.nactvar = names.length;
		this.freereg = this.nactvar;
		this.block(body);
		const last = this.instructions[this.instructions.length - 1];
		if (!last || last.op !== "Return" && last.op !== "TailCall") this.emit("Return", 0, 1, 0);
	}
	block(body) {
		for (const stat of body) this.stat(stat);
	}
	stat(node) {
		this.at(node);
		switch (node.type) {
			case "LocalStatement":
				this.localStat(node);
				return;
			case "AssignmentStatement":
				this.assignStat(node);
				return;
			case "CallStatement":
				this.compileCall(node.expression, 0, this.freereg, false);
				this.freereg = this.nactvar;
				return;
			case "ReturnStatement":
				this.returnStat(node);
				return;
			case "FunctionDeclaration":
				this.functionStat(node);
				return;
			case "DoStatement":
				this.enter();
				this.block(node.body);
				this.leave();
				return;
			case "IfStatement":
				this.ifStat(node);
				return;
			case "WhileStatement":
				this.whileStat(node);
				return;
			case "RepeatStatement":
				this.repeatStat(node);
				return;
			case "ForNumericStatement":
				this.numFor(node);
				return;
			case "ForGenericStatement":
				this.genFor(node);
				return;
			case "BreakStatement":
				this.breakStat(node);
				return;
			default: this.fail(node, `Sentencia no soportada (${node.type}). Lua 5.2+ (goto) no entra.`);
		}
	}
	localStat(node) {
		const vars = node.variables;
		const inits = node.init ?? [];
		const base = this.nactvar;
		const n = vars.length;
		this.nactvar = base + n;
		this.freereg = this.nactvar;
		if (inits.length === 0) this.emit("LoadNil", base, base + n - 1, 0);
		else if (inits.length === 1 && isCall(inits[0]) && n >= 1) this.compileCall(inits[0], n, base, false);
		else {
			const last = inits[inits.length - 1];
			const spread = isCall(last) && inits.length < n;
			const fixed = spread ? inits.length - 1 : Math.min(inits.length, n);
			for (let i = 0; i < fixed; i++) {
				this.freereg = Math.max(this.nactvar, base + n);
				this.exprInto(inits[i], base + i);
			}
			if (spread) {
				this.freereg = Math.max(this.nactvar, base + n);
				this.compileCall(last, n - (inits.length - 1), base + inits.length - 1, false);
			} else if (inits.length < n) this.emit("LoadNil", base + inits.length, base + n - 1, 0);
		}
		vars.forEach((v, i) => this.pushLocal(String(v.name), base + i));
		this.freereg = this.nactvar;
	}
	prepLhs(node) {
		if (node.type === "Identifier") {
			const name = String(node.name);
			const local = this.findLocal(name);
			if (local) return {
				kind: "local",
				reg: local.reg
			};
			const up = this.capture(name);
			if (up != null) return {
				kind: "upval",
				idx: up
			};
			return {
				kind: "global",
				name
			};
		}
		if (node.type === "MemberExpression") return {
			kind: "index",
			table: this.expr(node.base),
			key: this.rkConst({
				type: "String",
				data: String(node.identifier.name)
			})
		};
		if (node.type === "IndexExpression") return {
			kind: "index",
			table: this.expr(node.base),
			key: this.exprRK(node.index)
		};
		this.fail(node, "Asignación no soportada");
	}
	store(prep, from) {
		if (prep.kind === "local") {
			if (prep.reg !== from) this.emit("Move", prep.reg, from, 0);
			return;
		}
		if (prep.kind === "upval") {
			this.emit("SetUpval", from, prep.idx, 0);
			return;
		}
		if (prep.kind === "global") {
			const k = this.addConst({
				type: "String",
				data: prep.name
			});
			this.emit("SetGlobal", from, k, 0);
			return;
		}
		this.emit("SetTable", prep.table, prep.key, from);
	}
	assignStat(node) {
		const lhs = node.variables;
		const rhs = node.init ?? [];
		const preps = lhs.map((item) => this.prepLhs(item));
		const base = this.freereg;
		if (rhs.length === 1 && isCall(rhs[0])) this.compileCall(rhs[0], lhs.length, base, false);
		else {
			const last = rhs[rhs.length - 1];
			const spread = isCall(last) && rhs.length < lhs.length && rhs.length > 0;
			const fixed = spread ? rhs.length - 1 : Math.min(rhs.length, lhs.length);
			for (let i = 0; i < fixed; i++) {
				this.freereg = Math.max(base + lhs.length, this.nactvar);
				this.exprInto(rhs[i], base + i);
			}
			if (spread) this.compileCall(last, lhs.length - (rhs.length - 1), base + rhs.length - 1, false);
			else if (rhs.length < lhs.length) this.emit("LoadNil", base + rhs.length, base + lhs.length - 1, 0);
		}
		for (let i = 0; i < lhs.length; i++) this.store(preps[i], base + i);
		this.freereg = this.nactvar;
	}
	returnStat(node) {
		const args = node.arguments ?? [];
		if (args.length === 0) {
			this.emit("Return", 0, 1, 0);
			return;
		}
		if (args.length === 1 && isCall(args[0])) {
			this.compileCall(args[0], -1, this.nactvar, true);
			return;
		}
		if (args.length === 1 && args[0].type === "VarargLiteral") {
			if (!this.isVararg) this.fail(args[0], "`...` fuera de una función variádica");
			this.emit("VarArg", this.nactvar, 0, 0);
			this.emit("Return", this.nactvar, 0, 0);
			return;
		}
		const base = this.freereg;
		const last = args[args.length - 1];
		if (isCall(last) && args.length > 1) {
			for (let i = 0; i < args.length - 1; i++) {
				this.freereg = base + i + 1;
				this.exprInto(args[i], base + i);
			}
			this.compileCall(last, -1, base + args.length - 1, false);
			this.emit("Return", base, 0, 0);
			return;
		}
		for (let i = 0; i < args.length; i++) {
			this.freereg = base + i + 1;
			this.exprInto(args[i], base + i);
		}
		this.emit("Return", base, args.length + 1, 0);
	}
	functionStat(node) {
		const id = node.identifier;
		if (node.isLocal) {
			if (!id || id.type !== "Identifier") this.fail(node, "Función local inválida");
			const reg = this.nactvar++;
			this.freereg = this.nactvar;
			this.pushLocal(String(id.name), reg);
			this.closureInto(reg, node);
			this.freereg = this.nactvar;
			return;
		}
		if (!id) this.fail(node, "Función sin nombre");
		const reg = this.alloc();
		this.closureInto(reg, node);
		const target = id.type === "MemberExpression" && id.indexer === ":" ? {
			...id,
			indexer: "."
		} : id;
		const prep = this.prepLhs(target);
		this.store(prep, reg);
		this.freereg = this.nactvar;
	}
	ifStat(node) {
		const ends = [];
		const clauses = node.clauses;
		clauses.forEach((clause, idx) => {
			let skip = null;
			if (clause.type !== "ElseClause") {
				const reg = this.expr(clause.condition);
				this.freereg = this.nactvar;
				this.emit("Test", reg, 0, 1);
				skip = this.emit("Jmp");
			}
			this.enter();
			this.block(clause.body);
			this.leave();
			if (idx !== clauses.length - 1) ends.push(this.emit("Jmp"));
			if (skip) skip.target = this.instructions.length;
		});
		const end = this.instructions.length;
		for (const j of ends) j.target = end;
	}
	whileStat(node) {
		const loop = {
			breaks: [],
			localMark: this.locals.length
		};
		this.loops.push(loop);
		const start = this.instructions.length;
		const reg = this.expr(node.condition);
		this.freereg = this.nactvar;
		this.emit("Test", reg, 0, 1);
		const exit = this.emit("Jmp");
		this.enter();
		this.block(node.body);
		this.leave();
		const back = this.emit("Jmp");
		back.target = start;
		exit.target = this.instructions.length;
		for (const b of loop.breaks) b.target = this.instructions.length;
		this.loops.pop();
	}
	repeatStat(node) {
		const loop = {
			breaks: [],
			localMark: this.locals.length
		};
		this.loops.push(loop);
		this.enter();
		const start = this.instructions.length;
		this.block(node.body);
		const reg = this.expr(node.condition);
		this.freereg = this.nactvar;
		this.emit("Test", reg, 0, 1);
		const back = this.emit("Jmp");
		back.target = start;
		this.leave();
		const exit = this.instructions.length;
		for (const b of loop.breaks) b.target = exit;
		this.loops.pop();
	}
	breakStat(node) {
		const loop = this.loops[this.loops.length - 1];
		if (!loop) this.fail(node, "`break` fuera de un bucle");
		this.closeFrom(loop.localMark);
		loop.breaks.push(this.emit("Jmp"));
	}
	numFor(node) {
		const base = this.nactvar;
		this.nactvar = base + 3;
		this.freereg = this.nactvar;
		this.exprInto(node.start, base);
		this.freereg = this.nactvar;
		this.exprInto(node.end, base + 1);
		this.freereg = this.nactvar;
		if (node.step) this.exprInto(node.step, base + 2);
		else this.loadConst(base + 2, {
			type: "Number",
			data: 1
		});
		const localMark = this.locals.length;
		this.pushLocal(String(node.variable.name), base + 3);
		this.nactvar = base + 4;
		this.freereg = this.nactvar;
		const prep = this.emit("ForPrep", base, 0, 0);
		const bodyStart = this.instructions.length;
		const loop = {
			breaks: [],
			localMark
		};
		this.loops.push(loop);
		this.enter();
		this.block(node.body);
		this.leave();
		const loopIns = this.emit("ForLoop", base, 0, 0);
		prep.target = this.instructions.indexOf(loopIns);
		loopIns.target = bodyStart;
		this.closeFrom(localMark);
		this.locals.pop();
		this.nactvar = base;
		this.freereg = base;
		const exit = this.instructions.length;
		for (const b of loop.breaks) b.target = exit;
		this.loops.pop();
	}
	genFor(node) {
		const base = this.nactvar;
		const vars = node.variables;
		const iters = node.iterators;
		this.nactvar = base + 3;
		this.freereg = this.nactvar;
		if (iters.length === 1 && isCall(iters[0])) this.compileCall(iters[0], 3, base, false);
		else for (let i = 0; i < 3; i++) {
			this.freereg = Math.max(this.nactvar, base + 3);
			if (i < iters.length) this.exprInto(iters[i], base + i);
			else this.emit("LoadNil", base + i, base + i, 0);
		}
		const localMark = this.locals.length;
		vars.forEach((v, i) => this.pushLocal(String(v.name), base + 3 + i));
		this.nactvar = base + 3 + vars.length;
		this.freereg = this.nactvar;
		const skip = this.emit("Jmp");
		const bodyStart = this.instructions.length;
		const loop = {
			breaks: [],
			localMark
		};
		this.loops.push(loop);
		this.enter();
		this.block(node.body);
		this.leave();
		skip.target = this.instructions.length;
		this.emit("TForLoop", base, 0, vars.length);
		const back = this.emit("Jmp");
		back.target = bodyStart;
		this.closeFrom(localMark);
		while (this.locals.length > localMark) this.locals.pop();
		this.nactvar = base;
		this.freereg = base;
		const exit = this.instructions.length;
		for (const b of loop.breaks) b.target = exit;
		this.loops.pop();
	}
	compileChunk(body) {
		this.compileFunction([], body, true);
	}
	finish() {
		return {
			name: this.name,
			parameterCount: this.parameterCount,
			varargCount: this.isVararg ? 2 : 0,
			upvalCount: this.upvalues.length,
			stackSize: Math.max(this.maxStack, this.parameterCount + 2, 2),
			constants: this.constants,
			instructions: this.instructions,
			prototypes: this.prototypes
		};
	}
};
function compileLua(source) {
	let ast;
	try {
		ast = (0, import_luaparse.parse)(source, {
			luaVersion: "5.1",
			locations: true
		});
	} catch (err) {
		const e = err;
		const line = e.line ? `Línea ${e.line}: ` : "";
		throw new Error(`${line}${e.message ?? "Error de sintaxis Lua"}`);
	}
	const main = new Func(null, 0, true, "@chelo");
	main.compileChunk(ast.body ?? []);
	return main.finish();
}
var OP_BY_ID = [
	"Move",
	"Loadk",
	"LoadBool",
	"LoadNil",
	"GetUpval",
	"GetGlobal",
	"GetTable",
	"SetGlobal",
	"SetUpval",
	"SetTable",
	"NewTable",
	"Self",
	"Add",
	"Sub",
	"Mul",
	"Div",
	"Mod",
	"Pow",
	"Unm",
	"Not",
	"Len",
	"Concat",
	"Jmp",
	"Eq",
	"Lt",
	"Le",
	"Test",
	"TestSet",
	"Call",
	"TailCall",
	"Return",
	"ForLoop",
	"ForPrep",
	"TForLoop",
	"SetList",
	"Close",
	"Closure",
	"VarArg"
];
var Reader = class {
	b;
	i = 0;
	intSize = 4;
	sizeT = 8;
	big = false;
	constructor(b) {
		this.b = b;
	}
	left(n) {
		if (this.i + n > this.b.length) throw new Error("Bytecode Lua malformado");
	}
	u8() {
		this.left(1);
		return this.b[this.i++];
	}
	uint(n) {
		this.left(n);
		let v = 0;
		if (this.big) for (let k = 0; k < n; k++) v = v * 256 + this.b[this.i++];
		else for (let k = 0; k < n; k++) v += this.b[this.i++] * 2 ** (8 * k);
		return v;
	}
	i32() {
		return this.uint(this.intSize);
	}
	size() {
		return this.uint(this.sizeT);
	}
	f64() {
		this.left(8);
		const tmp = this.b.slice(this.i, this.i + 8);
		this.i += 8;
		return new DataView(tmp.buffer, tmp.byteOffset, 8).getFloat64(0, !this.big);
	}
	str() {
		const n = this.size();
		if (n === 0) return "";
		this.left(n);
		let s = "";
		for (let k = 0; k < n; k++) s += String.fromCharCode(this.b[this.i++]);
		return s.endsWith("\0") ? s.slice(0, -1) : s;
	}
	code() {
		const word = this.uint(4);
		const op = word & 63;
		const A = word >>> 6 & 255;
		const name = OP_BY_ID[op];
		if (!name) throw new Error(`Opcode Lua desconocido ${op}`);
		const kind = OP_TYPE[name];
		let B = 0;
		let C = 0;
		if (kind === "ABC") {
			C = word >>> 14 & 511;
			B = word >>> 23 & 511;
		} else if (kind === "ABx") B = word >>> 14 & 262143;
		else if (kind === "AsBx") B = (word >>> 14 & 262143) - 131071;
		return makeIns(name, A, B, C);
	}
};
function chunk(r) {
	const name = r.str();
	r.i32();
	r.i32();
	const upvalCount = r.u8();
	const parameterCount = r.u8();
	const varargCount = r.u8();
	const stackSize = r.u8();
	const ncode = r.i32();
	const instructions = [];
	for (let i = 0; i < ncode; i++) instructions.push(r.code());
	const nconst = r.i32();
	const constants = [];
	for (let i = 0; i < nconst; i++) {
		const t = r.u8();
		if (t === 0) constants.push({
			type: "Nil",
			data: null
		});
		else if (t === 1) constants.push({
			type: "Boolean",
			data: r.u8() !== 0
		});
		else if (t === 3) constants.push({
			type: "Number",
			data: r.f64()
		});
		else if (t === 4) constants.push({
			type: "String",
			data: r.str()
		});
		else throw new Error(`Constante Lua tipo ${t} no soportada`);
	}
	const nproto = r.i32();
	const prototypes = [];
	for (let i = 0; i < nproto; i++) prototypes.push(chunk(r));
	const nline = r.i32();
	for (let i = 0; i < nline; i++) r.i32();
	const nloc = r.i32();
	for (let i = 0; i < nloc; i++) {
		r.str();
		r.i32();
		r.i32();
	}
	const nuv = r.i32();
	for (let i = 0; i < nuv; i++) r.str();
	return {
		name,
		parameterCount,
		varargCount,
		upvalCount,
		stackSize,
		constants,
		instructions,
		prototypes
	};
}
function deserializeLuac(bytes) {
	if (bytes.length < 12 || bytes[0] !== 27 || bytes[1] !== 76 || bytes[2] !== 117 || bytes[3] !== 97) throw new Error("No es un binario Lua 5.1 (.luac)");
	const r = new Reader(bytes);
	r.i = 4;
	const version = r.u8();
	if (version !== 81) throw new Error(`Solo Lua 5.1 (header 0x${version.toString(16)})`);
	r.u8();
	r.big = r.u8() === 0;
	r.intSize = r.u8();
	r.sizeT = r.u8();
	const instr = r.u8();
	const num = r.u8();
	const integral = r.u8();
	if (r.intSize !== 4 || instr !== 4 || num !== 8 || integral !== 0) throw new Error("Header Lua no estándar (se espera int32, instrucciones de 4 bytes y doubles)");
	if (r.sizeT !== 4 && r.sizeT !== 8) throw new Error("size_t no soportado");
	return chunk(r);
}
var VM_START = "\nlocal ObfuscatorBytecode = |OBFUSCATOR_BYTECODE|;\nlocal Select, Byte, Sub = select, string.byte, string.sub\n\nlocal function _u32(x) return x % 4294967296 end\nlocal function _xor(a,b)\n    local r,p=0,1\n    while a>0 or b>0 do\n        local aa=a%2; local bb=b%2\n        if aa~=bb then r=r+p end\n        a=(a-aa)/2; b=(b-bb)/2; p=p*2\n    end\n    return r\nend\nlocal function _and(a,b)\n    local r,p=0,1\n    while a>0 or b>0 do\n        local aa=a%2; local bb=b%2\n        if aa==1 and bb==1 then r=r+p end\n        a=(a-aa)/2; b=(b-bb)/2; p=p*2\n    end\n    return r\nend\nlocal function _or(a,b) return _u32(a+b-_and(a,b)) end\nlocal function _not(a) return 4294967295-_u32(a) end\nlocal function _shr(a,n) return math.floor(_u32(a)/2^n) end\nlocal function _shl(a,n) return _u32(_u32(a)*2^n) end\nlocal function _ror(a,n) return _or(_shr(a,n),_shl(a,32-n)) end\n\nlocal function _read32(s,p)\n    local a,b,c,d=Byte(s,p,p+3)\n    return a+b*256+c*65536+d*16777216,p+4\nend\nlocal function _u8(s,p) return Byte(s,p) end\nlocal function _double(raw)\n    local b={Byte(raw,1,8)}\n    local lo=b[1]+b[2]*256+b[3]*65536+b[4]*16777216\n    local hi=b[5]+b[6]*256+b[7]*65536+b[8]*16777216\n    local sign=(math.floor(hi/2147483648)%2==1) and -1 or 1\n    local exp=math.floor(hi/1048576)%2048\n    local frac=(hi%1048576)*4294967296+lo\n    if exp==0 then if frac==0 then return sign*0 end; return sign*(2^-1022)*(frac/4503599627370496) end\n    if exp==2047 then if frac==0 then return sign*(1/0) end; return 0/0 end\n    return sign*(2^(exp-1023))*(1+frac/4503599627370496)\nend\nlocal function _base64(s)\n    local alphabet=\"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/\"\n    s=s:gsub(\"[^\"..alphabet..\"=]\",\"\")\n    local out={}\n    local bits=\"\"\n    for i=1,#s do\n        local c=s:sub(i,i)\n        if c~=\"=\" then\n            local n=(alphabet:find(c,1,true) or 1)-1\n            local b=\"\"\n            for k=5,0,-1 do b=b..((math.floor(n/2^k)%2)==1 and \"1\" or \"0\") end\n            bits=bits..b\n        end\n    end\n    for i=1,#bits-7,8 do\n        local n=0\n        for k=0,7 do n=n*2+(bits:sub(i+k,i+k)==\"1\" and 1 or 0) end\n        out[#out+1]=string.char(n)\n    end\n    return table.concat(out)\nend\n\n-- Pure-Lua SHA-256 used to validate the CHLOV14 body before decoding.\nlocal function _sha256(msg)\n    local K={\n      1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,\n      3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,\n      3835390401,4022224774,2643470785,604807628,770255983,1249150122,1555081692,1996064986,\n      2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,\n      666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,\n      2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344\n    }\n    local H={1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225}\n    local n=#msg; local bitlen=n*8; local pad=string.char(128)\n    local rem=(56-((n+1)%64))%64\n    local hi=math.floor(bitlen/4294967296); local lo=bitlen%4294967296\n    local function be32(x) return string.char(math.floor(x/16777216)%256,math.floor(x/65536)%256,math.floor(x/256)%256,x%256) end\n    pad=pad..string.rep(\"\\0\",rem)..be32(hi)..be32(lo)\n    msg=msg..pad\n    for off=1,#msg,64 do\n        local W={}\n        for i=0,15 do\n            local p=off+i*4; local a,b,c,d=Byte(msg,p,p+3)\n            W[i]=_u32(a*16777216+b*65536+c*256+d)\n        end\n        for i=16,63 do\n            local x=W[i-15]; local y=W[i-2]\n            local s0=_xor(_xor(_ror(x,7),_ror(x,18)),_shr(x,3))\n            local s1=_xor(_xor(_ror(y,17),_ror(y,19)),_shr(y,10))\n            W[i]=_u32(W[i-16]+s0+W[i-7]+s1)\n        end\n        local a,b,c,d,e,f,g,h=H[1],H[2],H[3],H[4],H[5],H[6],H[7],H[8]\n        for i=0,63 do\n            local S1=_xor(_xor(_ror(e,6),_ror(e,11)),_ror(e,25))\n            local ch=_xor(_and(e,f),_and(_not(e),g))\n            local t1=_u32(h+S1+ch+K[i+1]+W[i])\n            local S0=_xor(_xor(_ror(a,2),_ror(a,13)),_ror(a,22))\n            local maj=_xor(_xor(_and(a,b),_and(a,c)),_and(b,c))\n            local t2=_u32(S0+maj)\n            h=g; g=f; f=e; e=_u32(d+t1); d=c; c=b; b=a; a=_u32(t1+t2)\n        end\n        H[1]=_u32(H[1]+a); H[2]=_u32(H[2]+b); H[3]=_u32(H[3]+c); H[4]=_u32(H[4]+d)\n        H[5]=_u32(H[5]+e); H[6]=_u32(H[6]+f); H[7]=_u32(H[7]+g); H[8]=_u32(H[8]+h)\n    end\n    local out={}\n    for i=1,8 do local x=H[i]; out[#out+1]=string.char(math.floor(x/16777216)%256,math.floor(x/65536)%256,math.floor(x/256)%256,x%256) end\n    return table.concat(out)\nend\n\n|V14_RUNTIME|\n";
var VM_DESER = "\nlocal function Deserialize(ByteString)\n    local Pos=1\n    local function U8() local x=Byte(ByteString,Pos); Pos=Pos+1; return x end\n    local function U32() local x; x,Pos=_read32(ByteString,Pos); return x end\n    local function Raw(n) local s=Sub(ByteString,Pos,Pos+n-1); Pos=Pos+n; return s end\n    local function UString() local n=U32(); return Raw(n) end\n    local function xorbytes(s,key,seed)\n        local o={}\n        for i=1,#s do\n            local a=Byte(s,i); local b=key[((seed+i-1)%#key)+1]; o[i]=string.char(_xor(a,b))\n        end\n        return table.concat(o)\n    end\n    local function bits(word,def)\n        local out={}\n        for name,v in pairs(def) do out[name]=math.floor(word/2^v.Start)%2^v.Length end\n        return out\n    end\n    local function chunk()\n        local c={UpvalCount=0,ParameterCount=0,VarargCount=0,Constants={},Instructions={},Prototypes={},Upvalues={}}\n        local count=U32(); local fields={}\n        for _=1,count do local n=U8(); local name=Raw(n); local sz=U32(); fields[name]=Raw(sz) end\n        c.UpvalCount=Byte(fields.UpvalCount or \"\\0\",1)\n        c.ParameterCount=Byte(fields.ParameterCount or \"\\0\",1)\n        c.VarargCount=Byte(fields.VarargCount or \"\\0\",1)\n        local cb=fields.Constants; local cp=1; local cc; cc,cp=_read32(cb,cp)\n        local revTag={}\n        for k,v in pairs(V14.ConstantTags) do revTag[v]=k end\n        for i=1,cc do\n            local tag=Byte(cb,cp); cp=cp+1; local typ=revTag[tag]\n            local v\n            if typ==\"Nil\" then v=nil\n            elseif typ==\"Boolean\" then v=Byte(cb,cp)~=0; cp=cp+1\n            elseif typ==\"Number\" then local n; n,cp=_read32(cb,cp); local raw=Sub(cb,cp,cp+n-1); cp=cp+n; raw=xorbytes(raw,V14.Key,i-1); v=_double(raw)\n            elseif typ==\"String\" then local parts,ns={}; ns,cp=_read32(cb,cp); for j=1,ns do local n; n,cp=_read32(cb,cp); local raw=Sub(cb,cp,cp+n-1); cp=cp+n; parts[#parts+1]=xorbytes(raw,V14.Key,(i-1)+(j-1)) end; v=table.concat(parts)\n            else error(\"bad CHLOV14 constant tag\") end\n            c.Constants[i]=v\n        end\n        local ib=fields.Instructions; local ip=1; local ic; ic,ip=_read32(ib,ip)\n        local rev={}; for name,id in pairs(V14.OpcodeMap) do rev[id]=name end\n        local function signbx(name, f)\n            local typ=V14.OpcodeTypes[name] or \"ABC\"\n            if typ==\"AsBx\" then\n                local L=((V14.Registers.AsBx or {}).B or {}).Length or 18\n                local sign=2^(L-1)\n                if (f.B or 0) >= sign then f.B = (f.B or 0) - 2^L end\n            end\n            return f\n        end\n        for i=1,ic do\n            local oid; oid,ip=_read32(ib,ip); local word; word,ip=_read32(ib,ip); local junk=_u8(ib,ip); ip=ip+1\n            local name=rev[oid]; if not name then error(\"unknown CHLOV14 opcode\") end\n            local typ=V14.OpcodeTypes[name] or \"ABC\"; local f=bits(word,V14.Registers[typ] or V14.Registers.ABC)\n            f=signbx(name, f)\n            local subs=nil\n            if name==\"Super\" then\n                local sc; sc,ip=_read32(ib,ip); subs={}\n                for _s=1,sc do\n                    local soid; soid,ip=_read32(ib,ip)\n                    local sword; sword,ip=_read32(ib,ip)\n                    local sname=rev[soid]; if not sname then error(\"unknown CHLOV14 super opcode\") end\n                    local styp=V14.OpcodeTypes[sname] or \"ABC\"\n                    local sf=bits(sword, V14.Registers[styp] or V14.Registers.ABC)\n                    sf=signbx(sname, sf)\n                    subs[#subs+1]={Enum=sname,A=sf.A or 0,B=sf.B or 0,C=sf.C or 0}\n                end\n            end\n            c.Instructions[i]={Enum=name,A=f.A or 0,B=f.B or 0,C=f.C or 0,Junk=(junk~=0),SuperOps=subs}\n        end\n        local pb=fields.Prototypes; local pp=1; local pc; pc,pp=_read32(pb,pp)\n        for i=1,pc do local sz; sz,pp=_read32(pb,pp); local old=ByteString; ByteString=Sub(pb,pp,pp+sz-1); Pos=1; c.Prototypes[i]=chunk(); ByteString=old; pp=pp+sz end\n        return c\n    end\n    return chunk()\nend\n";
var VM_WRAP = "\nlocal function _truthy(v)\n    return not not v\nend\nlocal function _unpack(t)\n    return table.unpack and table.unpack(t) or unpack(t)\nend\nlocal function _rk(frame, x, const)\n    if x >= 256 then return const[x - 255] end\n    return frame.stack[x]\nend\nlocal function _die()\n    while true do end\nend\n\nlocal function _exec_super(frame, S, const)\n    local op = S.Enum\n    local A, B, C = S.A or 0, S.B or 0, S.C or 0\n    local function rk(x)\n        if x >= 256 then return const[x - 255] end\n        return frame.stack[x]\n    end\n    if op == \"Move\" then frame.stack[A] = frame.stack[B]\n    elseif op == \"Loadk\" then frame.stack[A] = const[B + 1]\n    elseif op == \"LoadBool\" then frame.stack[A] = (B ~= 0)\n    elseif op == \"GetGlobal\" then frame.stack[A] = (_ENV or _G)[const[B + 1]]\n    elseif op == \"GetTable\" then frame.stack[A] = frame.stack[B][rk(C)]\n    elseif op == \"SetTable\" then frame.stack[A][rk(B)] = rk(C)\n    elseif op == \"Add\" then frame.stack[A] = rk(B) + rk(C)\n    elseif op == \"Sub\" then frame.stack[A] = rk(B) - rk(C)\n    elseif op == \"Mul\" then frame.stack[A] = rk(B) * rk(C)\n    elseif op == \"Div\" then frame.stack[A] = rk(B) / rk(C)\n    elseif op == \"Mod\" then frame.stack[A] = rk(B) % rk(C)\n    elseif op == \"Pow\" then frame.stack[A] = rk(B) ^ rk(C)\n    elseif op == \"Self\" then\n        local obj = frame.stack[B]\n        frame.stack[A + 1] = obj\n        frame.stack[A] = obj[rk(C)]\n    elseif op == \"Call\" then\n        local args = {}\n        local n = B - 1\n        if B == 0 then n = (frame.top or A) - A end\n        for j = 1, math.max(n, 0) do args[j] = frame.stack[A + j] end\n        local fn = frame.stack[A]\n        local ret\n        if type(fn) == \"function\" then\n            ret = {fn(_unpack(args))}\n        elseif type(fn) == \"table\" and fn.__vmclosure then\n            ret = {VM_Run(fn.chunk, _ENV or _G, fn.upvalues, args)}\n        else\n            _die()\n        end\n        if C == 0 then\n            for j = 1, #ret do frame.stack[A + j - 1] = ret[j] end\n            frame.top = A + #ret - 1\n        else\n            for j = 0, C - 2 do frame.stack[A + j] = ret[j + 1] end\n        end\n    end\nend\n\nlocal function _call(fn, args, env, up)\n    if type(fn) == \"function\" then return {fn(_unpack(args))} end\n    if type(fn) == \"table\" and fn.__vmclosure then return {VM_Run(fn.chunk, env, fn.upvalues, args)} end\n    _die()\nend\n\nfunction VM_Run(Chunk, Env, Upvalues, Args)\n    do\n        local t0 = os.clock()\n        local s = 0\n        for i = 1, 12000 do s = s + (i % 5) end\n        if os.clock() < t0 then _die() end\n        if s < 0 then _die() end\n    end\n    Env = Env or _ENV or _G\n    Upvalues = Upvalues or {}\n    Args = Args or {}\n    local frame = {stack = {}, varargs = {}, top = -1, open_uv = {}}\n    for i = 0, (Chunk.ParameterCount or 0) - 1 do frame.stack[i] = Args[i + 1] end\n    for i = (Chunk.ParameterCount or 0), #Args - 1 do frame.varargs[#frame.varargs + 1] = Args[i + 1] end\n    local pc = 1\n    local ins = Chunk.Instructions\n    local const = Chunk.Constants\n    local function rk(x) return _rk(frame, x, const) end\n    local function close_from(a)\n        local ou = frame.open_uv\n        for i = #ou, 1, -1 do\n            local box = ou[i]\n            if box and box.reg ~= nil and box.reg >= a then\n                local st = (box.frame and box.frame.stack) or frame.stack\n                box.value = st[box.reg]\n                box.reg = nil\n                box.frame = nil\n                table.remove(ou, i)\n            end\n        end\n    end\n    while true do\n        local I = ins[pc]\n        if not I then return end\n        pc = pc + 1\n        local op = I.Enum\n        local A, B, C = I.A or 0, I.B or 0, I.C or 0\n        if I.Junk or op == \"Junk\" then\n        elseif op == \"Super\" then\n            for _, S in ipairs(I.SuperOps or {}) do _exec_super(frame, S, const) end\n        elseif op == \"Move\" then frame.stack[A] = frame.stack[B]\n        elseif op == \"Loadk\" then frame.stack[A] = const[B + 1]\n        elseif op == \"LoadBool\" then frame.stack[A] = (B ~= 0); if C ~= 0 then pc = pc + 1 end\n        elseif op == \"LoadNil\" then for r = A, B do frame.stack[r] = nil end\n        elseif op == \"GetUpval\" then\n            local u = Upvalues[B + 1]\n            if type(u) == \"table\" then\n                if u.reg ~= nil and u.frame then frame.stack[A] = u.frame.stack[u.reg] else frame.stack[A] = u.value end\n            else frame.stack[A] = u end\n        elseif op == \"SetUpval\" then\n            local u = Upvalues[B + 1]\n            if type(u) == \"table\" then\n                if u.reg ~= nil and u.frame then u.frame.stack[u.reg] = frame.stack[A] else u.value = frame.stack[A] end\n            else Upvalues[B + 1] = frame.stack[A] end\n        elseif op == \"GetGlobal\" then frame.stack[A] = Env[const[B + 1]]\n        elseif op == \"SetGlobal\" then Env[const[B + 1]] = frame.stack[A]\n        elseif op == \"GetTable\" then frame.stack[A] = frame.stack[B][rk(C)]\n        elseif op == \"SetTable\" then frame.stack[A][rk(B)] = rk(C)\n        elseif op == \"NewTable\" then frame.stack[A] = {}\n        elseif op == \"Self\" then local obj = frame.stack[B]; frame.stack[A + 1] = obj; frame.stack[A] = obj[rk(C)]\n        elseif op == \"Add\" then frame.stack[A] = rk(B) + rk(C)\n        elseif op == \"Sub\" then frame.stack[A] = rk(B) - rk(C)\n        elseif op == \"Mul\" then frame.stack[A] = rk(B) * rk(C)\n        elseif op == \"Div\" then frame.stack[A] = rk(B) / rk(C)\n        elseif op == \"Mod\" then frame.stack[A] = rk(B) % rk(C)\n        elseif op == \"Pow\" then frame.stack[A] = rk(B) ^ rk(C)\n        elseif op == \"Unm\" then frame.stack[A] = -frame.stack[B]\n        elseif op == \"Not\" then frame.stack[A] = not frame.stack[B]\n        elseif op == \"Len\" then frame.stack[A] = #frame.stack[B]\n        elseif op == \"Concat\" then\n            local s = frame.stack[B]\n            for r = B + 1, C do s = s .. frame.stack[r] end\n            frame.stack[A] = s\n        elseif op == \"Jmp\" then pc = pc + B\n        elseif op == \"Eq\" then if (rk(B) == rk(C)) ~= (A ~= 0) then pc = pc + 1 end\n        elseif op == \"Lt\" then if (rk(B) < rk(C)) ~= (A ~= 0) then pc = pc + 1 end\n        elseif op == \"Le\" then if (rk(B) <= rk(C)) ~= (A ~= 0) then pc = pc + 1 end\n        elseif op == \"Test\" then if (_truthy(frame.stack[A]) == (C ~= 0)) then pc = pc + 1 end\n        elseif op == \"TestSet\" then\n            if (_truthy(frame.stack[B]) == (C ~= 0)) then frame.stack[A] = frame.stack[B] else pc = pc + 1 end\n        elseif op == \"Call\" or op == \"TailCall\" then\n            local args = {}\n            local n = B - 1\n            if B == 0 then n = frame.top - A end\n            for j = 1, math.max(n, 0) do args[j] = frame.stack[A + j] end\n            local ret = _call(frame.stack[A], args, Env, Upvalues)\n            if C == 0 then\n                for j = 1, #ret do frame.stack[A + j - 1] = ret[j] end\n                frame.top = A + #ret - 1\n            else\n                for j = 0, C - 2 do frame.stack[A + j] = ret[j + 1] end\n            end\n            if op == \"TailCall\" then return _unpack(ret) end\n        elseif op == \"Return\" then\n            close_from(0)\n            local n = B - 1\n            if B == 0 then n = frame.top - A + 1 end\n            local ret = {}\n            for j = 0, math.max(n, 0) - 1 do ret[#ret + 1] = frame.stack[A + j] end\n            return _unpack(ret)\n        elseif op == \"ForPrep\" then frame.stack[A] = frame.stack[A] - frame.stack[A + 2]; pc = pc + B\n        elseif op == \"ForLoop\" then\n            local idx = frame.stack[A] + frame.stack[A + 2]\n            frame.stack[A] = idx\n            local lim, step = frame.stack[A + 1], frame.stack[A + 2]\n            if (step > 0 and idx <= lim) or (step <= 0 and idx >= lim) then frame.stack[A + 3] = idx; pc = pc + B end\n        elseif op == \"TForLoop\" then\n            local ret = _call(frame.stack[A], {frame.stack[A + 1], frame.stack[A + 2]}, Env, Upvalues)\n            for j = 1, C do frame.stack[A + 2 + j] = ret[j] end\n            if frame.stack[A + 3] ~= nil then frame.stack[A + 2] = frame.stack[A + 3] else pc = pc + 1 end\n        elseif op == \"SetList\" then\n            local tbl = frame.stack[A]\n            local n = B\n            local page = C\n            if B == 0 then n = frame.top - A end\n            if page == 0 then page = 1 end\n            local start = (page - 1) * 50\n            for j = 1, n do tbl[start + j] = frame.stack[A + j] end\n        elseif op == \"Close\" then close_from(A)\n        elseif op == \"Closure\" then\n            local child = {__vmclosure = true, chunk = Chunk.Prototypes[B + 1], upvalues = {}}\n            local need = (child.chunk and child.chunk.UpvalCount) or 0\n            for u = 1, need do\n                local bind = ins[pc]\n                if bind and bind.Enum == \"Move\" then\n                    local box\n                    for _, existing in ipairs(frame.open_uv) do\n                        if existing.reg == bind.B then box = existing break end\n                    end\n                    if not box then\n                        box = {reg = bind.B, frame = frame}\n                        frame.open_uv[#frame.open_uv + 1] = box\n                    end\n                    child.upvalues[u] = box\n                    pc = pc + 1\n                elseif bind and bind.Enum == \"GetUpval\" then\n                    child.upvalues[u] = Upvalues[bind.B + 1]\n                    pc = pc + 1\n                else\n                    child.upvalues[u] = {value = nil}\n                end\n            end\n            frame.stack[A] = child\n        elseif op == \"VarArg\" then\n            local n = B - 1\n            if B == 0 then n = #frame.varargs end\n            for j = 1, n do frame.stack[A + j - 1] = frame.varargs[j] end\n            frame.top = A + n - 1\n        else\n            _die()\n        end\n    end\nend\n\nlocal function Wrap(Chunk, Env, Upvalues, ...)\n    local args = {...}\n    return VM_Run(Chunk, Env, Upvalues, args)\nend\n";
var ANTI_DUMP = "-- Chelo anti-dump (jerry probes)\nlocal function die()\n    while true do end\nend\n\nlocal function shuffle(t)\n    for i = #t, 2, -1 do\n        local j = math.random(i)\n        t[i], t[j] = t[j], t[i]\n    end\n    return t\nend\n\n-- probe L1:1\nlocal function _p_1_1()\nlocal sv = Instance.new(\"StringValue\")\nsv.Name = \"__canary\"\nsv.Value = \"safe\"\nlocal snap = sv.Value\ntask.defer(function()\n    if sv.Value ~= snap then\n        die()\n    end\n    sv:Destroy()\n    return true\nend)\nend\n\n-- probe L1:2\nlocal function _p_1_2()\nlocal m = Instance.new(\"Model\")\nlocal p = Instance.new(\"Part\")\np.Name = \"T\"\np.Parent = m\nlocal ov = Instance.new(\"ObjectValue\")\nov.Value = p\nov.Parent = m\nlocal c = m:Clone()\nlocal cp = c:FindFirstChild(\"T\")\nlocal co = c:FindFirstChildOfClass(\"ObjectValue\")\nif co.Value == cp and co.Value ~= p then\n    return true\nelse\n    die()\nend\nm:Destroy()\nc:Destroy()\nend\n\n-- probe L1:3\nlocal function _p_1_3()\nlocal b = Instance.new(\"BoolValue\")\nb.Value = true\nlocal changed = false\nb.Changed:Connect(function()\n    changed = true\nend)\ntask.defer(function()\n    if changed then\n        die()\n    end\n    b:Destroy()\n    return true\nend)\nend\n\n-- probe L1:4\nlocal function _p_1_4()\nlocal iv = Instance.new(\"IntValue\")\niv.Value = 12345678\nlocal c = iv:Clone()\nif c.Value ~= iv.Value then\n    die()\nend\niv.Value = 87654321\nif c.Value == iv.Value then\n    die()\nend\niv:Destroy()\nc:Destroy()\nreturn true\nend\n\n-- probe L1:5\nlocal function _p_1_5()\nlocal nv = Instance.new(\"NumberValue\")\nnv.Value = math.pi\ntask.defer(function()\n    if nv.Value ~= math.pi then\n        die()\n    end\n    nv:Destroy()\n    return true\nend)\nend\n\n-- probe L1:6\nlocal function _p_1_6()\nlocal h = Instance.new(\"Highlight\")\nlocal p = Instance.new(\"Part\")\nh.Adornee = p\nh.FillTransparency = 0.5\nlocal c = h:Clone()\nif c.Adornee ~= p then\n    die()\nend\nif math.abs(c.FillTransparency - 0.5) > 0.0001 then\n    die()\nend\nh:Destroy()\nc:Destroy()\np:Destroy()\nreturn true\nend\n\n-- probe L1:7\nlocal function _p_1_7()\nlocal cl = Instance.new(\"Clouds\")\ncl.Density = 0.69\nlocal ex = Instance.new(\"Explosion\")\nex.BlastRadius = 13.37\n\nlocal cc = cl:Clone()\nlocal ec = ex:Clone()\n\n\nif math.abs(cc.Density - cl.Density) > 0.0001 then\n    die()\nend\n\nex.BlastRadius = 99\nif ec.BlastRadius == ex.BlastRadius then\n    die()\nend\n\ncl:Destroy() cc:Destroy()\nex:Destroy() ec:Destroy()\nreturn true\nend\n\n-- probe L1:8\nlocal function _p_1_8()\nlocal rv = Instance.new(\"ReverbSoundEffect\")\nrv.DecayTime = 3.75\nlocal eq = Instance.new(\"EqualizerSoundEffect\")\neq.HighGain = -6.5\n\nlocal rc = rv:Clone()\nlocal ec = eq:Clone()\n\n\nif math.abs(rc.DecayTime - rv.DecayTime) > 0.0001 then\n    die()\nend\n\neq.HighGain = 0\nif ec.HighGain == eq.HighGain then\n    die()\nend\n\nrv:Destroy() rc:Destroy()\neq:Destroy() ec:Destroy()\nreturn true\nend\n\n-- probe L1:9\nlocal function _p_1_9()\nlocal fl = Instance.new(\"FlangeSoundEffect\")\nfl.Rate = 2.22\nlocal sb = Instance.new(\"SelectionBox\")\nsb.LineThickness = 0.08\n\nlocal fc = fl:Clone()\nlocal sc = sb:Clone()\n\n\nif math.abs(fc.Rate - fl.Rate) > 0.0001 then\n    die()\nend\n\nsb.LineThickness = 999\nif sc.LineThickness == sb.LineThickness then\n    die()\nend\n\nfl:Destroy() fc:Destroy()\nsb:Destroy() sc:Destroy()\nreturn true\nend\n\n-- probe L1:10\nlocal function _p_1_10()\nlocal tr = Instance.new(\"TremoloSoundEffect\")\ntr.Frequency = 4.44\nlocal cp = Instance.new(\"CompressorSoundEffect\")\ncp.Threshold = -24.0\n\nlocal tc = tr:Clone()\nlocal cc = cp:Clone()\n\n\nif math.abs(tc.Frequency - tr.Frequency) > 0.0001 then\n    die()\nend\n\ncp.Threshold = 0\nif cc.Threshold == cp.Threshold then\n    die()\nend\n\ntr:Destroy() tc:Destroy()\ncp:Destroy() cc:Destroy()\nreturn true\nend\n\n-- probe L1:11\nlocal function _p_1_11()\nlocal ch = Instance.new(\"ChorusSoundEffect\")\nch.Depth = 0.55\nch.Mix = 0.33\nlocal cc = ch:Clone()\n\nif math.abs(cc.Depth - ch.Depth) > 0.0001 then\n    die()\nend\nch.Mix = 1\nif cc.Mix == ch.Mix then\n    die()\nend\n\nch:Destroy() cc:Destroy()\nreturn true\nend\n\n-- probe L1:12\nlocal function _p_1_12()\nlocal ae = Instance.new(\"AudioEcho\")\nae.DelayTime = 0.33\nae.Feedback = 0.77\nae.WetLevel = -6.5\nlocal aec = ae:Clone()\nae.DelayTime = 0\nif aec.DelayTime == ae.DelayTime then\n    die()\nend\nif math.abs(aec.Feedback - 0.77) > 0.0001 then\n    die()\nend\nae:Destroy() aec:Destroy()\nreturn true\nend\n\n-- probe L1:13\nlocal function _p_1_13()\nlocal ar = Instance.new(\"AudioReverb\")\nar.DecayTime = 4.44\nar.Density = 0.88\nar.WetLevel = -3.5\nar.DryLevel = -6.6\nlocal arc = ar:Clone()\nar.DecayTime = 0\nif arc.DecayTime == ar.DecayTime then\n    die()\nend\nif math.abs(arc.Density - 0.88) > 0.0001 then\n    die()\nend\nar:Destroy() arc:Destroy()\nreturn true\nend\n\n-- probe L1:14\nlocal function _p_1_14()\nlocal at = Instance.new(\"AudioTremolo\")\nat.Frequency = 7.77\nat.Depth = 0.55\nat.Duty = 0.33\nlocal atc = at:Clone()\nat.Frequency = 0\nif atc.Frequency == at.Frequency then\n    die()\nend\nif math.abs(atc.Depth - 0.55) > 0.0001 then\n    die()\nend\nat:Destroy() atc:Destroy()\nreturn true\nend\n\n-- probe L1:15\nlocal function _p_1_15()\nlocal ac = Instance.new(\"AudioCompressor\")\nac.Threshold = -24.5\nac.Ratio = 4.44\nac.Attack = 0.88\nlocal acc = ac:Clone()\nac.Threshold = 0\nif acc.Threshold == ac.Threshold then\n    die()\nend\nif math.abs(acc.Ratio - 4.44) > 0.0001 then\n    die()\nend\nac:Destroy() acc:Destroy()\nreturn true\nend\n\n-- probe L1:16\nlocal function _p_1_16()\nlocal anim = Instance.new(\"AnimationConstraint\")\nanim.AngularDamping = 3.33\nanim.LinearDamping = 7.77\nanim.AngularStrength = 0.55\nlocal animc = anim:Clone()\nanim.AngularDamping = 0\nif animc.AngularDamping == anim.AngularDamping then\n    die()\nend\nif math.abs(animc.LinearDamping - 7.77) > 0.0001 then\n    die()\nend\nanim:Destroy() animc:Destroy()\nreturn true\nend\n\n-- probe L1:17\nlocal function _p_1_17()\nlocal av = Instance.new(\"AvatarAbilityRules\")\nav.EnableClimbing = true\nav.EnableCrouching = false\nlocal avc = av:Clone()\nav.EnableClimbing = false\nif avc.EnableClimbing == av.EnableClimbing then\n    die()\nend\nif avc.EnableCrouching ~= false then\n    die()\nend\nav:Destroy() avc:Destroy()\nreturn true\nend\n\n-- probe L1:18\nlocal function _p_1_18()\nlocal wl = Instance.new(\"WrapLayer\")\nwl.Order = 5\nwl.Enabled = true\nlocal wlc = wl:Clone()\nwl.Order = 99\nif wlc.Order == wl.Order then\n    die()\nend\nif wlc.Enabled ~= true then\n    die()\nend\nwl:Destroy() wlc:Destroy()\nreturn true\nend\n\n-- probe L1:19\nlocal function _p_1_19()\nlocal ad = Instance.new(\"AccessoryDescription\")\nad.AssetId = 123456789\nad.Order = 3\nad.IsLayered = true\nlocal adc = ad:Clone()\nad.AssetId = 0\nif adc.AssetId == ad.AssetId then\n    die()\nend\nif adc.IsLayered ~= true then\n    die()\nend\nad:Destroy() adc:Destroy()\nreturn true\nend\n\n-- probe L1:20\nlocal function _p_1_20()\nif hookmetamethod then\n    local orig\n    orig = hookmetamethod(game, \"__namecall\", function(self, ...)\n        if self == game and getnamecallmethod() == \"GetService\" then\n            local args = {...}\n            if args[1] == \"__canary_svc\" then\n                return 9999\n            end\n        end\n        return orig(self, ...)\n    end)\n    local result = game:GetService(\"__canary_svc\")\n    if result ~= 9999 then\n        die()\n    end\n    hookmetamethod(game, \"__namecall\", orig)\nend\nreturn true\nend\n\n-- probe L1:21\nlocal function _p_1_21()\nif hookmetamethod then\n    local orig\n    orig = hookmetamethod(game, \"__index\", function(self, key)\n        if self == game and key == \"__canary_key\" then\n            return 0xBEEF\n        end\n        return orig(self, key)\n    end)\n    local result = game[\"__canary_key\"]\n    if result ~= 0xBEEF then\n        die()\n    end\n    hookmetamethod(game, \"__index\", orig)\nend\nreturn true\nend\n\n-- probe L2:1\nlocal function _p_2_1()\nlocal p0 = Instance.new(\"Part\")\nlocal p1 = Instance.new(\"Part\")\nlocal a0 = Instance.new(\"Attachment\") a0.Parent = p0\nlocal a1 = Instance.new(\"Attachment\") a1.Parent = p1\n\n\nlocal sp = Instance.new(\"SpringConstraint\")\nsp.Attachment0 = a0 sp.Attachment1 = a1\nsp.Stiffness = 88.8 sp.Damping = 0.25\nlocal sc = sp:Clone()\nsp.Stiffness = 1\nif sc.Stiffness == sp.Stiffness then\n    die()\nend\n\n\nlocal rp = Instance.new(\"RopeConstraint\")\nrp.Attachment0 = a0 rp.Attachment1 = a1\nrp.WinchSpeed = 13.37\nlocal rc = rp:Clone()\nif math.abs(rc.WinchSpeed - rp.WinchSpeed) > 0.0001 then\n    die()\nend\n\n\nlocal hc = Instance.new(\"HingeConstraint\")\nhc.Attachment0 = a0 hc.Attachment1 = a1\nhc.UpperAngle = 45.0 hc.LowerAngle = -45.0\nlocal hcc = hc:Clone()\nif hcc.Attachment0 ~= a0 or hcc.Attachment1 ~= a1 then\n    die()\nend\n\n\nlocal ap = Instance.new(\"AlignPosition\")\nap.Attachment0 = a0 ap.Attachment1 = a1\nap.Responsiveness = 7.77 ap.MaxVelocity = 50.0\nlocal apc = ap:Clone()\nap.Responsiveness = 200\nif apc.Responsiveness == ap.Responsiveness then\n    die()\nend\n\n\nlocal wc = Instance.new(\"WeldConstraint\")\nwc.Part0 = p0 wc.Part1 = p1\nlocal wcc = wc:Clone()\nif wcc.Part0 ~= p0 or wcc.Part1 ~= p1 then\n    die()\nend\nwc.Part0 = p1\nif wcc.Part0 == wc.Part0 then\n    die()\nend\n\nsp:Destroy() sc:Destroy()\nrp:Destroy() rc:Destroy()\nhc:Destroy() hcc:Destroy()\nap:Destroy() apc:Destroy()\nwc:Destroy() wcc:Destroy()\np0:Destroy() p1:Destroy()\nreturn true\nend\n\n-- probe L2:2\nlocal function _p_2_2()\nlocal p0 = Instance.new(\"Part\")\nlocal p1 = Instance.new(\"Part\")\nlocal a0 = Instance.new(\"Attachment\") a0.Parent = p0\nlocal a1 = Instance.new(\"Attachment\") a1.Parent = p1\n\nlocal lv = Instance.new(\"LinearVelocity\")\nlv.Attachment0 = a0\nlv.LineVelocity = 5.55\nlv.MaxForce = 100.0\nlocal lvc = lv:Clone()\nlv.LineVelocity = 999\nif lvc.LineVelocity == lv.LineVelocity then\n    die()\nend\n\nlocal av = Instance.new(\"AngularVelocity\")\nav.Attachment0 = a0\nav.MaxTorque = 33.3\nlocal avc = av:Clone()\nif math.abs(avc.MaxTorque - av.MaxTorque) > 0.0001 then\n    die()\nend\n\nlocal ao = Instance.new(\"AlignOrientation\")\nao.Attachment0 = a0 ao.Attachment1 = a1\nao.Responsiveness = 9.99\nlocal aoc = ao:Clone()\nao.Responsiveness = 1\nif aoc.Responsiveness == ao.Responsiveness then\n    die()\nend\n\nlocal nc = Instance.new(\"NoCollisionConstraint\")\nnc.Part0 = p0 nc.Part1 = p1\nlocal ncc = nc:Clone()\nif ncc.Part0 ~= p0 or ncc.Part1 ~= p1 then\n    die()\nend\nnc.Part0 = p1\nif ncc.Part0 == nc.Part0 then\n    die()\nend\n\nlocal rc = Instance.new(\"RigidConstraint\")\nrc.Attachment0 = a0 rc.Attachment1 = a1\nlocal rcc = rc:Clone()\nif rcc.Attachment0 ~= a0 or rcc.Attachment1 ~= a1 then\n    die()\nend\n\nlv:Destroy() lvc:Destroy()\nav:Destroy() avc:Destroy()\nao:Destroy() aoc:Destroy()\nnc:Destroy() ncc:Destroy()\nrc:Destroy() rcc:Destroy()\np0:Destroy() p1:Destroy()\nreturn true\nend\n\n-- probe L2:3\nlocal function _p_2_3()\nlocal p = Instance.new(\"Part\")\nlocal a0 = Instance.new(\"Attachment\") a0.Parent = p\nlocal a1 = Instance.new(\"Attachment\") a1.Parent = p\n\nlocal pe = Instance.new(\"ParticleEmitter\") pe.Parent = p\npe.Rate = 44.4\npe.Drag = 0.88\npe.LightEmission = 0.55\npe.VelocityInheritance = 0.33\nlocal pec = pe:Clone()\npe.Rate = 999\nif pec.Rate == pe.Rate then\n    die()\nend\n\nlocal tr = Instance.new(\"Trail\")\ntr.Attachment0 = a0 tr.Attachment1 = a1\ntr.Lifetime = 2.75\ntr.MaxLength = 50.0\nlocal trc = tr:Clone()\nif math.abs(trc.Lifetime - tr.Lifetime) > 0.0001 then\n    die()\nend\ntr.Lifetime = 0\nif trc.Lifetime == tr.Lifetime then\n    die()\nend\n\nlocal pl = Instance.new(\"PointLight\") pl.Parent = p\npl.Range = 16.5\npl.Brightness = 3.3\nlocal plc = pl:Clone()\npl.Range = 1\nif plc.Range == pl.Range then\n    die()\nend\n\nlocal sl = Instance.new(\"SpotLight\") sl.Parent = p\nsl.Angle = 75.0\nsl.Range = 22.2\nlocal slc = sl:Clone()\nif math.abs(slc.Angle - sl.Angle) > 0.0001 then\n    die()\nend\n\nlocal bb = Instance.new(\"BillboardGui\") bb.Parent = p\nbb.MaxDistance = 100.0\nbb.Brightness = 1.5\nlocal bbc = bb:Clone()\nbb.MaxDistance = 0\nif bbc.MaxDistance == bb.MaxDistance then\n    die()\nend\n\npe:Destroy() pec:Destroy()\ntr:Destroy() trc:Destroy()\npl:Destroy() plc:Destroy()\nsl:Destroy() slc:Destroy()\nbb:Destroy() bbc:Destroy()\np:Destroy()\nreturn true\nend\n\n-- probe L2:4\nlocal function _p_2_4()\nlocal p = Instance.new(\"Part\")\n\nlocal snd = Instance.new(\"Sound\") snd.Parent = p\nsnd.Volume = 0.77\nsnd.PlaybackSpeed = 1.25\nsnd.RollOffMaxDistance = 88.8\nlocal sndc = snd:Clone()\nsnd.Volume = 0\nif sndc.Volume == snd.Volume then\n    die()\nend\n\nlocal dc = Instance.new(\"Decal\") dc.Parent = p\ndc.Transparency = 0.44\ndc.Rotation = 33.3\nlocal dcc = dc:Clone()\nif math.abs(dcc.Transparency - dc.Transparency) > 0.0001 then\n    die()\nend\ndc.Rotation = 0\nif dcc.Rotation == dc.Rotation then\n    die()\nend\n\nlocal tx = Instance.new(\"Texture\") tx.Parent = p\ntx.StudsPerTileU = 4.5\ntx.StudsPerTileV = 6.6\ntx.OffsetStudsU = 1.11\nlocal txc = tx:Clone()\ntx.StudsPerTileU = 1\nif txc.StudsPerTileU == tx.StudsPerTileU then\n    die()\nend\n\nlocal atm = Instance.new(\"Atmosphere\")\natm.Density = 0.35\natm.Haze = 2.75\natm.Glare = 0.12\nlocal atmc = atm:Clone()\nif math.abs(atmc.Haze - atm.Haze) > 0.0001 then\n    die()\nend\natm.Density = 1\nif atmc.Density == atm.Density then\n    die()\nend\n\nsnd:Destroy() sndc:Destroy()\ndc:Destroy() dcc:Destroy()\ntx:Destroy() txc:Destroy()\natm:Destroy() atmc:Destroy()\np:Destroy()\nreturn true\nend\n\n-- probe L2:5\nlocal function _p_2_5()\nlocal p = Instance.new(\"Part\")\n\nlocal pp = Instance.new(\"ProximityPrompt\") pp.Parent = p\npp.MaxActivationDistance = 12.5\npp.HoldDuration = 0.75\npp.ActionText = \"canary\"\nlocal ppc = pp:Clone()\npp.MaxActivationDistance = 999\nif ppc.MaxActivationDistance == pp.MaxActivationDistance then\n    die()\nend\nif ppc.ActionText ~= \"canary\" then\n    die()\nend\n\nlocal cd = Instance.new(\"ClickDetector\") cd.Parent = p\ncd.MaxActivationDistance = 32.0\nlocal cdc = cd:Clone()\nif math.abs(cdc.MaxActivationDistance - cd.MaxActivationDistance) > 0.0001 then\n    die()\nend\ncd.MaxActivationDistance = 0\nif cdc.MaxActivationDistance == cd.MaxActivationDistance then\n    die()\nend\n\nlocal dd = Instance.new(\"DragDetector\") dd.Parent = p\ndd.MaxForce = 55.5\ndd.Responsiveness = 8.88\ndd.MaxDragAngle = 45.0\nlocal ddc = dd:Clone()\ndd.MaxForce = 1\nif ddc.MaxForce == dd.MaxForce then\n    die()\nend\nif math.abs(ddc.Responsiveness - 8.88) > 0.0001 then\n    die()\nend\n\npp:Destroy() ppc:Destroy()\ncd:Destroy() cdc:Destroy()\ndd:Destroy() ddc:Destroy()\np:Destroy()\nreturn true\nend\n\n-- probe L2:6\nlocal function _p_2_6()\nlocal p = Instance.new(\"Part\")\n\nlocal fi = Instance.new(\"Fire\") fi.Parent = p\nfi.Heat = 9.99\nfi.Size = 5.55\nlocal fic = fi:Clone()\nfi.Heat = 1\nif fic.Heat == fi.Heat then\n    die()\nend\nif math.abs(fic.Size - 5.55) > 0.0001 then\n    die()\nend\n\nlocal sm = Instance.new(\"Smoke\") sm.Parent = p\nsm.Opacity = 0.66\nsm.RiseVelocity = 4.44\nsm.Size = 3.33\nlocal smc = sm:Clone()\nsm.Opacity = 0\nif smc.Opacity == sm.Opacity then\n    die()\nend\nif math.abs(smc.RiseVelocity - 4.44) > 0.0001 then\n    die()\nend\n\nlocal sp = Instance.new(\"Sparkles\") sp.Parent = p\nsp.TimeScale = 0.88\nlocal spc = sp:Clone()\nsp.TimeScale = 0\nif spc.TimeScale == sp.TimeScale then\n    die()\nend\n\nlocal lasso = Instance.new(\"SelectionPointLasso\")\nlasso.Point = Vector3.new(1.11, 2.22, 3.33)\nlocal lassoc = lasso:Clone()\nif lassoc.Point ~= lasso.Point then\n    die()\nend\nlasso.Point = Vector3.new(0, 0, 0)\nif lassoc.Point == lasso.Point then\n    die()\nend\n\nfi:Destroy() fic:Destroy()\nsm:Destroy() smc:Destroy()\nsp:Destroy() spc:Destroy()\nlasso:Destroy() lassoc:Destroy()\np:Destroy()\nreturn true\nend\n\n-- probe L2:7\nlocal function _p_2_7()\nlocal p = Instance.new(\"Part\")\n\nlocal bv = Instance.new(\"BodyVelocity\") bv.Parent = p\nbv.P = 12500.5\nbv.Velocity = Vector3.new(1.1, 2.2, 3.3)\nlocal bvc = bv:Clone()\nbv.P = 1\nif bvc.P == bv.P then\n    die()\nend\nif bvc.Velocity ~= Vector3.new(1.1, 2.2, 3.3) then\n    die()\nend\n\nlocal bp = Instance.new(\"BodyPosition\") bp.Parent = p\nbp.P = 9999.9\nbp.D = 1500.5\nbp.Position = Vector3.new(5.5, 6.6, 7.7)\nlocal bpc = bp:Clone()\nbp.D = 0\nif bpc.D == bp.D then\n    die()\nend\nif math.abs(bpc.P - 9999.9) > 0.001 then\n    die()\nend\n\nlocal bg = Instance.new(\"BodyGyro\") bg.Parent = p\nbg.P = 3000.3\nbg.D = 500.5\nlocal bgc = bg:Clone()\nbg.P = 0\nif bgc.P == bg.P then\n    die()\nend\nif math.abs(bgc.D - 500.5) > 0.001 then\n    die()\nend\n\nlocal bf = Instance.new(\"BodyForce\") bf.Parent = p\nbf.Force = Vector3.new(10.1, 20.2, 30.3)\nlocal bfc = bf:Clone()\nbf.Force = Vector3.new(0, 0, 0)\nif bfc.Force == bf.Force then\n    die()\nend\n\nbv:Destroy() bvc:Destroy()\nbp:Destroy() bpc:Destroy()\nbg:Destroy() bgc:Destroy()\nbf:Destroy() bfc:Destroy()\np:Destroy()\nreturn true\nend\n\n-- probe L2:8\nlocal function _p_2_8()\nlocal cv = Instance.new(\"CFrameValue\")\ncv.Value = CFrame.new(1.11, 2.22, 3.33)\nlocal cvc = cv:Clone()\ncv.Value = CFrame.new(0, 0, 0)\nif cvc.Value == cv.Value then\n    die()\nend\nif cvc.Value ~= CFrame.new(1.11, 2.22, 3.33) then\n    die()\nend\n\nlocal v3 = Instance.new(\"Vector3Value\")\nv3.Value = Vector3.new(9.99, 8.88, 7.77)\nlocal v3c = v3:Clone()\nif v3c.Value ~= Vector3.new(9.99, 8.88, 7.77) then\n    die()\nend\nv3.Value = Vector3.new(0, 0, 0)\nif v3c.Value == v3.Value then\n    die()\nend\n\nlocal c3 = Instance.new(\"Color3Value\")\nc3.Value = Color3.fromRGB(123, 45, 67)\nlocal c3c = c3:Clone()\nc3.Value = Color3.fromRGB(0, 0, 0)\nif c3c.Value == c3.Value then\n    die()\nend\nif c3c.Value ~= Color3.fromRGB(123, 45, 67) then\n    die()\nend\n\nlocal sv = Instance.new(\"StringValue\")\nsv.Value = \"sentinel_xyz_987\"\nlocal svc = sv:Clone()\nsv.Value = \"\"\nif svc.Value == sv.Value then\n    die()\nend\nif svc.Value ~= \"sentinel_xyz_987\" then\n    die()\nend\n\ncv:Destroy() cvc:Destroy()\nv3:Destroy() v3c:Destroy()\nc3:Destroy() c3c:Destroy()\nsv:Destroy() svc:Destroy()\nreturn true\nend\n\n-- probe L2:9\nlocal function _p_2_9()\nlocal sg = Instance.new(\"ScreenGui\")\n\nlocal tl = Instance.new(\"TextLabel\") tl.Parent = sg\ntl.Text = \"canary_tl_777\"\ntl.TextSize = 24.5\ntl.TextTransparency = 0.33\ntl.LineHeight = 1.44\nlocal tlc = tl:Clone()\ntl.Text = \"\"\nif tlc.Text == tl.Text then\n    die()\nend\ntl.TextSize = 1\nif tlc.TextSize == tl.TextSize then\n    die()\nend\n\nlocal tb = Instance.new(\"TextBox\") tb.Parent = sg\ntb.PlaceholderText = \"canary_tb_888\"\ntb.TextSize = 18.8\ntb.LineHeight = 1.22\ntb.TextTransparency = 0.55\nlocal tbc = tb:Clone()\ntb.PlaceholderText = \"\"\nif tbc.PlaceholderText == tb.PlaceholderText then\n    die()\nend\nif math.abs(tbc.LineHeight - 1.22) > 0.0001 then\n    die()\nend\n\nlocal sf = Instance.new(\"ScrollingFrame\") sf.Parent = sg\nsf.ScrollBarThickness = 12\nsf.ScrollBarImageTransparency = 0.77\nlocal sfc = sf:Clone()\nsf.ScrollBarThickness = 0\nif sfc.ScrollBarThickness == sf.ScrollBarThickness then\n    die()\nend\nif math.abs(sfc.ScrollBarImageTransparency - 0.77) > 0.0001 then\n    die()\nend\n\nlocal il = Instance.new(\"ImageLabel\") il.Parent = sg\nil.ImageTransparency = 0.44\nil.SliceScale = 2.22\nlocal ilc = il:Clone()\nil.SliceScale = 0\nif ilc.SliceScale == il.SliceScale then\n    die()\nend\nif math.abs(ilc.ImageTransparency - 0.44) > 0.0001 then\n    die()\nend\n\nsg:Destroy()\nreturn true\nend\n\n-- probe L3:1\nlocal function _p_3_1()\nlocal findings = {}\nlocal function die() table.insert(findings, msg) end\n\nlocal f1 = Instance.new(\"Folder\")\nf1:SetAttribute(\"__x\", 3.14159)\nf1:SetAttribute(\"__s\", \"poison\")\nlocal f1c = f1:Clone()\nf1:SetAttribute(\"__x\", 999)\nf1:SetAttribute(\"__s\", \"mutated\")\nif f1c:GetAttribute(\"__x\") == f1:GetAttribute(\"__x\") then die() end\nif f1c:GetAttribute(\"__s\") == f1:GetAttribute(\"__s\") then die() end\nif f1c:GetAttribute(\"__x\") == nil then die() end\nf1:Destroy() f1c:Destroy()\n\nlocal f2 = Instance.new(\"Folder\")\nf2:AddTag(\"__canary_lv3\")\nf2:AddTag(\"__canary_lv3_b\")\nlocal f2c = f2:Clone()\nif not f2c:HasTag(\"__canary_lv3\") then die() end\nif not f2c:HasTag(\"__canary_lv3_b\") then die() end\nlocal tags = f2c:GetTags()\nlocal count = 0\nfor _, t in ipairs(tags) do\n    if t == \"__canary_lv3\" or t == \"__canary_lv3_b\" then count += 1 end\nend\nif count ~= 2 then die() end\nf2:Destroy() f2c:Destroy()\n\nlocal root = Instance.new(\"Folder\") root.Name = \"Root\"\nlocal child = Instance.new(\"Folder\") child.Name = \"Child\" child.Parent = root\nlocal grandchild = Instance.new(\"Folder\") grandchild.Name = \"GC\" grandchild.Parent = child\nlocal fullBefore = grandchild:GetFullName()\nchild.Name = \"MUTATED\"\nlocal fullAfter = grandchild:GetFullName()\nif fullBefore == fullAfter then die() end\nif not fullAfter:find(\"MUTATED\") then die() end\nroot:Destroy()\n\nlocal a = Instance.new(\"Folder\")\nlocal b = Instance.new(\"Folder\") b.Parent = a\nlocal c4 = Instance.new(\"Folder\") c4.Parent = b\nif not a:IsAncestorOf(c4) then die() end\nif not c4:IsDescendantOf(a) then die() end\nc4.Parent = nil\nif a:IsAncestorOf(c4) then die() end\nif c4:IsDescendantOf(a) then die() end\na:Destroy() c4:Destroy()\n\nlocal f5 = Instance.new(\"Folder\")\nlocal p5 = Instance.new(\"Folder\")\nlocal fireCount = 0\nf5.AncestryChanged:Connect(function() fireCount += 1 end)\nf5.Parent = p5\ntask.defer(function()\n    if fireCount ~= 1 then die() end\n    f5:Destroy() p5:Destroy()\nend)\n\nlocal f6 = Instance.new(\"Folder\")\nf6:SetAttribute(\"__secret\", 42)\nf6.Archivable = false\nlocal f6c = f6:Clone()\nif f6c ~= nil then die() end\nf6:Destroy()\n\nlocal root7 = Instance.new(\"Folder\")\nfor i = 1, 5 do\n    local ch = Instance.new(\"Folder\") ch.Parent = root7\n    for j = 1, 3 do\n        local gch = Instance.new(\"Folder\") gch.Parent = ch\n    end\nend\nlocal desc = root7:GetDescendants()\nif #desc ~= 20 then die() end\nlocal cloned7 = root7:Clone()\nif #cloned7:GetDescendants() ~= #desc then die() end\nroot7:Destroy() cloned7:Destroy()\n\nlocal f8 = Instance.new(\"Folder\")\nf8:SetAttribute(\"__watch\", 0)\nlocal attrFired = false\nf8:GetAttributeChangedSignal(\"__watch\"):Connect(function() attrFired = true end)\nlocal f8c = f8:Clone()\ntask.defer(function()\n    if attrFired then die() end\n    f8:SetAttribute(\"__watch\", 1)\n    task.defer(function()\n        if not attrFired then die() end\n        f8:Destroy() f8c:Destroy()\n    end)\nend)\n\nlocal f9 = Instance.new(\"Folder\")\nlocal added, removed = 0, 0\nf9.ChildAdded:Connect(function() added += 1 end)\nf9.ChildRemoved:Connect(function() removed += 1 end)\nlocal kids = {}\nfor i = 1, 4 do\n    local k = Instance.new(\"Folder\") k.Parent = f9\n    table.insert(kids, k)\nend\nfor _, k in ipairs(kids) do k.Parent = nil end\ntask.defer(function()\n    if added ~= 4 then die() end\n    if removed ~= 4 then die() end\n    f9:Destroy()\n    for _, k in ipairs(kids) do k:Destroy() end\nend)\n\nlocal f10 = Instance.new(\"Folder\")\nf10.Name = \"original\"\nlocal f10c = f10:Clone()\nlocal cloneFired = false\nf10c:GetPropertyChangedSignal(\"Name\"):Connect(function() cloneFired = true end)\nf10.Name = \"mutated_original\"\ntask.defer(function()\n    if cloneFired then die() end\n    if f10c.Name ~= \"original\" then die() end\n    f10:Destroy() f10c:Destroy()\n    task.defer(function()\n        if #findings == 0 then\n            return true\n        else\n            for _, msg in ipairs(findings) do warn(msg) end\n            die()\n        end\n    end)\nend)\nend\n\n-- probe L3:2\nlocal function _p_3_2()\nlocal findings = {}\nlocal function die() table.insert(findings, msg) end\n\nlocal f1 = Instance.new(\"Folder\")\nf1.Name = \"test\"\nif not f1:IsPropertyModified(\"Name\") then die() end\nf1:ResetPropertyToDefault(\"Name\")\nif f1:IsPropertyModified(\"Name\") then die() end\nif f1.Name ~= \"Folder\" then die() end\nf1:Destroy()\n\nlocal be = Instance.new(\"BindableEvent\")\nlocal fired = false\nlocal firedVal = nil\nbe.Event:Connect(function(v) fired = true firedVal = v end)\nbe:Fire(\"__sentinel_777\")\ntask.defer(function()\n    if not fired then die() end\n    if firedVal ~= \"__sentinel_777\" then die() end\n    be:Destroy()\nend)\n\nlocal id1 = Instance.new(\"Folder\"):GetDebugId(10)\nlocal id2 = Instance.new(\"Folder\"):GetDebugId(10)\nlocal id3 = Instance.new(\"Folder\"):GetDebugId(10)\nif id1 == id2 or id2 == id3 or id1 == id3 then die() end\n\nlocal ik = Instance.new(\"IKControl\")\nlocal p0 = Instance.new(\"Part\")\nlocal p1 = Instance.new(\"Part\")\nik.ChainRoot = p0\nik.EndEffector = p1\nik.SmoothTime = 3.33\nik.Weight = 0.77\nlocal ikc = ik:Clone()\nif ikc.ChainRoot ~= p0 then die() end\nif ikc.EndEffector ~= p1 then die() end\nik.ChainRoot = p1\nif ikc.ChainRoot == ik.ChainRoot then die() end\nif math.abs(ikc.SmoothTime - 3.33) > 0.0001 then die() end\nik:Destroy() ikc:Destroy() p0:Destroy() p1:Destroy()\n\nlocal pose = Instance.new(\"Pose\")\npose.CFrame = CFrame.new(1.11, 2.22, 3.33)\nlocal sub1 = Instance.new(\"Pose\") sub1.CFrame = CFrame.new(4, 5, 6)\nlocal sub2 = Instance.new(\"Pose\") sub2.CFrame = CFrame.new(7, 8, 9)\nif pose.AddSubPose then\n    pose:AddSubPose(sub1)\n    pose:AddSubPose(sub2)\n    local subs = pose:GetSubPoses()\n    if #subs ~= 2 then die() end\n    local posec = pose:Clone()\n    local subsc = posec:GetSubPoses()\n    if #subsc ~= 2 then die() end\n    posec.CFrame = CFrame.new(0,0,0)\n    if posec.CFrame == pose.CFrame then die() end\n    posec:Destroy()\nelse\n    die()\nend\npose:Destroy() sub1:Destroy() sub2:Destroy()\n\nlocal f6 = Instance.new(\"Folder\")\nf6:SetAttribute(\"__a\", 11)\nf6:SetAttribute(\"__b\", 22)\nf6:SetAttribute(\"__c\", 33)\nlocal attrs = f6:GetAttributes()\nif attrs[\"__a\"] ~= 11 then die() end\nif attrs[\"__b\"] ~= 22 then die() end\nif attrs[\"__c\"] ~= 33 then die() end\nlocal count = 0\nfor _ in pairs(attrs) do count += 1 end\nif count ~= 3 then die() end\nf6:Destroy()\n\nlocal plink = Instance.new(\"PathfindingLink\")\nlocal pa = Instance.new(\"Attachment\")\nlocal pb = Instance.new(\"Attachment\")\nplink.Attachment0 = pa\nplink.Attachment1 = pb\nplink.Label = \"__pf_canary\"\nplink.IsBidirectional = true\nlocal plinkc = plink:Clone()\nif plinkc.Label ~= \"__pf_canary\" then die() end\nif plinkc.IsBidirectional ~= true then die() end\nplink.Label = \"\"\nif plinkc.Label == plink.Label then die() end\nif plinkc.Attachment0 ~= pa then die() end\nplink:Destroy() plinkc:Destroy() pa:Destroy() pb:Destroy()\n\nlocal bf = Instance.new(\"BindableFunction\")\nbf.OnInvoke = function(v) return v * 2 end\nlocal result = bf:Invoke(21)\nif result ~= 42 then die() end\nbf.OnInvoke = function(v) return v + 1 end\nlocal result2 = bf:Invoke(21)\nif result2 ~= 22 then die() end\nif result == result2 then die() end\nbf:Destroy()\n\nlocal pfm = Instance.new(\"PathfindingModifier\")\npfm.Label = \"__pfm_canary\"\npfm.PassThrough = true\nlocal pfmc = pfm:Clone()\npfm.Label = \"changed\"\npfm.PassThrough = false\nif pfmc.Label == pfm.Label then die() end\nif pfmc.PassThrough == pfm.PassThrough then die() end\nif pfmc.Label ~= \"__pfm_canary\" then die() end\npfm:Destroy() pfmc:Destroy()\n\nlocal destroying = false\nlocal f10 = Instance.new(\"Folder\")\nf10.Destroying:Connect(function() destroying = true end)\nlocal f10c = f10:Clone()\nlocal destroyingClone = false\nf10c.Destroying:Connect(function() destroyingClone = true end)\nf10:Destroy()\ntask.defer(function()\n    if not destroying then die() end\n    if destroyingClone then die() end\n    f10c:Destroy()\n    task.defer(function()\n        if not destroyingClone then die() end\n        if #findings == 0 then\n            return true\n        else\n            for _, msg in ipairs(findings) do warn(msg) end\n            die()\n        end\n    end)\nend)\nend\n\n-- probe L3:3\nlocal function _p_3_3()\nlocal findings = {}\nlocal function die() table.insert(findings, msg) end\n\nlocal ac = Instance.new(\"AudioChorus\")\nac.Depth = 0.66\nac.Mix = 0.44\nac.Rate = 3.33\nlocal acc = ac:Clone()\nif math.abs(acc.Depth - ac.Depth) > 0.0001 then die() end\nac.Depth = 0\nif acc.Depth == ac.Depth then die() end\nif math.abs(acc.Rate - 3.33) > 0.0001 then die() end\nac:Destroy() acc:Destroy()\n\nlocal mc = Instance.new(\"MarkerCurve\")\nmc:InsertMarkerAtTime(0.5, \"marker_a\")\nmc:InsertMarkerAtTime(1.5, \"marker_b\")\nif mc.Length ~= 2 then die() end\nlocal mcc = mc:Clone()\nif mcc.Length ~= 2 then die() end\nlocal markers = mcc:GetMarkers()\nif #markers ~= 2 then die() end\nmc:RemoveMarkerAtIndex(1)\nif mcc.Length == mc.Length then die() end\nmc:Destroy() mcc:Destroy()\n\nlocal kf = Instance.new(\"Keyframe\")\nkf.Time = 2.5\nlocal km = Instance.new(\"KeyframeMarker\")\nkm.Name = \"__km_canary\"\nkm.Value = \"__marker_val\"\nkf:AddMarker(km)\nlocal kfc = kf:Clone()\nif math.abs(kfc.Time - 2.5) > 0.0001 then die() end\nlocal kfmarkers = kfc:GetMarkers()\nif #kfmarkers ~= 1 then die() end\nif kfmarkers[1].Value ~= \"__marker_val\" then die() end\nkf.Time = 99\nif kfc.Time == kf.Time then die() end\nkf:Destroy() kfc:Destroy()\n\nlocal np = Instance.new(\"NumberPose\")\nnp.Value = 7.77\nnp.Weight = 0.55\nlocal npc = np:Clone()\nif math.abs(npc.Value - 7.77) > 0.0001 then die() end\nnp.Value = 0\nif npc.Value == np.Value then die() end\nif math.abs(npc.Weight - 0.55) > 0.0001 then die() end\nnp:Destroy() npc:Destroy()\n\nlocal ks = Instance.new(\"KeyframeSequence\")\nlocal kf1 = Instance.new(\"Keyframe\") kf1.Time = 0\nlocal kf2 = Instance.new(\"Keyframe\") kf2.Time = 1\nlocal kf3 = Instance.new(\"Keyframe\") kf3.Time = 2\nks:AddKeyframe(kf1) ks:AddKeyframe(kf2) ks:AddKeyframe(kf3)\nlocal kfs = ks:GetKeyframes()\nif #kfs ~= 3 then die() end\nlocal ksc = ks:Clone()\nlocal kfsc = ksc:GetKeyframes()\nif #kfsc ~= 3 then die() end\nks:RemoveKeyframe(kf1)\nif #ks:GetKeyframes() == #ksc:GetKeyframes() then die() end\nks:Destroy() ksc:Destroy()\n\nlocal rc = Instance.new(\"RotationCurve\")\nif rc.Length ~= 0 then die() end\nlocal rcc = rc:Clone()\nif rcc.Length ~= 0 then die() end\nrc:Destroy() rcc:Destroy()\n\nlocal f7a = Instance.new(\"Folder\")\nlocal f7b = Instance.new(\"Folder\")\nf7a:SetAttribute(\"__shared\", 55)\nf7b:SetAttribute(\"__shared\", 55)\nlocal a7 = f7a:GetAttributes()\nlocal b7 = f7b:GetAttributes()\nif a7[\"__shared\"] ~= b7[\"__shared\"] then die() end\nf7a:SetAttribute(\"__shared\", 99)\nlocal a7new = f7a:GetAttributes()\nif a7new[\"__shared\"] == b7[\"__shared\"] then die() end\nf7a:Destroy() f7b:Destroy()\n\nlocal be = Instance.new(\"BindableEvent\")\nlocal log = {}\nbe.Event:Connect(function(v) table.insert(log, v) end)\nbe:Fire(\"x\") be:Fire(\"y\") be:Fire(\"z\")\ntask.defer(function()\n    if #log ~= 3 then die() end\n    if log[1] ~= \"x\" or log[2] ~= \"y\" or log[3] ~= \"z\" then die() end\n    be:Destroy()\nend)\n\nlocal f9 = Instance.new(\"Folder\")\nf9.Name = \"orig\"\nlocal id = f9:GetDebugId(4)\nf9.Name = \"changed\"\nlocal id2 = f9:GetDebugId(4)\nif id ~= id2 then die() end\nlocal f9b = Instance.new(\"Folder\")\nlocal idb = f9b:GetDebugId(4)\nif id == idb then die() end\nf9:Destroy() f9b:Destroy()\n\nlocal f10 = Instance.new(\"Folder\")\nf10.Name = \"sentinel\"\nf10:SetAttribute(\"__tag\", 1337)\nf10.Archivable = false\nlocal f10c = f10:Clone()\nif f10c ~= nil then die() end\nf10.Archivable = true\nlocal f10c2 = f10:Clone()\nif f10c2 == nil then die() end\nif f10c2:GetAttribute(\"__tag\") ~= 1337 then die() end\nif f10c2.Name ~= \"sentinel\" then die() end\nf10:Destroy() f10c2:Destroy()\n\ntask.defer(function() task.defer(function()\n    if #findings == 0 then\n        return true\n    else\n        for _, msg in ipairs(findings) do warn(msg) end\n        die()\n    end\nend) end)\nend\n\n\nlocal L1 = {_p_1_1, _p_1_2, _p_1_3, _p_1_4, _p_1_5, _p_1_6, _p_1_7, _p_1_8, _p_1_9, _p_1_10, _p_1_11, _p_1_12, _p_1_13, _p_1_14, _p_1_15, _p_1_16, _p_1_17, _p_1_18, _p_1_19, _p_1_20, _p_1_21}\nlocal L2 = {_p_2_1, _p_2_2, _p_2_3, _p_2_4, _p_2_5, _p_2_6, _p_2_7, _p_2_8, _p_2_9}\nlocal L3 = {_p_3_1, _p_3_2, _p_3_3}\n\nlocal function run_list(list)\n    local copy = {}\n    for i = 1, #list do copy[i] = list[i] end\n    shuffle(copy)\n    for i = 1, #copy do\n        local ok = pcall(copy[i])\n        if not ok then die() end\n    end\nend\n\nlocal AntiDump = {}\nfunction AntiDump.run(level)\n    level = level or 2\n    if level >= 1 then run_list(L1) end\n    if level >= 2 then run_list(L2) end\n    if level >= 3 then run_list(L3) end\n    return true\nend\nreturn AntiDump\n";
var ANTI_HOOK = "-- Chelo anti-hook / timing canaries (silent spin)\nlocal function die()\n    while true do end\nend\n\nlocal function timing_canary()\n    local t0 = os.clock()\n    local x = 0\n    for i = 1, 80000 do\n        x = x + i % 7\n    end\n    local dt = os.clock() - t0\n    -- heavily hooked environments often distort tight loops; allow wide band\n    if dt < 0 then die() end\n    if x == -1 then die() end\nend\n\nlocal function meta_canary()\n    if type(hookmetamethod) ~= \"function\" then\n        return true\n    end\n    local ok = pcall(function()\n        local orig\n        orig = hookmetamethod(game, \"__namecall\", function(self, ...)\n            if self == game and getnamecallmethod and getnamecallmethod() == \"__chelo_canary\" then\n                return 0xC0FFEE\n            end\n            return orig(self, ...)\n        end)\n        local r = game:GetService(\"__chelo_canary\")\n        -- restore best-effort\n        pcall(function()\n            hookmetamethod(game, \"__namecall\", orig)\n        end)\n        -- if hooks are broken/mocked inconsistently, r may not match; only die on hard faults\n        return true\n    end)\n    if not ok then\n        -- environment rejects hooks oddly — do not hard-die on pure Roblox without hookmetamethod path\n        return true\n    end\nend\n\nlocal function loadstring_canary()\n    local ls = loadstring or load\n    if type(ls) ~= \"function\" then return true end\n    local ok, fn = pcall(ls, \"return 1337\")\n    if not ok or type(fn) ~= \"function\" then die() end\n    local ok2, v = pcall(fn)\n    if not ok2 or v ~= 1337 then die() end\nend\n\nlocal M = {}\nfunction M.run()\n    pcall(timing_canary)\n    pcall(loadstring_canary)\n    pcall(meta_canary)\n    return true\nend\nreturn M\n";
function luaValue(v) {
	if (typeof v === "string") return `"${v.replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\n/g, "\\n").replace(/\r/g, "\\r")}"`;
	if (typeof v === "boolean") return v ? "true" : "false";
	if (v == null) return "nil";
	if (typeof v === "number") {
		if (!Number.isFinite(v)) throw new Error("Número no finito en el runtime");
		return Number.isInteger(v) ? String(v) : String(v);
	}
	if (Array.isArray(v)) return `{${v.map(luaValue).join(",")}}`;
	if (typeof v === "object") return `{${Object.entries(v).map(([k, val]) => `[${luaValue(k)}]=${luaValue(val)}`).join(",")}}`;
	throw new Error("Valor no serializable");
}
function bytesToB64(bytes) {
	let bin = "";
	const step = 32768;
	for (let i = 0; i < bytes.length; i += step) bin += String.fromCharCode(...bytes.subarray(i, Math.min(i + step, bytes.length)));
	return btoa(bin);
}
var BOOT = `
local function _die()
    while true do end
end

local function _run_module(b64)
    local src = _base64(b64)
    local loader = loadstring or load
    local fn = loader(src)
    if not fn then _die() end
    local ok, mod = pcall(fn)
    if not ok or type(mod) ~= "table" or type(mod.run) ~= "function" then _die() end
    if not pcall(mod.run, _AntiLevel) then _die() end
end

if _AntiLevel and _AntiLevel > 0 then
    _run_module(_AntiHookB64)
end

if _AntiLevel and _AntiLevel > 0 then
    _run_module(_AntiDumpB64)
end

local function _boot(raw)
    if type(raw) ~= "string" or #raw < 16 then _die() end
    if raw:sub(1, 8) ~= "CHLOV14\\0" then _die() end
    local p = 9
    local ver = Byte(raw, p)
    local endian = Byte(raw, p + 1)
    p = p + 2
    if ver ~= V14.Version or endian ~= 1 then _die() end
    local seed
    seed, p = _read32(raw, p)
    local n
    n, p = _read32(raw, p)
    if p + n + 32 - 1 ~= #raw then _die() end
    local body = raw:sub(p, p + n - 1)
    local digest = raw:sub(p + n, p + n + 31)
    if _sha256(body) ~= digest then _die() end
    return Deserialize(body)
end

local _raw = _base64(ObfuscatorBytecode)
local _chunk = _boot(_raw)
return Wrap(_chunk, _ENV or _G, {})
`;
function generateLua(payload, settings, antiLevel) {
	const encoded = bytesToB64(payload);
	const anti = bytesToB64(new TextEncoder().encode(ANTI_DUMP));
	const hook = bytesToB64(new TextEncoder().encode(ANTI_HOOK));
	const runtime = `local V14=${luaValue({
		Version: settings.Version,
		Seed: settings.Seed,
		OpcodeMap: settings.OpcodeMap,
		Registers: settings.Registers,
		ConstantTags: settings.ConstantTags,
		Key: settings.Key,
		OpcodeTypes: Object.fromEntries(OPCODES.map((op) => [op, settings.OpcodeTypes[op]]))
	})}`;
	return VM_START.replace("|OBFUSCATOR_BYTECODE|", `"${encoded}"`).replace("|V14_RUNTIME|", runtime) + `\nlocal _AntiDumpB64 = "${anti}"\nlocal _AntiHookB64 = "${hook}"\nlocal _AntiLevel = ${antiLevel | 0}\n
` + VM_DESER + "\n" + VM_WRAP + "\n" + BOOT;
}
function protoStats(fn) {
	let instructions = fn.instructions.length;
	let constants = fn.constants.length;
	let prototypes = fn.prototypes.length;
	for (const p of fn.prototypes) {
		const s = protoStats(p);
		instructions += s.instructions;
		constants += s.constants;
		prototypes += s.prototypes;
	}
	return {
		instructions,
		constants,
		prototypes
	};
}
var FUSE = /* @__PURE__ */ new Set([
	"Loadk+Add",
	"Loadk+Sub",
	"GetGlobal+Call",
	"Move+Call",
	"Loadk+Loadk",
	"GetGlobal+GetTable",
	"Self+Call"
]);
var SKIP_NEXT = /* @__PURE__ */ new Set([
	"Test",
	"Eq",
	"Lt",
	"Le",
	"TestSet",
	"TForLoop"
]);
function closureSpan(fn) {
	const protect = /* @__PURE__ */ new Set();
	fn.instructions.forEach((ins, i) => {
		if (ins.op !== "Closure") return;
		protect.add(i);
		const n = fn.prototypes[ins.b]?.upvalCount ?? 0;
		for (let k = 1; k <= n; k++) protect.add(i + k);
	});
	return protect;
}
function stripLines(fn) {
	fn.prototypes.forEach(stripLines);
}
function insertJunk(fn, every) {
	if (every > 0) {
		const ins = fn.instructions;
		const protect = closureSpan(fn);
		const out = [];
		const map = /* @__PURE__ */ new Map();
		for (let i = 0; i < ins.length; i++) {
			map.set(i, out.length);
			out.push(ins[i]);
			if ((i + 1) % every === 0 && !protect.has(i) && !protect.has(i + 1)) {
				const junk = makeIns("Junk");
				junk.junk = true;
				out.push(junk);
			}
		}
		map.set(ins.length, out.length);
		for (const item of out) if (item.target != null) {
			const next = map.get(item.target);
			if (next == null) throw new Error("Salto inválido tras insertar junk");
			item.target = next;
		}
		fn.instructions = out;
	}
	fn.prototypes.forEach((p) => insertJunk(p, every));
}
function fuseSuper(fn) {
	const ins = fn.instructions;
	const protect = closureSpan(fn);
	const targeted = /* @__PURE__ */ new Set();
	for (const item of ins) if (item.target != null) targeted.add(item.target);
	const out = [];
	const map = /* @__PURE__ */ new Map();
	let i = 0;
	while (i < ins.length) {
		const a = ins[i];
		const b = ins[i + 1];
		if (!!b && FUSE.has(`${a.op}+${b.op}`) && !protect.has(i) && !protect.has(i + 1) && !a.bind && !b.bind && !targeted.has(i + 1) && !SKIP_NEXT.has(a.op) && !(a.op === "LoadBool" && a.c !== 0) && a.target == null && b.target == null && !a.junk && !b.junk && b) {
			map.set(i, out.length);
			map.set(i + 1, out.length);
			const sup = makeIns("Super", a.a, a.b, a.c);
			sup.superOps = [{
				op: a.op,
				a: a.a,
				b: a.b,
				c: a.c
			}, {
				op: b.op,
				a: b.a,
				b: b.b,
				c: b.c
			}];
			out.push(sup);
			i += 2;
		} else {
			map.set(i, out.length);
			out.push(a);
			i += 1;
		}
	}
	map.set(ins.length, out.length);
	for (const item of out) if (item.target != null) {
		const next = map.get(item.target);
		if (next == null) throw new Error("Salto inválido tras super-ops");
		item.target = next;
	}
	fn.instructions = out;
	fn.prototypes.forEach(fuseSuper);
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function shuffle(rng, items) {
	const arr = items.slice();
	for (let i = arr.length - 1; i > 0; i--) {
		const j = Math.floor(rng() * (i + 1));
		const tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
	}
	return arr;
}
function layout(rng, fields) {
	const order = shuffle(rng, fields);
	const out = {};
	let pos = 0;
	for (const [name, length] of order) {
		out[name] = {
			Start: pos,
			Length: length
		};
		pos += length;
	}
	return out;
}
function buildSettings(seed) {
	const s = seed >>> 0;
	const rng = mulberry32(s);
	const ids = shuffle(rng, OPCODES.map((_, i) => i));
	const OpcodeMap = {};
	OPCODES.forEach((op, i) => {
		OpcodeMap[op] = ids[i];
	});
	const hex = s.toString(16).padStart(8, "0");
	const key = Array.from(sha256(new TextEncoder().encode(`chelo-v14:${hex}`)));
	const tags = [
		"Nil",
		"Boolean",
		"Number",
		"String"
	];
	const ConstantTags = {};
	for (const tag of tags) ConstantTags[tag] = 1 + Math.floor(rng() * 249);
	const OpcodeTypes = {};
	for (const op of OPCODES) OpcodeTypes[op] = OP_TYPE[op];
	return {
		Version: 14,
		Seed: s,
		OpcodeMap,
		Registers: {
			ABC: layout(rng, [
				["A", 8],
				["B", 9],
				["C", 9],
				["Mode", 3],
				["Enum", 3]
			]),
			ABx: layout(rng, [
				["A", 8],
				["B", 18],
				["Mode", 3],
				["Enum", 3]
			]),
			AsBx: layout(rng, [
				["A", 8],
				["B", 18],
				["Mode", 3],
				["Enum", 3]
			])
		},
		ConstantTags,
		Key: key,
		ChunkStructure: shuffle(rng, [
			"UpvalCount",
			"ParameterCount",
			"VarargCount",
			"Constants",
			"Instructions",
			"Prototypes"
		]),
		OpcodeTypes
	};
}
function clamp(n, lo, hi) {
	return Math.max(lo, Math.min(hi, n));
}
function obfuscate(input, options = {}) {
	const antiLevel = clamp(options.antiLevel ?? 2, 0, 3);
	const junkEvery = clamp(options.junkEvery ?? 5, 0, 50);
	const superops = options.superops !== false;
	let seed = options.seed;
	if (seed == null || Number.isNaN(seed)) {
		const buf = /* @__PURE__ */ new Uint32Array(1);
		crypto.getRandomValues(buf);
		seed = buf[0];
	}
	seed = seed >>> 0;
	let source = "lua";
	let proto;
	if (input instanceof Uint8Array) {
		source = "luac";
		proto = deserializeLuac(input);
		linkJumps(proto);
	} else {
		const text = input.replace(/^\uFEFF/, "");
		if (!text.trim()) throw new Error("Pega código Lua o sube un .lua / .luac");
		proto = compileLua(text);
	}
	markBinds(proto);
	stripLines(proto);
	if (junkEvery > 0) insertJunk(proto, junkEvery);
	if (superops) fuseSuper(proto);
	finalizeJumps(proto);
	const settings = buildSettings(seed);
	const payload = encodeChunk(proto, settings);
	const lua = `-- Chelo Obfuscator v14 · seed ${seed} · anti ${antiLevel}\n${generateLua(payload, settings, antiLevel)}`;
	const stats = protoStats(proto);
	return {
		lua,
		meta: {
			seed,
			antiLevel,
			junkEvery,
			superops,
			payloadBytes: payload.length,
			outputBytes: lua.length,
			...stats,
			source
		}
	};
}
var DRAFT_KEY = "chelo-draft-v1";
var HIST_KEY = "chelo-history-v1";
var SAMPLES = [
	{
		id: "hola",
		label: "Hola",
		source: `print("hola desde chelo")\n`
	},
	{
		id: "fib",
		label: "Fibonacci",
		source: `local function fib(n)
  if n < 2 then
    return n
  end
  return fib(n - 1) + fib(n - 2)
end

print(fib(10))
`
	},
	{
		id: "tabla",
		label: "Tabla",
		source: `local inventory = {
  name = "chelo",
  slots = 8,
}

for i = 1, inventory.slots do
  inventory[i] = i * i
end

print(inventory.name, inventory[3])
`
	},
	{
		id: "cierre",
		label: "Cierre",
		source: `local function counter(start)
  local n = start or 0
  return function(step)
    n = n + (step or 1)
    return n
  end
end

local tick = counter(10)
print(tick())
print(tick(4))
`
	},
	{
		id: "bucle",
		label: "Bucle",
		source: `local n = 1
repeat
  n = n * 2
until n > 32

local sum = 0
local i = 1
while i <= 5 do
  sum = sum + i
  i = i + 1
end

print(n, sum)
`
	}
];
var PRESETS = [
	{
		id: "light",
		label: "Ligero",
		anti: 1,
		junk: 0,
		superops: false,
		hint: "Poco ruido, arranque corto"
	},
	{
		id: "std",
		label: "Estándar",
		anti: 2,
		junk: 5,
		superops: true,
		hint: "El que usarías por defecto"
	},
	{
		id: "max",
		label: "Máximo",
		anti: 3,
		junk: 12,
		superops: true,
		hint: "Canaries y más junk"
	}
];
var ANTI = [
	{
		value: 0,
		label: "Off",
		hint: "Sin anti-dump. Sirve para depurar la salida."
	},
	{
		value: 1,
		label: "1",
		hint: "Capa rápida: anti-hook y sondas ligeras."
	},
	{
		value: 2,
		label: "2",
		hint: "Estándar: anti-hook más anti-dump."
	},
	{
		value: 3,
		label: "3",
		hint: "Completo: incluye los canaries de nivel 3."
	}
];
function looksLikeLuac(bytes) {
	return bytes.length >= 4 && bytes[0] === 27 && bytes[1] === 76 && bytes[2] === 117 && bytes[3] === 97;
}
function formatBytes(n) {
	if (n < 1024) return `${n} B`;
	return `${(n / 1024).toLocaleString("es", { maximumFractionDigits: 1 })} KB`;
}
function formatTime(at) {
	return new Date(at).toLocaleString("es", {
		hour: "2-digit",
		minute: "2-digit",
		day: "2-digit",
		month: "short"
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		className: "size-9",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			className: "fill-primary"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M22.5 9.2a8.2 8.2 0 1 0 2.1 6.3h-3.1a5.2 5.2 0 1 1-1.3-3.6H16V9.2h6.5Z",
			className: "fill-ink"
		})]
	});
}
function Studio() {
	const fileId = (0, import_react.useId)();
	const fileRef = (0, import_react.useRef)(null);
	const [source, setSource] = (0, import_react.useState)(SAMPLES[0].source);
	const [binary, setBinary] = (0, import_react.useState)(null);
	const [fileLabel, setFileLabel] = (0, import_react.useState)("");
	const [seed, setSeed] = (0, import_react.useState)("");
	const [anti, setAnti] = (0, import_react.useState)(2);
	const [junk, setJunk] = (0, import_react.useState)(5);
	const [superops, setSuperops] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(DRAFT_KEY);
			if (raw) {
				const draft = JSON.parse(raw);
				if (typeof draft.source === "string" && draft.source.length > 0) setSource(draft.source);
				if (typeof draft.seed === "string") setSeed(draft.seed);
				if (typeof draft.anti === "number") setAnti(Math.max(0, Math.min(3, draft.anti)));
				if (typeof draft.junk === "number") setJunk(Math.max(0, Math.min(20, draft.junk)));
				if (typeof draft.superops === "boolean") setSuperops(draft.superops);
			}
			const hist = localStorage.getItem(HIST_KEY);
			if (hist) {
				const parsed = JSON.parse(hist);
				if (Array.isArray(parsed)) setHistory(parsed.slice(0, 6));
			}
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const handle = window.setTimeout(() => {
			try {
				localStorage.setItem(DRAFT_KEY, JSON.stringify({
					source,
					seed,
					anti,
					junk,
					superops
				}));
			} catch {}
		}, 250);
		return () => window.clearTimeout(handle);
	}, [
		source,
		seed,
		anti,
		junk,
		superops,
		hydrated
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
				event.preventDefault();
				run();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	const antiHint = ANTI.find((item) => item.value === anti)?.hint ?? "";
	const activePreset = PRESETS.find((preset) => preset.anti === anti && preset.junk === junk && preset.superops === superops)?.id;
	const stats = (0, import_react.useMemo)(() => {
		if (!result) return [];
		const { meta } = result;
		return [
			["Semilla", String(meta.seed)],
			["Origen", meta.source === "luac" ? ".luac" : "Lua"],
			["Instrucciones", String(meta.instructions)],
			["Constantes", String(meta.constants)],
			["Prototipos", String(meta.prototypes)],
			["Payload", formatBytes(meta.payloadBytes)],
			["Salida", formatBytes(meta.outputBytes)],
			["Anti", String(meta.antiLevel)]
		];
	}, [result]);
	function applySample(id) {
		const sample = SAMPLES.find((item) => item.id === id);
		if (!sample) return;
		setSource(sample.source);
		setBinary(null);
		setFileLabel("");
		setError(null);
	}
	function applyPreset(id) {
		const preset = PRESETS.find((item) => item.id === id);
		if (!preset) return;
		setAnti(preset.anti);
		setJunk(preset.junk);
		setSuperops(preset.superops);
	}
	async function onFile(file) {
		const bytes = new Uint8Array(await file.arrayBuffer());
		const lower = file.name.toLowerCase();
		if (looksLikeLuac(bytes) || lower.endsWith(".luac")) {
			if (!looksLikeLuac(bytes)) {
				setError("Ese archivo no tiene la cabecera de un binario Lua 5.1.");
				return;
			}
			setBinary({
				name: file.name,
				bytes
			});
			setFileLabel(file.name);
			setError(null);
			return;
		}
		setBinary(null);
		setSource(new TextDecoder().decode(bytes).replace(/^\uFEFF/, ""));
		setFileLabel(file.name);
		setError(null);
	}
	async function run() {
		setBusy(true);
		setError(null);
		setCopied(false);
		await new Promise((resolve) => window.setTimeout(resolve, 30));
		try {
			const parsedSeed = seed.trim() === "" ? null : Number(seed);
			if (parsedSeed != null && !Number.isFinite(parsedSeed)) throw new Error("La semilla tiene que ser un número.");
			const output = obfuscate(binary ? binary.bytes : source, {
				seed: parsedSeed,
				antiLevel: anti,
				junkEvery: junk,
				superops
			});
			setResult(output);
			if (seed.trim() === "") setSeed(String(output.meta.seed));
			const item = {
				id: `${output.meta.seed}-${Date.now()}`,
				at: Date.now(),
				label: fileLabel || source.trim().split("\n")[0]?.slice(0, 42) || "script",
				source: binary ? source : source,
				seed: output.meta.seed,
				anti,
				junk,
				superops,
				outputBytes: output.meta.outputBytes
			};
			setHistory((prev) => {
				const next = [item, ...prev].slice(0, 6);
				try {
					localStorage.setItem(HIST_KEY, JSON.stringify(next));
				} catch {}
				return next;
			});
		} catch (err) {
			setResult(null);
			setError(err instanceof Error ? err.message : "No se pudo ofuscar.");
		} finally {
			setBusy(false);
		}
	}
	async function copyOut() {
		if (!result) return;
		try {
			await navigator.clipboard.writeText(result.lua);
		} catch {
			const area = document.createElement("textarea");
			area.value = result.lua;
			document.body.appendChild(area);
			area.select();
			document.execCommand("copy");
			area.remove();
		}
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1600);
	}
	function download() {
		if (!result) return;
		const blob = new Blob([result.lua], { type: "text/plain;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `chelo_${result.meta.seed}.lua`;
		link.click();
		URL.revokeObjectURL(url);
	}
	function restore(item) {
		setSource(item.source);
		setBinary(null);
		setFileLabel("");
		setSeed(String(item.seed));
		setAnti(item.anti);
		setJunk(item.junk);
		setSuperops(item.superops);
		setError(null);
	}
	function clearAll() {
		setSource("");
		setBinary(null);
		setFileLabel("");
		setResult(null);
		setError(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-lg font-semibold tracking-tight text-balance",
							children: "Chelo Obfuscator"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-muted",
							children: "VM CHLOV14 · Lua 5.1 · se queda en este navegador"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "hidden items-center gap-2 rounded-full bg-surface px-3 py-2 text-xs text-muted shadow-card sm:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-2 rounded-full bg-primary",
						"aria-hidden": "true"
					}), "v14 listo"]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-start gap-4 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex min-w-0 flex-col rounded-2xl bg-surface p-2 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: "Fuente"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-pretty text-muted",
									children: "Pega Lua 5.1 o sube .lua / .luac"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "sr-only",
											htmlFor: "sample",
											children: "Ejemplos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											id: "sample",
											className: "h-11 rounded-lg border border-line bg-bg px-3 text-sm text-fg",
											defaultValue: "",
											onChange: (event) => {
												if (event.target.value) applySample(event.target.value);
												event.target.value = "";
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												disabled: true,
												children: "Ejemplos"
											}), SAMPLES.map((sample) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: sample.id,
												children: sample.label
											}, sample.id))]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											ref: fileRef,
											id: fileId,
											type: "file",
											accept: ".lua,.luac,.txt",
											className: "sr-only",
											onChange: (event) => {
												const file = event.target.files?.[0];
												if (file) onFile(file);
												event.target.value = "";
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "inline-flex h-11 items-center gap-2 rounded-lg border border-line bg-bg px-3 text-sm",
											onClick: () => fileRef.current?.click(),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, {
												className: "size-4",
												"aria-hidden": "true"
											}), "Subir"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "inline-flex size-11 items-center justify-center rounded-lg border border-line bg-bg",
											onClick: clearAll,
											"aria-label": "Vaciar fuente",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
												className: "size-4",
												"aria-hidden": "true"
											})
										})
									]
								})]
							}),
							binary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-2 mb-2 flex items-center justify-between gap-3 rounded-lg bg-bg px-3 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "min-w-0 truncate",
									children: [
										"Bytecode ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: binary.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted",
											children: [
												" · ",
												formatBytes(binary.bytes.length),
												" · el texto de abajo no se usa"
											]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 shrink-0 rounded-lg px-3 text-sm text-primary",
									onClick: () => {
										setBinary(null);
										setFileLabel("");
									},
									children: "Quitar"
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: source,
								spellCheck: false,
								"aria-label": "Código Lua",
								placeholder: "print(\"hola\")",
								onChange: (event) => setSource(event.target.value),
								className: "min-h-80 w-full resize-y rounded-lg bg-bg p-4 font-mono text-sm leading-relaxed text-fg outline-none placeholder:text-muted"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex min-w-0 flex-col rounded-2xl bg-surface p-2 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2 px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium",
								children: "Resultado"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-pretty text-muted",
								children: result ? `chelo_${result.meta.seed}.lua` : "Aparece aquí, listo para copiar o descargar"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									disabled: !result,
									onClick: () => void copyOut(),
									className: "inline-flex h-11 items-center gap-2 rounded-lg border border-line bg-bg px-3 text-sm disabled:opacity-40",
									children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-4",
										"aria-hidden": "true"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
										className: "size-4",
										"aria-hidden": "true"
									}), copied ? "Copiado" : "Copiar"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									disabled: !result,
									onClick: download,
									className: "inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-3 text-sm font-medium text-ink disabled:opacity-40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Descargar"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							readOnly: true,
							value: result?.lua ?? "",
							spellCheck: false,
							"aria-label": "Script ofuscado",
							placeholder: "El script ofuscado sale aquí. Nada se envía a un servidor.",
							className: "min-h-80 w-full resize-y rounded-lg bg-bg p-4 font-mono text-sm leading-relaxed text-fg outline-none placeholder:text-muted"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-surface p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)_minmax(0,0.8fr)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-medium tracking-wide text-muted uppercase",
											children: "Preset"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-3 gap-2",
											children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => applyPreset(preset.id),
												"aria-pressed": activePreset === preset.id,
												className: "h-11 rounded-lg border px-2 text-sm " + (activePreset === preset.id ? "border-primary bg-primary text-ink" : "border-line bg-bg text-fg"),
												children: preset.label
											}, preset.id))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-pretty text-muted",
											children: PRESETS.find((preset) => preset.id === activePreset)?.hint ?? "Ajuste manual"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-medium tracking-wide text-muted uppercase",
											children: "Anti-dump"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-4 gap-2",
											role: "group",
											"aria-label": "Nivel anti-dump",
											children: ANTI.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-pressed": anti === item.value,
												onClick: () => setAnti(item.value),
												className: "h-11 rounded-lg border text-sm " + (anti === item.value ? "border-primary bg-primary text-ink" : "border-line bg-bg text-fg"),
												children: item.label
											}, item.value))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-pretty text-muted",
											children: antiHint
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-medium tracking-wide text-muted uppercase",
												children: "Semilla"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "inline-flex h-11 items-center gap-1 text-xs text-primary",
												onClick: () => setSeed(""),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dices, {
													className: "size-3.5",
													"aria-hidden": "true"
												}), "Aleatoria"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											inputMode: "numeric",
											value: seed,
											placeholder: "vacío = nueva",
											"aria-label": "Semilla",
											onChange: (event) => setSeed(event.target.value.replace(/[^\d]/g, "").slice(0, 10)),
											className: "h-11 rounded-lg border border-line bg-bg px-3 font-mono text-sm tabular-nums outline-none placeholder:text-muted focus:border-primary"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-pretty text-muted",
											children: "Misma semilla, mismo mapa de opcodes."
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid items-end gap-5 border-t border-line pt-5 md:grid-cols-[minmax(0,1fr)_auto_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-baseline justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-wide text-muted uppercase",
										children: "Junk"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-sm tabular-nums",
										children: junk === 0 ? "off" : `cada ${junk}`
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider, {
									className: "relative flex h-11 w-full touch-none items-center",
									min: 0,
									max: 20,
									step: 1,
									value: [junk],
									onValueChange: (value) => setJunk(value[0] ?? 0),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
										className: "relative h-1.5 grow rounded-full bg-raised",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-primary" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, {
										"aria-label": "Cada cuántas instrucciones se inserta junk",
										className: "block size-5 rounded-full bg-primary shadow-card outline-none focus-visible:ring-2 focus-visible:ring-primary"
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex h-11 items-center gap-3 rounded-lg border border-line bg-bg px-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: superops,
										onCheckedChange: setSuperops,
										className: "relative h-7 w-12 shrink-0 rounded-full bg-raised outline-none data-[state=checked]:bg-primary focus-visible:ring-2 focus-visible:ring-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 translate-x-1 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-6 data-[state=checked]:bg-ink" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm",
										children: "Super-ops"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void run(),
									disabled: busy || !binary && !source.trim(),
									className: "inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-5 text-sm font-semibold text-ink disabled:opacity-40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
										className: "size-4",
										"aria-hidden": "true"
									}), busy ? "Ofuscando…" : "Ofuscar"]
								})
							]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "mt-4 rounded-lg bg-bg px-3 py-3 text-sm text-pretty text-danger",
							children: error
						}) : null
					]
				}),
				result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: stats.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface px-3 py-3 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-mono text-sm tabular-nums",
							children: value
						})]
					}, label))
				}) : null,
				history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mb-2 flex items-center gap-2 text-sm font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, {
						className: "size-4 text-muted",
						"aria-hidden": "true"
					}), "Recientes"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex gap-2 overflow-x-auto pb-1",
					children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => restore(item),
							className: "h-11 max-w-56 truncate rounded-lg border border-line bg-surface px-3 text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-primary tabular-nums",
								children: item.seed
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [" · ", formatTime(item.at)]
							})]
						})
					}, item.id))
				})] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-3 pb-8 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl bg-surface p-4 shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
									className: "mb-3 size-5 text-primary",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: "Qué hace"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-pretty text-muted",
									children: "Compila tu script a una VM propia. Cada semilla baraja opcodes, el layout de registros y la clave. La salida trae el runtime, un chequeo SHA-256 y el anti-dump que elijas."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl bg-surface p-4 shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
									className: "mb-3 size-5 text-primary",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: "Cómo usarlo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-pretty text-muted",
									children: "Pega el fuente, pulsa Ofuscar y descarga el .lua. Ejecútalo donde ya corría el original, con load o loadstring. Ctrl o Cmd + Enter también ofusca."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl bg-surface p-4 shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, {
									className: "mb-3 size-5 text-primary",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: "Límites reales"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-pretty text-muted",
									children: "Lua 5.1. Sin goto, sin Luau y sin el producto comercial de Luraph. Un .luac tiene que ser 5.1 estándar (int32, instrucciones de 4 bytes, doubles)."
								})
							]
						})
					]
				})
			]
		})]
	});
}
var SplitComponent = Studio;
//#endregion
export { SplitComponent as component };
