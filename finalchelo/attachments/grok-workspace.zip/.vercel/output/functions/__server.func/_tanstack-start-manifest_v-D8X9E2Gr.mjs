//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D8X9E2Gr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DBaeXEzF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DBaeXEzF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-qW_qdHVC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
